export interface PresetExam {
  id: string;
  label: string;
  grade: string;
  content: string;
}

export const PRESET_EXAMS: PresetExam[] = [
  {
    id: "grade9-unit1",
    label: "Đề Lớp 9 - Unit 1: Local Environment (15 phút)",
    grade: "Lớp 9",
    content: `ĐỀ KIỂM TRA 15 PHÚT - TIẾNG ANH 9
CHỦ ĐỀ: LOCAL ENVIRONMENT (Cộng đồng địa phương)

I. Choose the correct answer A, B, C, or D to complete each sentence. (4 câu - 4.0 điểm)
1. This scarf was _______ by hand in a traditional craft village.
A. woven
B. knit
C. carved
D. molded

2. My family decided to take a trip to Bat Trang village to _______ how to make pottery.
A. look up
B. learn about
C. pass down
D. close down

3. The artisans in Dong Ho village always try to _______ their traditional craft.
A. set up
B. keep up with
C. preserve
D. take off

4. We need to find a way to make our city cleaner, _______?
A. don't we
B. do we
C. aren't we
D. won't we

II. Complete each sentence with the correct form of the word in brackets. (2 câu - 2.0 điểm)
5. Dong Ho village is famous for its _______ paintings. (TRADITION)
6. Making pottery requires a lot of _______ and patience. (SKILLFUL)

III. Rewrite the following sentences using the suggestions. (2 câu - 4.0 điểm)
7. "I will show you around the lantern-making workshop tomorrow," said Phong. (Phong said...)
 Phong said ___________________________________________
8. Although she was very tired, she continued weaving the tapestry. (Using "In spite of")
 In spite of ___________________________________________

--- ĐÁP ÁN ---
1. A
2. B
3. C
4. A
5. traditional
6. skill
7. Phong said he would show me around the lantern-making workshop the next day. / Phong said that he would show me around the lantern-making workshop the following day.
8. In spite of being very tired, she continued weaving the tapestry.`
  },
  {
    id: "grade7-midterm",
    label: "Đề Lớp 7 - Giữa kỳ 1: Hobbies & Health (Trắc nghiệm + Tự luận)",
    grade: "Lớp 7",
    content: `GIỮA KỲ I - TIẾNG ANH 7
Thời gian làm bài: 45 phút

PHẦN 1: ĐỀ THI

A. PHONETICS (1.5 điểm)
Choose the word whose underlined part is pronounced differently from that of the other three.
1. A. boxes     B. classes     C. potatoes    D. watches
2. A. clean     B. beach       C. great       D. seat
3. A. worked    B. played      C. watched     D. danced

B. VOCABULARY AND GRAMMAR (3.5 điểm)
Choose the best option A, B, C or D to complete each sentence.
4. I love _______ outdoor activities like gardening and cycling.
A. playing     B. doing       C. making      D. taking
5. Eat more fruit and vegetables because they provide _______ vitamins.
A. less        B. no          C. many        D. little
6. She _______ a lot of blood to help people in need last year.
A. donated     B. collected   C. planted     D. recycled
7. My father hates _______ computer games. He thinks they are wasteful.
A. play        B. playing     C. to playing  D. played
8. He loves model-making. He is very _______ with his hands.
A. creative    B. active      C. lazy        D. boring
9. You should wear a hat _______ you don't get sunburnt.
A. or          B. and         C. but         & D. so
10. The children _______ some trees in the school yard yesterday morning.
A. plant       B. planted     C. are plantingD. will plant

C. READING (2.5 điểm)
Read the text and choose the correct answer A, B, C or D for each space.
Green Organization started working in 2012. Its main activities are (11) _______ trees and collecting rubbish. It helps make our city greener and cleaner. Up to now, the organization has planted more than 5,000 trees in urban areas. Members also go to local parks (12) _______ Sundays to pick up trash. They also encourage people to use public transport instead (13) _______ personal motorbikes to reduce pollution.

11. A. planting    B. cut          C. growing     D. climbing
12. A. in          B. at           C. on          D. for
13. A. of          B. to           C. for         D. by

D. WRITING (2.5 điểm)
Complete the second sentence so that it means the same as the first one.
14. My brother is interested in collecting old coins.
 My brother loves ______________________________________
15. He didn't wash his hands, so he had a stomach ache.
 Because ______________________________________________

PHẦN 2: ĐÁP ÁN
1. C
2. C
3. B
4. B
5. C
6. A
7. B
8. A
9. D
10. B
11. A
12. C
13. A
14. My brother loves collecting old coins.
15. Because he didn't wash his hands, he had a stomach ache.`
  },
  {
    id: "grade8-unit3",
    label: "Đề Lớp 8 - Unit 3: Teenagers (15 phút)",
    grade: "Lớp 8",
    content: `ĐỀ 15 PHÚT - TIẾNG ANH 8
TOPIC: TEENAGERS (Tuổi thiếu niên)

I. Choose the correct word to complete the sentence. (4.0 điểm)
1. He is under a lot of peer _______ from his classmates to get high marks.
A. pressure
B. support
C. connection
D. feedback

2. Teenagers often browse online _______ forums to discuss their school work.
A. club
B. post
C. media
D. chat

3. She loves playing chess because it helps her improve her _______ skills.
A. focus
B. concentration
C. physical
D. social

4. The students wanted to participate _______ the cultural exchange program.
A. in
B. on
C. at
D. with

II. Supply the correct form of the verb in brackets. (3.0 điểm)
5. Our teacher suggests _______ (use) social media only for study purposes.
6. She detests _______ (do) homework late at night.
7. We must avoid _______ (post) negative comments online.

III. Complete the sentences with "therefore" or "otherwise". (3.0 điểm)
8. You should log off social media; _______, you cannot focus on your study.
9. He won the swimming competition; _______, he was very happy.
10. Study harder; _______, you will fail the final exam.

--- ĐÁP ÁN ---
1. A
2. D
3. B
4. A
5. using
6. doing
7. posting
8. otherwise
9. therefore
10. otherwise`
  }
];
