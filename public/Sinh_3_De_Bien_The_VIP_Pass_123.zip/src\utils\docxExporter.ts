import { 
  Document, 
  Packer, 
  Paragraph, 
  TextRun, 
  AlignmentType, 
  Table, 
  TableRow, 
  TableCell, 
  BorderStyle, 
  WidthType 
} from "docx";

/**
 * Detects if a line represents a Section Header, Part Title, Roman Numeral, Question Number, or Instruction details
 * that should be bolded according to Ministry standard formats.
 */
function isBoldLine(line: string): boolean {
  const trimmed = line.trim();
  if (!trimmed) return false;
  
  const upper = trimmed.toUpperCase();

  // Part / Section headers
  if (
    upper.startsWith("PHẦN") ||
    upper.startsWith("PART") ||
    upper.startsWith("QUESTION") ||
    upper.startsWith("CÂU")
  ) {
    return true;
  }
  
  // Roman numerals: I., II., III., IV., V., etc.
  if (trimmed.match(/^[I|V|X|L|C|D|M]+\./)) {
    return true;
  }
  
  // Numbers followed by dot like "1. ", "2. " (if it's not a short multiple choice option)
  if (trimmed.match(/^\d+\./) && !trimmed.includes("A.") && !trimmed.includes("B.") && !trimmed.includes("C.") && !trimmed.includes("D.")) {
    return true;
  }
  
  // Scoring guidelines like (1.0 pt), (2.5 points), (10 điểm)
  if (trimmed.match(/\(\d+(\.\d+)?\s*(point|pt|điểm)/i)) {
    return true;
  }

  // Fully capitalized short section subtitles
  if (upper === trimmed && trimmed.length < 80 && !trimmed.match(/^[A-D]\./) && !trimmed.match(/^\d/)) {
    return true;
  }

  return false;
}

/**
 * Creates the standard header table, student name input, and grading box
 * according to Ministry of Education guidelines.
 */
function createHeaderAndStudentBlock(title: string): (Table | Paragraph)[] {
  const block: (Table | Paragraph)[] = [];

  // 1. School & Exam Information Table (Borderless)
  block.push(
    new Table({
      width: {
        size: 100,
        type: WidthType.PERCENTAGE,
      },
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
        insideHorizontal: { style: BorderStyle.NONE },
        insideVertical: { style: BorderStyle.NONE },
      },
      rows: [
        new TableRow({
          children: [
            new TableCell({
              width: { size: 45, type: WidthType.PERCENTAGE },
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 0, after: 60, line: 240 },
                  children: [
                    new TextRun({
                      text: "TRƯỜNG THCS ....................................",
                      bold: true,
                      font: "Times New Roman",
                      size: 24, // 12pt
                    }),
                  ],
                }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 0, after: 120, line: 240 },
                  children: [
                    new TextRun({
                      text: "------------------",
                      font: "Times New Roman",
                      size: 18,
                      color: "555555",
                    }),
                  ],
                }),
              ],
            }),
            new TableCell({
              width: { size: 55, type: WidthType.PERCENTAGE },
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 0, after: 60, line: 240 },
                  children: [
                    new TextRun({
                      text: title.toUpperCase(),
                      bold: true,
                      font: "Times New Roman",
                      size: 26, // 13pt
                    }),
                  ],
                }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 0, after: 60, line: 240 },
                  children: [
                    new TextRun({
                      text: "ĐỀ KIỂM TRA ĐỀ XUẤT TIẾNG ANH THCS",
                      bold: true,
                      font: "Times New Roman",
                      size: 24, // 12pt
                    }),
                  ],
                }),
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 0, after: 60, line: 240 },
                  children: [
                    new TextRun({
                      text: "Năm học: 2025 - 2026",
                      font: "Times New Roman",
                      size: 24, // 12pt
                    }),
                  ],
                }),
              ],
            }),
          ],
        }),
      ],
    })
  );

  // 2. Student name & Class input line
  block.push(
    new Paragraph({
      spacing: { before: 180, after: 180, line: 240 },
      children: [
        new TextRun({
          text: "Họ và tên học sinh: ............................................................................ Lớp: .....................",
          font: "Times New Roman",
          size: 26, // 13pt
        }),
      ],
    })
  );

  // 3. Grading Table (With Borders)
  block.push(
    new Table({
      width: {
        size: 100,
        type: WidthType.PERCENTAGE,
      },
      rows: [
        new TableRow({
          children: [
            new TableCell({
              width: { size: 30, type: WidthType.PERCENTAGE },
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 80, after: 80, line: 240 },
                  children: [
                    new TextRun({
                      text: "Điểm số",
                      bold: true,
                      font: "Times New Roman",
                      size: 26, // 13pt
                    }),
                  ],
                }),
                new Paragraph({ spacing: { line: 240, after: 120 } }),
                new Paragraph({ spacing: { line: 240, after: 120 } }),
              ],
            }),
            new TableCell({
              width: { size: 70, type: WidthType.PERCENTAGE },
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { before: 80, after: 80, line: 240 },
                  children: [
                    new TextRun({
                      text: "Nhận xét của thầy, cô giáo",
                      bold: true,
                      font: "Times New Roman",
                      size: 26, // 13pt
                    }),
                  ],
                }),
                new Paragraph({ spacing: { line: 240, after: 120 } }),
                new Paragraph({ spacing: { line: 240, after: 120 } }),
              ],
            }),
          ],
        }),
      ],
    })
  );

  // Spacer after table
  block.push(new Paragraph({ spacing: { before: 180, after: 180, line: 240 } }));

  return block;
}

/**
 * Exports a single exam variant with its detailed answers into a .docx file.
 * Formatted with Times New Roman, size 13, single line spacing, A4 paper, 1.5cm margins and generic headings.
 */
export async function exportSingleVariant(title: string, examContent: string, answers: string) {
  const children: (Paragraph | Table)[] = [];

  // Add the official headers and student name blocks
  children.push(...createHeaderAndStudentBlock(title));

  // 2. Exam Content
  const examLines = examContent.split("\n");
  for (const line of examLines) {
    const trimmed = line.trim();
    if (trimmed === "") {
      children.push(new Paragraph({ spacing: { line: 240, after: 60 } }));
      continue;
    }

    const bold = isBoldLine(trimmed);

    children.push(
      new Paragraph({
        spacing: { line: 240, before: 0, after: 60 },
        children: [
          new TextRun({
            text: line,
            bold,
            size: 26, // 13pt
            color: "000000",
            font: "Times New Roman",
          }),
        ],
      })
    );
  }

  // 3. Separator for Answers
  children.push(new Paragraph({ spacing: { line: 240, before: 360, after: 120 } }));
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { line: 240, before: 120, after: 120 },
      children: [
        new TextRun({
          text: "PHẦN 2: ĐÁP ÁN VÀ GIẢI THÍCH CHI TIẾT",
          bold: true,
          size: 28, // 14pt
          color: "000000",
          font: "Times New Roman",
        }),
      ],
    })
  );

  // 4. Answers
  const answerLines = answers.split("\n");
  for (const line of answerLines) {
    const trimmed = line.trim();
    if (trimmed === "") {
      children.push(new Paragraph({ spacing: { line: 240, after: 60 } }));
      continue;
    }

    const bold = isBoldLine(trimmed);

    children.push(
      new Paragraph({
        spacing: { line: 240, before: 0, after: 60 },
        children: [
          new TextRun({
            text: line,
            bold,
            size: 26, // 13pt
            font: "Times New Roman",
            color: "000000"
          }),
        ],
      })
    );
  }

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 850,    // 1.5 cm
              bottom: 850, // 1.5 cm
              left: 850,   // 1.5 cm
              right: 850,  // 1.5 cm
            },
            size: {
              width: 11906,  // A4 Width (210mm)
              height: 16838, // A4 Height (297mm)
            }
          },
        },
        children,
      },
    ],
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${title.replace(/\s+/g, "_")}.docx`;
  a.click();
  URL.revokeObjectURL(url);
}

/**
 * Exports all three variants merged into a single word document, separated by page sections.
 * Formatted with Times New Roman, size 13, single line spacing, A4 paper, 1.5cm margins and generic headings.
 */
export async function exportAllVariants(variants: { title: string; examContent: string; answers: string }[]) {
  const sections = variants.map((v) => {
    const children: (Paragraph | Table)[] = [];

    // Add the official headers and student name blocks
    children.push(...createHeaderAndStudentBlock(v.title));

    // Content
    const examLines = v.examContent.split("\n");
    for (const line of examLines) {
      const trimmed = line.trim();
      if (trimmed === "") {
        children.push(new Paragraph({ spacing: { line: 240, after: 60 } }));
        continue;
      }

      const bold = isBoldLine(trimmed);

      children.push(
        new Paragraph({
          spacing: { line: 240, before: 0, after: 60 },
          children: [
            new TextRun({
              text: line,
              bold,
              size: 26, // 13pt
              color: "000000",
              font: "Times New Roman",
            }),
          ],
        })
      );
    }

    // Separator before Answers
    children.push(new Paragraph({ spacing: { line: 240, before: 360, after: 120 } }));
    children.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { line: 240, before: 120, after: 120 },
        children: [
          new TextRun({
            text: "PHẦN 2: ĐÁP ÁN VÀ GIẢI THÍCH CHI TIẾT",
            bold: true,
            size: 28, // 14pt
            color: "000000",
            font: "Times New Roman",
          }),
        ],
      })
    );

    // Answers
    const answerLines = v.answers.split("\n");
    for (const line of answerLines) {
      const trimmed = line.trim();
      if (trimmed === "") {
        children.push(new Paragraph({ spacing: { line: 240, after: 60 } }));
        continue;
      }

      const bold = isBoldLine(trimmed);

      children.push(
        new Paragraph({
          spacing: { line: 240, before: 0, after: 60 },
          children: [
            new TextRun({
              text: line,
              bold,
              size: 26, // 13pt
              font: "Times New Roman",
              color: "000000"
            }),
          ],
        })
      );
    }

    return {
      properties: {
        page: {
          margin: {
            top: 850,    // 1.5 cm
            bottom: 850, // 1.5 cm
            left: 850,   // 1.5 cm
            right: 850,  // 1.5 cm
          },
          size: {
            width: 11906,
            height: 16838,
          }
        },
      },
      children,
    };
  });

  const doc = new Document({
    sections,
  });

  const blob = await Packer.toBlob(doc);
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Dong_bo_3_de_bien_the_THCS.docx`;
  a.click();
  URL.revokeObjectURL(url);
}
