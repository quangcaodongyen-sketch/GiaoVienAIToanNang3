import React, { useState, useEffect } from "react";
import {
  Sparkles,
  BookOpen,
  Download,
  Trash2,
  Key,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Eye,
  EyeOff,
  Home,
  FileText,
  Check,
  Loader2,
  Info,
  Layers,
  Settings,
  ChevronRight,
  Play,
  X,
  Upload
} from "lucide-react";
import { PRESET_EXAMS, PresetExam } from "./presets";
import { exportSingleVariant, exportAllVariants } from "./utils/docxExporter";

interface ExamAnalysis {
  subject: string;
  grade: string;
  totalQuestions: string;
  totalParts: string;
  skillsTested: string;
  difficulty: string;
}

interface ExamVariant {
  title: string;
  examContent: string;
  answers: string;
}

interface GeneratedData {
  analysis: ExamAnalysis;
  variant1: ExamVariant;
  variant2: ExamVariant;
  variant3: ExamVariant;
}

export default function App() {
  // Original Exam text (for presets and backward compatibility)
  const [originalExam, setOriginalExam] = useState<string>("");
  
  // File upload state
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    base64: string;
    mimeType: string;
    size?: string;
  } | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);

  // Custom Gemini API Key state
  const [customApiKey, setCustomApiKey] = useState<string>(() => {
    return localStorage.getItem("gemini_custom_api_key") || "";
  });
  const [apiKeyInput, setApiKeyInput] = useState<string>(() => {
    return localStorage.getItem("gemini_custom_api_key") || "";
  });
  const [showApiKey, setShowApiKey] = useState<boolean>(false);
  const [keyVerificationStatus, setKeyVerificationStatus] = useState<{
    tested: boolean;
    success: boolean;
    message: string;
  }>({ tested: false, success: false, message: "" });
  const [isVerifyingKey, setIsVerifyingKey] = useState<boolean>(false);
  const [showKeyPanel, setShowKeyPanel] = useState<boolean>(false);

  // Gemini Model state (Referenced from taodethi2026.vercel.app settings)
  const [selectedModel, setSelectedModel] = useState<string>(() => {
    return localStorage.getItem("gemini_selected_model") || "gemini-2.5-flash";
  });

  // App running/generation states
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingMessage, setLoadingMessage] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  
  // Generated variants and analysis
  const [generatedData, setGeneratedData] = useState<GeneratedData | null>(null);

  // Active tabs for each variant card ("exam" | "answers") - Kept for compatibility if needed
  const [activeTabs, setActiveTabs] = useState<{
    variant1: "exam" | "answers";
    variant2: "exam" | "answers";
    variant3: "exam" | "answers";
  }>({
    variant1: "exam",
    variant2: "exam",
    variant3: "exam",
  });

  // Load API Key on mount
  useEffect(() => {
    const savedKey = localStorage.getItem("gemini_custom_api_key");
    if (savedKey) {
      setApiKeyInput(savedKey);
    }
  }, []);

  // Educational status cycling messages when generating
  useEffect(() => {
    if (!isLoading) return;

    const messages = [
      "🔍 Đang quét và phân tích ma trận kiến thức tệp đề thi gốc...",
      "🧠 Đang trích xuất cấu trúc ngữ pháp, từ vựng cốt lõi THCS...",
      "✍️ Đang soạn ĐỀ 1 (Biến thể nhẹ: Đổi từ vựng, ngữ cảnh & tên riêng)...",
      "⚡ Đang soạn ĐỀ 2 (Biến thể trung bình: Viết lại bài đọc, đổi cấu trúc tương đương)...",
      "✨ Đang soạn ĐỀ 3 (Biến thể mới hơn: Thiết kế mới câu hỏi bám sát ma trận)...",
      "🔑 Đang biên soạn đáp án và giải thích chi tiết cho cả 3 đề thi...",
      "🎉 Sắp hoàn thành! Đang đóng gói dữ liệu và kiểm tra định dạng Times New Roman..."
    ];

    let currentIdx = 0;
    setLoadingMessage(messages[0]);

    const interval = setInterval(() => {
      currentIdx = (currentIdx + 1) % messages.length;
      setLoadingMessage(messages[currentIdx]);
    }, 4500);

    return () => clearInterval(interval);
  }, [isLoading]);

  // Handle Preset Exam Selection
  const handleSelectPreset = (preset: PresetExam) => {
    setOriginalExam(preset.content);
    setUploadedFile({
      name: `[Đề mẫu] ${preset.label}`,
      base64: "", // empty base64, will fall back to originalExam text
      mimeType: "text/plain"
    });
    setError(null);
  };

  // API Key operations
  const handleSaveApiKey = () => {
    if (!apiKeyInput.trim()) {
      setError("Vui lòng nhập API Key trước khi lưu.");
      return;
    }
    localStorage.setItem("gemini_custom_api_key", apiKeyInput.trim());
    localStorage.setItem("gemini_selected_model", selectedModel);
    setCustomApiKey(apiKeyInput.trim());
    setKeyVerificationStatus({
      tested: true,
      success: true,
      message: "Đã lưu cấu hình API Key và Mô hình thành công!"
    });
    setError(null);
  };

  const handleDeleteApiKey = () => {
    localStorage.removeItem("gemini_custom_api_key");
    localStorage.removeItem("gemini_selected_model");
    setApiKeyInput("");
    setCustomApiKey("");
    setSelectedModel("gemini-2.5-flash");
    setKeyVerificationStatus({ tested: false, success: false, message: "" });
  };

  const handleTestApiKey = async () => {
    const keyToTest = apiKeyInput.trim();
    if (!keyToTest) {
      setKeyVerificationStatus({
        tested: true,
        success: false,
        message: "Vui lòng nhập API Key trước khi kiểm tra."
      });
      return;
    }

    setIsVerifyingKey(true);
    setKeyVerificationStatus({ tested: false, success: false, message: "" });
    
    try {
      const res = await fetch("/api/check-key", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ customApiKey: keyToTest })
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setKeyVerificationStatus({
          tested: true,
          success: true,
          message: "Tuyệt vời! API Key hợp lệ và hoạt động chính xác."
        });
      } else {
        setKeyVerificationStatus({
          tested: true,
          success: false,
          message: data.message || "API Key không hợp lệ. Vui lòng kiểm tra lại."
        });
      }
    } catch (err: any) {
      setKeyVerificationStatus({
        tested: true,
        success: false,
        message: "Không thể kết nối đến hệ thống kiểm tra."
      });
    } finally {
      setIsVerifyingKey(false);
    }
  };

  // Main Generation Handler
  const handleGenerateVariants = async () => {
    if (!uploadedFile) {
      setError("Vui lòng chọn hoặc kéo thả đề thi gốc vào đây trước.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setGeneratedData(null);

    const isRealFile = uploadedFile.mimeType === "application/pdf" || uploadedFile.mimeType.startsWith("image/");
    const systemInstruction = `Bạn là chuyên gia ra đề kiểm tra Tiếng Anh THCS (Trung học cơ sở, từ Lớp 6 đến Lớp 9). 
Hãy tạo đúng 3 đề kiểm tra biến thể khác nhau từ đề gốc do giáo viên cung cấp.
Giữ nguyên cấu trúc đề gốc bao gồm: số phần, số câu, dạng câu hỏi, mức độ khó, và ma trận kiến thức.
Không tạo câu hỏi vượt quá trình độ học sinh THCS. Mỗi đề phải có phần đề thi và đáp án đầy đủ.

Quy tắc sinh đề và định dạng đặc biệt bắt buộc:
- Không sao chép y nguyên câu hỏi gốc.
- Thay đổi tên người, địa danh, đồ vật, tình huống hoặc đổi từ vựng/ngữ pháp tương đương.
- Giữ nguyên dạng bài (ví dụ: Multiple Choice, Reading, Writing, Listening script nếu có).
- Mỗi câu trắc nghiệm có 4 đáp án A, B, C, D nếu đề gốc có 4 đáp án. Chỉ có đúng 1 đáp án đúng cho mỗi câu.
- Đáp án phải khớp chính xác với câu hỏi.
- KHÔNG sử dụng bảng biểu (table) cho phần văn bản trong đề thi (ví dụ: câu hỏi, bài đọc, câu trắc nghiệm), để tránh việc khó căn chỉnh khi tải về. Chỉ dùng văn bản thuần.
- Trong phần câu hỏi trắc nghiệm A, B, C, D: Nếu các phương án trả lời ngắn (khoảng 1-3 từ), hãy trình bày chung trên 1 dòng với khoảng cách hợp lý (ví dụ: A. cat      B. dog      C. bird      D. fish) với khoảng cách tối thiểu 6-8 dấu cách giữa các phương án. Nếu các phương án dài hơn, hãy chia thành 2 dòng (A, B trên dòng 1; C, D trên dòng 2). Chỉ viết mỗi phương án trên một dòng khi đáp án rất dài hoặc chứa câu hoàn chỉnh.
- Đối với các môn hoặc câu hỏi có công thức toán học/khoa học, hãy viết đúng định dạng ký tự toán học chuẩn Unicode (ví dụ: dùng x², √y, ±, etc.) để hiển thị và xuất Word không bị lỗi công thức.
- Không tạo nội dung nhạy cảm, chính trị, bạo lực.
- Ngôn ngữ phù hợp học sinh lớp 6, 7, 8, 9.

Mức độ biến thể của 3 đề:
- Đề 1 (Biến thể nhẹ): Đổi từ vựng, ngữ cảnh, tên riêng hoặc tình huống đơn giản nhưng giữ nguyên cấu trúc ngữ pháp và kiểu câu hỏi.
- Đề 2 (Biến thể trung bình): Đổi câu hỏi và ngữ cảnh nhiều hơn, sử dụng các cấu trúc ngữ pháp tương đương cùng mức độ, nội dung bài đọc được viết lại mới.
- Đề 3 (Biến thể mới hơn): Kiểm tra cùng một lượng kiến thức, chủ đề và điểm ngữ pháp nhưng đổi mới hoàn toàn câu hỏi và bài tập, không trùng câu với đề gốc hay đề 1, 2.

Đảm bảo kết quả trả về bằng tiếng Việt dễ hiểu cho giáo viên, nhưng phần nội dung đề thi và đáp án tiếng Anh phải chuẩn ngữ pháp, tự nhiên và chính xác.`;

    let contents: any[] = [];
    if (isRealFile) {
      const base64Data = uploadedFile.base64.split(",")[1] || uploadedFile.base64;
      contents.push({
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: uploadedFile.mimeType
            }
          },
          {
            text: `Dưới đây là tệp tin đề thi gốc do giáo viên tải lên.
Hãy đọc kỹ tệp tin này, nhận diện toàn bộ nội dung đề thi (bao gồm các phần trắc nghiệm, tự luận, bài đọc, câu hỏi và đáp án nếu có).
Sau đó, tiến hành phân tích ma trận kiến thức của đề gốc này: Xác định số phần, số câu, dạng câu hỏi, mức độ khó, chủ đề từ vựng và ngữ pháp.
Tiếp theo, hãy sinh ra đúng 3 đề kiểm tra biến thể tương ứng theo đúng các quy tắc sinh đề và định dạng đặc biệt bắt buộc ở phần hướng dẫn hệ thống:
- Đề biến thể số 1 (Biến thể nhẹ)
- Đề biến thể số 2 (Biến thể trung bình)
- Đề biến thể số 3 (Biến thể mới hơn)

Mỗi đề biến thể bắt buộc phải có đầy đủ 2 phần chính được viết rõ ràng trong văn bản:
PHẦN 1: ĐỀ THI
[Toàn bộ đề thi]

PHẦN 2: ĐÁP ÁN
1. A
2. B
...

Vui lòng trả về kết quả dưới dạng JSON theo đúng cấu trúc của responseSchema.`
          }
        ]
      });
    } else {
      contents.push({
        parts: [
          {
            text: `Dưới đây là đề thi gốc do giáo viên cung cấp:
---
${originalExam}
---

Hãy phân tích đề thi gốc này: Xác định số phần, số câu, dạng câu hỏi, mức độ khó, chủ đề từ vựng và ngữ pháp.
Sau đó, sinh ra 3 đề biến thể tương ứng:
- Đề biến thể số 1 (Biến thể nhẹ)
- Đề biến thể số 2 (Biến thể trung bình)
- Đề biến thể số 3 (Biến thể mới hơn)

Mỗi đề biến thể bắt buộc phải có đầy đủ 2 phần chính được viết rõ ràng trong văn bản:
PHẦN 1: ĐỀ THI
[Toàn bộ đề thi]

PHẦN 2: ĐÁP ÁN
1. A
2. B
...

Vui lòng trả về kết quả dưới dạng JSON theo đúng cấu trúc của responseSchema.`
          }
        ]
      });
    }

    try {
      let data: any;

      if (customApiKey && customApiKey.trim() !== "") {
        // Run Client-Side via Google API to bypass Vercel 10s execution limits
        const apiKey = customApiKey.trim();
        const model = selectedModel;
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents,
            systemInstruction: {
              parts: [{ text: systemInstruction }]
            },
            generationConfig: {
              responseMimeType: "application/json",
              responseSchema: {
                type: "OBJECT",
                properties: {
                  analysis: {
                    type: "OBJECT",
                    properties: {
                      subject: { type: "STRING" },
                      grade: { type: "STRING" },
                      totalQuestions: { type: "STRING" },
                      totalParts: { type: "STRING" },
                      skillsTested: { type: "STRING" },
                      difficulty: { type: "STRING" }
                    },
                    required: ["subject", "grade", "totalQuestions", "totalParts", "skillsTested", "difficulty"]
                  },
                  variant1: {
                    type: "OBJECT",
                    properties: {
                      title: { type: "STRING" },
                      examContent: { type: "STRING" },
                      answers: { type: "STRING" }
                    },
                    required: ["title", "examContent", "answers"]
                  },
                  variant2: {
                    type: "OBJECT",
                    properties: {
                      title: { type: "STRING" },
                      examContent: { type: "STRING" },
                      answers: { type: "STRING" }
                    },
                    required: ["title", "examContent", "answers"]
                  },
                  variant3: {
                    type: "OBJECT",
                    properties: {
                      title: { type: "STRING" },
                      examContent: { type: "STRING" },
                      answers: { type: "STRING" }
                    },
                    required: ["title", "examContent", "answers"]
                  }
                },
                required: ["analysis", "variant1", "variant2", "variant3"]
              }
            }
          })
        });

        if (!res.ok) {
          const errorData = await res.json().catch(() => ({}));
          throw new Error(errorData?.error?.message || `Lỗi HTTP ${res.status}: ${res.statusText}`);
        }

        const result = await res.json();
        const text = result?.candidates?.[0]?.content?.parts?.[0]?.text;
        if (!text) {
          throw new Error("Không nhận được dữ liệu đề từ Google Gemini. Vui lòng kiểm tra lại cấu hình.");
        }
        data = JSON.parse(text);
      } else {
        // Fall back to serverless backend for shared key
        const res = await fetch("/api/generate", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            originalExam: isRealFile ? "" : originalExam,
            fileData: isRealFile ? {
              base64: uploadedFile.base64,
              mimeType: uploadedFile.mimeType
            } : undefined,
            selectedModel
          })
        });

        const textResponse = await res.text();
        let result: any;
        try {
          result = JSON.parse(textResponse);
        } catch (jsonErr) {
          if (textResponse.includes("504") || textResponse.includes("Gateway Timeout") || textResponse.includes("An error occurred")) {
            throw new Error("Vercel Gateway Timeout (10 giây). Máy chủ miễn phí Vercel giới hạn thời gian chạy tối đa 10s. Để sinh đề thi lớn ổn định, vui lòng dán Google Gemini API Key cá nhân của bạn ở mục Cài Đặt phía trên để chạy trực tiếp trên trình duyệt của bạn (bỏ qua giới hạn Vercel).");
          }
          throw new Error(`Phản hồi từ máy chủ không hợp lệ: ${textResponse.substring(0, 100)}...`);
        }

        if (!res.ok || !result.success) {
          throw new Error(result.message || "Không thể sinh đề biến thể từ AI.");
        }

        data = result.data;
      }

      setGeneratedData(data);
      setActiveTabs({
        variant1: "exam",
        variant2: "exam",
        variant3: "exam"
      });
    } catch (err: any) {
      console.error(err);
      const errMsg = err.message || "";
      if (errMsg.includes("503") || errMsg.includes("demand") || errMsg.includes("UNAVAILABLE") || errMsg.includes("temporary") || errMsg.includes("Unavailable")) {
        setError(
          "Hệ thống Google Gemini hiện tại đang quá tải (Lỗi 503: High demand). Vui lòng thử lại sau vài giây hoặc nhấn nút 'Sử dụng đề thi mẫu' màu xám bên dưới để trải nghiệm xuất Word ngay lập tức."
        );
      } else {
        setError(errMsg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  // Quick reset action
  const handleReset = () => {
    setOriginalExam("");
    setUploadedFile(null);
    setGeneratedData(null);
    setError(null);
  };

  const handleClearFile = () => {
    setUploadedFile(null);
    setOriginalExam("");
    setError(null);
  };

  // File Upload Helper Processing
  const processFile = (file: File) => {
    if (file.size > 20 * 1024 * 1024) {
      setError("Tải tệp không thành công. Kích thước tệp tối đa là 20MB.");
      return;
    }

    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const base64 = reader.result as string;
      setUploadedFile({
        name: file.name,
        base64,
        mimeType: file.type,
        size: (file.size / 1024 / 1024).toFixed(2) + " MB"
      });
      setOriginalExam("");
      setError(null);
    };
    reader.onerror = () => {
      setError("Không thể đọc tệp này. Vui lòng thử lại.");
    };
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  // Load mock data for testing Word export format
  const handleLoadMockData = () => {
    setError(null);
    setGeneratedData({
      analysis: {
        subject: "Tiếng Anh THCS (Mẫu Thử Nghiệm)",
        grade: "Lớp 8",
        totalQuestions: "25",
        totalParts: "3",
        skillsTested: "Phát âm, Từ vựng, Ngữ pháp, Viết, Toán học mẫu (công thức)",
        difficulty: "Trung bình"
      },
      variant1: {
        title: "Đề thi thử nghiệm số 1",
        examContent: `Phần 1: ĐỀ THI - ĐỀ SỐ 1\nUBND XÃ ĐỒNG YÊN - TRƯỜNG THCS ĐỒNG YÊN BÀI KIỂM TRA ĐÁNH GIÁ CUỐI HỌC KÌ II - MÔN: TIẾNG ANH 8\n\nPart 1: Listen and circle A or B.\n1. In the future, we will use robots to do all the housework. A. True B. False\n2. Flying cars will be common by 2050. A. True B. False\n3. We will be able to travel to the moon for holidays. A. True B. False\n4. Virtual reality will replace all classrooms. A. True B. False\n5. Learning a language will be instant with neural chips. A. True B. False\n\nPart 2: Listen and choose the best option. 6. The speaker finds Astronomy _____. A. fascinating B. tiring C. scary\n7. During the club, they often _____. A. build rockets B. look at stars C. write reports\n8. The speaker dreams of being an _____. A. engineer B. astronaut C. teacher\n9. Space exploration helps us understand _____. A. oceans B. the universe C. history\n10. Science solves _____. A. problems B. ancient C. global`,
        answers: `1. A\n2. A\n3. B\n4. A\n5. B\n6. A\n7. B\n8. B\n9. B\n10. A`
      },
      variant2: {
        title: "Đề thi thử nghiệm số 2",
        examContent: `Phần 1: ĐỀ THI - ĐỀ SỐ 2\nUBND XÃ ĐỒNG YÊN - TRƯỜNG THCS ĐỒNG YÊN BÀI KIỂM TRA ĐÁNH GIÁ CUỐI HỌC KÌ II - MÔN: TIẾNG ANH 8\n\nPart 1: Listen and circle A or B.\n1. AI will handle medical diagnoses in the future. A. True B. False\n2. Humans will travel to other galaxies by 2040. A. True B. False\n3. Solar energy will be the main power source. A. True B. False\n4. Virtual classrooms require physical presence. A. True B. False\n5. Translation gadgets will make languages obsolete. A. True B. False\n\nPart 2: Listen and choose the best option. 6. The speaker talks about _____ technology. A. outdated B. modern C. simple\n7. He uses a _____ for his daily tasks. A. smartphone B. paper map C. typewriter\n8. He believes technology makes life _____. A. harder B. easier C. busier\n9. The biggest benefit is the speed of _____. A. walking B. information C. cooking\n10. He worries about _____ security. A. digital B. physical C. financial`,
        answers: `1. A\n2. B\n3. A\n4. B\n5. A\n6. B\n7. A\n8. B\n9. B\n10. A`
      },
      variant3: {
        title: "Đề thi thử nghiệm số 3",
        examContent: `Phần 1: ĐỀ THI - ĐỀ SỐ 3\nUBND XÃ ĐỒNG YÊN - TRƯỜNG THCS ĐỒNG YÊN BÀI KIỂM TRA ĐÁNH GIÁ CUỐI HỌC KÌ II - MÔN: TIẾNG ANH 8\n\nPart 1: Listen and circle A or B.\n1. Nanotechnology will help repair human cells. A. True B. False\n2. Humans will inhabit the oceans by 2060. A. True B. False\n3. Most electricity will come from nuclear fusion. A. True B. False\n4. Computers will develop human-like emotions. A. True B. False\n5. Wireless charging will be available everywhere. A. True B. False\n\nPart 2: Listen and choose the best option. 6. The speaker talks about a _____ gadget. A. health B. kitchen C. security\n7. It helps the user track their _____. A. sleep B. steps C. temperature\n8. He bought it during a _____ sale. A. seasonal B. clearance C. birthday\n9. He thinks it is a _____ investment. A. bad B. smart C. risky\n10. He will buy another one for his _____. A. sister B. friend C. neighbor`,
        answers: `1. A\n2. B\n3. A\n4. B\n5. A\n6. A\n7. B\n8. B\n9. B\n10. C`
      }
    });
    setUploadedFile({
      name: "Mã đề 801 - IN.pdf",
      base64: "",
      mimeType: "application/pdf"
    });
    setActiveTabs({
      variant1: "exam",
      variant2: "exam",
      variant3: "exam"
    });
  };

  // Export variants to .docx
  const handleDownloadSingle = async (variantKey: "variant1" | "variant2" | "variant3") => {
    if (!generatedData) return;
    const variant = generatedData[variantKey];
    try {
      await exportSingleVariant(variant.title, variant.examContent, variant.answers);
    } catch (err) {
      console.error("Lỗi xuất file Word:", err);
      alert("Có lỗi xảy ra khi xuất file Word. Vui lòng tải lại trang.");
    }
  };

  const handleDownloadAllCombined = async () => {
    if (!generatedData) return;
    const list = [
      generatedData.variant1,
      generatedData.variant2,
      generatedData.variant3,
    ];
    try {
      await exportAllVariants(list);
    } catch (err) {
      console.error("Lỗi xuất file gộp Word:", err);
      alert("Có lỗi xảy ra khi tải file Word gộp.");
    }
  };

  // Line formatting helper for results viewport rendering
  const renderExamLine = (line: string, idx: number) => {
    const trimmed = line.trim();
    if (trimmed === "") return <div key={idx} className="h-2" />;

    // 1. Highlight specific school title line
    if (trimmed.includes("UBND XÃ ĐỒNG YÊN") && trimmed.includes("TRƯỜNG THCS ĐỒNG YÊN")) {
      const targetStr = "UBND XÃ ĐỒNG YÊN - TRƯỜNG THCS ĐỒNG YÊN";
      const startIndex = trimmed.indexOf(targetStr);
      if (startIndex !== -1) {
        const before = trimmed.substring(0, startIndex);
        const after = trimmed.substring(startIndex + targetStr.length);
        return (
          <div key={idx} className="font-bold text-xs leading-relaxed mb-3">
            {before}
            <span className="text-[#059669] font-extrabold">{targetStr}</span>
            <span className="text-slate-800 font-extrabold">{after}</span>
          </div>
        );
      }
    }

    // 2. Highlight section headers
    const isSectionHeader = 
      trimmed.startsWith("PHẦN") || 
      trimmed.startsWith("PART") || 
      trimmed.startsWith("Part") ||
      trimmed.startsWith("Phần") ||
      (trimmed.toUpperCase() === trimmed && trimmed.length < 100 && !trimmed.match(/^[A-D]\./));

    if (isSectionHeader) {
      return (
        <div key={idx} className="font-bold text-teal-700 text-xs mt-3 mb-1.5 uppercase">
          {line}
        </div>
      );
    }

    // 3. Highlight question lines
    const isQuestion = trimmed.match(/^\d+\./) !== null || trimmed.startsWith("Câu");
    if (isQuestion) {
      return (
        <div key={idx} className="font-semibold text-slate-800 mt-2 mb-1">
          {line}
        </div>
      );
    }

    // Default regular line
    return (
      <div key={idx} className="text-slate-700 mb-1">
        {line}
      </div>
    );
  };

  return (
    <div id="app_root" className="min-h-screen bg-slate-50 text-slate-800 font-sans selection:bg-emerald-100 selection:text-emerald-900 pb-16">
      {/* 1. Header Section */}
      <header id="app_header" className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs px-4 sm:px-6 lg:px-8 py-3.5 transition-all">
        <div className="max-w-[1600px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          
          {/* Logo & Navigation (Matching user screenshot header) */}
          <div className="flex items-center gap-3">
            <button 
              id="btn_home"
              onClick={handleReset} 
              className="flex items-center gap-1 px-3 py-1 text-sm font-medium text-slate-600 hover:text-emerald-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200 shadow-3xs cursor-pointer bg-white"
            >
              <span>← Trang chủ</span>
            </button>
            <div className="w-px h-5 bg-slate-200" />
            <div className="flex items-center gap-1.5">
              <div className="p-1 text-blue-500">
                <FileText className="w-4 h-4" />
              </div>
              <h1 className="text-sm font-bold text-slate-800 tracking-tight">
                Sinh 3 đề biến thể
              </h1>
            </div>
          </div>

          {/* Quick status badges & API Controls */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            <button
              id="btn_toggle_api_panel"
              onClick={() => setShowKeyPanel(!showKeyPanel)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all cursor-pointer ${
                customApiKey 
                  ? "bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100" 
                  : "bg-amber-50 text-amber-800 border-amber-200 hover:bg-amber-100"
              }`}
            >
              <Key className="w-3.5 h-3.5" />
              <span>
                {customApiKey ? "API Key & Model riêng" : "API Key & Model hệ thống"}
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        
        {/* 2. API Key & Model Config Panel (Collapsible, matching reference app style) */}
        {showKeyPanel && (
          <div id="api_key_panel" className="mb-6 bg-white border border-slate-200 rounded-2xl shadow-sm p-5 transition-all animate-in fade-in duration-200">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-slate-500" />
                <h3 className="font-bold text-slate-800 text-sm">Cấu hình API Key & Mô hình AI</h3>
              </div>
              <button 
                onClick={() => setShowKeyPanel(false)}
                className="text-xs font-bold text-slate-400 hover:text-slate-600 bg-slate-100 hover:bg-slate-200 px-2 py-1 rounded-md cursor-pointer"
              >
                Đóng ×
              </button>
            </div>
            
            <p className="text-xs text-slate-600 mb-4 leading-relaxed">
              Ứng dụng hỗ trợ cả API Key hệ thống được cấp sẵn. Nếu bạn sử dụng tài khoản Google Gemini riêng, hãy nhập khóa API cá nhân của bạn và chọn mô hình mong muốn. Khóa này được lưu trực tiếp trên trình duyệt của bạn (localStorage) và gửi trực tiếp tới máy chủ Google (bỏ qua giới hạn thời gian 10s của Vercel).
            </p>

            <div className="flex flex-col gap-4">
              <div className="flex flex-col md:flex-row gap-3 items-stretch">
                {/* API Key Input */}
                <div className="relative flex-1">
                  <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">Google Gemini API Key</label>
                  <div className="relative">
                    <input
                      id="input_api_key"
                      type={showApiKey ? "text" : "password"}
                      placeholder="Dán Google Gemini API Key tại đây (AI Studio API key)..."
                      value={apiKeyInput}
                      onChange={(e) => setApiKeyInput(e.target.value)}
                      className="w-full pl-10 pr-10 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all font-mono"
                    />
                    <Key className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <button
                      type="button"
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                    >
                      {showApiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Model Selector Dropdown */}
                <div className="w-full md:w-64">
                  <label className="block text-[10px] font-bold text-slate-400 mb-1 uppercase">Mô hình AI (Model)</label>
                  <select
                    value={selectedModel}
                    onChange={(e) => setSelectedModel(e.target.value)}
                    className="w-full py-2 px-3 bg-slate-50 border border-slate-300 rounded-xl text-xs sm:text-sm focus:outline-hidden focus:border-emerald-500 focus:bg-white transition-all font-medium text-slate-700 cursor-pointer"
                  >
                    <option value="gemini-2.5-flash">Gemini 2.5 Flash (Mặc định - Cực nhanh)</option>
                    <option value="gemini-1.5-flash">Gemini 1.5 Flash (Tốc độ ổn định)</option>
                    <option value="gemini-2.5-pro">Gemini 2.5 Pro (Chất lượng cao - Chậm hơn)</option>
                    <option value="gemini-1.5-pro">Gemini 1.5 Pro (Sâu sắc - Chậm hơn)</option>
                  </select>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 justify-end">
                <button
                  id="btn_test_key"
                  onClick={handleTestApiKey}
                  disabled={isVerifyingKey}
                  className="px-4 py-2 text-xs bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 font-medium rounded-xl transition-colors flex items-center gap-2 cursor-pointer"
                >
                  {isVerifyingKey ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                  Kiểm tra
                </button>
                <button
                  id="btn_save_key"
                  onClick={handleSaveApiKey}
                  className="px-4 py-2 text-xs bg-emerald-600 hover:bg-emerald-700 text-white font-medium rounded-xl transition-colors cursor-pointer"
                >
                  Lưu Cấu Hình
                </button>
                {customApiKey && (
                  <button
                    id="btn_delete_key"
                    onClick={handleDeleteApiKey}
                    className="p-2 text-red-600 hover:bg-red-50 border border-red-200 rounded-xl transition-colors cursor-pointer"
                    title="Xóa API Key"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {keyVerificationStatus.tested && (
              <div className={`mt-3 p-3 rounded-xl border flex items-start gap-2 text-xs ${
                keyVerificationStatus.success 
                  ? "bg-emerald-50 text-emerald-800 border-emerald-100" 
                  : "bg-red-50 text-red-800 border-red-100"
              }`}>
                {keyVerificationStatus.success ? (
                  <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                )}
                <span>{keyVerificationStatus.message}</span>
              </div>
            )}
          </div>
        )}

        {/* 3. Main content area switcher */}
        {isLoading && (
          /* Loading Overlay State */
          <div id="loader_variants" className="bg-white border border-slate-200 rounded-3xl p-12 shadow-xs text-center flex flex-col items-center justify-center min-h-[450px] max-w-4xl mx-auto">
            <div className="relative mb-6">
              <div className="w-20 h-20 rounded-full border-4 border-emerald-100 border-t-emerald-600 animate-spin" />
              <Sparkles className="w-8 h-8 text-emerald-500 absolute top-6 left-6 animate-pulse" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Hệ thống AI đang khởi tạo 3 đề thi</h3>
            <p id="loader_status_message" className="text-sm text-emerald-600 font-semibold px-4 py-2 bg-emerald-50 rounded-xl max-w-xl transition-all duration-300">
              {loadingMessage}
            </p>
            <div className="mt-8 flex flex-col items-center gap-1.5 text-xs text-slate-400 max-w-md">
              <span className="font-bold flex items-center gap-1">
                <Info className="w-3.5 h-3.5" /> Quy trình sinh đề tự động
              </span>
              <span>Gemini sẽ nhận diện tài liệu, trích xuất ma trận câu hỏi và biên soạn 3 biến thể đề thi kèm đáp án chi tiết.</span>
            </div>
          </div>
        )}

        {!isLoading && !generatedData && (
          /* Landing Page: matching User's screenshots */
          <div id="landing_page" className="max-w-3xl mx-auto flex flex-col items-center mt-10">
            {/* Header Title */}
            <div className="text-center mb-8">
              <h2 className="text-3xl font-extrabold text-slate-800 tracking-tight sm:text-4xl">
                Sinh <span className="text-blue-600">3 đề biến thể</span> từ 1 đề gốc
              </h2>
              <p className="mt-3.5 text-xs sm:text-sm text-slate-500 max-w-xl mx-auto leading-relaxed">
                Tải lên đề gốc (PDF/Ảnh). Hệ thống sẽ tự động sinh 3 đề biến thể kèm đáp án chi tiết theo quy trình 3 bước.
              </p>
            </div>

            {/* Drag & Drop Upload Container */}
            <div className="w-full bg-white border border-slate-200 rounded-3xl p-6 shadow-xs flex flex-col items-center">
              
              <div 
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => {
                  if (!uploadedFile) {
                    document.getElementById("file_picker")?.click();
                  }
                }}
                className={`w-full border rounded-2xl p-8 flex flex-col items-center justify-center transition-all duration-200 cursor-pointer ${
                  uploadedFile 
                    ? "border-emerald-200 bg-emerald-50/15" 
                    : isDragging 
                      ? "border-emerald-400 bg-emerald-50 border-dashed" 
                      : "border-slate-300 border-dashed hover:border-emerald-400 hover:bg-slate-50/50"
                }`}
              >
                <input 
                  id="file_picker"
                  type="file"
                  className="hidden"
                  accept=".pdf,image/png,image/jpeg,image/jpg"
                  onChange={handleFileChange}
                />

                {uploadedFile ? (
                  /* Custom uploaded file view matching user screenshot 2 */
                  <div className="flex items-center justify-between w-full p-2 relative">
                    <div className="flex items-center gap-3">
                      <div className="p-3 bg-emerald-100 text-[#059669] rounded-xl flex items-center justify-center">
                        <FileText className="w-7 h-7" />
                      </div>
                      <div className="flex flex-col text-left">
                        <span className="font-bold text-slate-800 text-sm max-w-md break-all">
                          {uploadedFile.name}
                        </span>
                        <span className="text-[10px] text-teal-600 font-semibold mt-0.5">
                          Đã tải lên - Click xóa để chọn file khác
                        </span>
                      </div>
                    </div>
                    
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleClearFile();
                      }}
                      className="p-1.5 text-slate-400 hover:text-red-500 rounded-full hover:bg-slate-100 transition-all cursor-pointer"
                      title="Xóa tệp"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  /* Standard dashed upload instructions matching user screenshot 1 */
                  <div className="flex flex-col items-center text-center">
                    <div className="p-3.5 bg-emerald-50 text-[#059669] rounded-full mb-3 flex items-center justify-center">
                      <Upload className="w-6 h-6" />
                    </div>
                    <span className="font-bold text-slate-700 text-sm">
                      Kéo thả đề gốc vào đây
                    </span>
                    <span className="text-xs text-slate-400 mt-0.5">
                      Hỗ trợ PDF, JPG, PNG
                    </span>
                    <span className="text-[10px] text-slate-400 mt-2 bg-slate-50 px-2.5 py-0.5 rounded-full border border-slate-200">
                      Hỗ trợ PDF, JPG, PNG (Max 20MB)
                    </span>
                  </div>
                )}
              </div>

              {/* Start Process Button (Changes styling based on uploadedFile status) */}
              <button
                id="btn_start_process"
                onClick={handleGenerateVariants}
                disabled={!uploadedFile}
                className={`w-full mt-5 py-3 px-4 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-3xs ${
                  uploadedFile
                    ? "bg-[#059669] hover:bg-[#047857] text-white active:scale-98"
                    : "bg-[#d1d5db] text-[#4b5563] cursor-not-allowed opacity-75"
                }`}
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>BẮT ĐẦU QUY TRÌNH 3 BƯỚC</span>
              </button>

              {/* Mock Test Button */}
              <button
                id="btn_generate_mock"
                onClick={handleLoadMockData}
                className="w-full mt-3 py-2.5 px-4 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-600 font-semibold rounded-xl text-xs transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>🧪 Sử dụng đề thi mẫu (Trải nghiệm nhanh không cần API Key)</span>
              </button>

              {error && (
                <div className="w-full mt-4 p-3 rounded-xl bg-red-50 border border-red-100 text-red-800 text-xs flex items-start gap-2 leading-relaxed animate-shake">
                  <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{error}</span>
                </div>
              )}
            </div>

            {/* Bottom 3 cards of the process pipeline */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 w-full mt-10">
              <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-3xs flex flex-col items-center text-center">
                <div className="w-9 h-9 rounded-full bg-[#047857] text-white font-bold flex items-center justify-center text-xs mb-2.5">
                  1
                </div>
                <span className="text-xs font-bold text-slate-800">Đề 1 + Đáp án</span>
              </div>
              <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-3xs flex flex-col items-center text-center">
                <div className="w-9 h-9 rounded-full bg-[#047857] text-white font-bold flex items-center justify-center text-xs mb-2.5">
                  2
                </div>
                <span className="text-xs font-bold text-slate-800">Đề 2 + Đáp án</span>
              </div>
              <div className="bg-white border border-slate-200/80 rounded-2xl p-5 shadow-3xs flex flex-col items-center text-center">
                <div className="w-9 h-9 rounded-full bg-[#047857] text-white font-bold flex items-center justify-center text-xs mb-2.5">
                  3
                </div>
                <span className="text-xs font-bold text-slate-800">Đề 3 + Đáp án</span>
              </div>
            </div>
          </div>
        )}

        {!isLoading && generatedData && (
          /* Results View: Full-width matching User's screenshot 3 */
          <div id="results_container" className="flex flex-col gap-6 transition-all animate-in fade-in duration-300 w-full">
            
            {/* Centered Pill progress bar & Word download */}
            <div className="flex items-center justify-between bg-white border border-slate-200 rounded-full shadow-3xs px-6 py-2.5 max-w-2xl mx-auto w-full">
              <div className="flex items-center gap-3">
                {/* Step 1 */}
                <div className="flex items-center gap-1 text-[#059669] font-bold text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Đề 1</span>
                </div>
                <ChevronRight className="w-3 h-3 text-slate-300" />
                
                {/* Step 2 */}
                <div className="flex items-center gap-1 text-[#059669] font-bold text-xs">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Đề 2</span>
                </div>
                <ChevronRight className="w-3 h-3 text-slate-300" />
                
                {/* Step 3 */}
                <div className="flex items-center gap-1.5 text-blue-600 font-bold text-xs">
                  <span className="w-4 h-4 flex items-center justify-center rounded-full bg-blue-100 text-blue-600 text-[10px] font-bold">3</span>
                  <span>Đề 3</span>
                </div>
              </div>

              {/* Combined Word Download Button */}
              <button
                id="btn_download_all"
                onClick={handleDownloadAllCombined}
                className="flex items-center gap-1.5 px-4 py-1.5 bg-[#059669] hover:bg-[#047857] text-white text-xs font-bold rounded-full transition-all shadow-3xs cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Word (.docx)</span>
              </button>
            </div>

            {/* Analysis Dashboard Details */}
            <div id="analysis_dashboard" className="bg-white border border-slate-200 rounded-3xl p-5 shadow-3xs max-w-4xl mx-auto w-full">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-2 mb-3">
                <Layers className="w-4 h-4 text-[#059669]" />
                <h3 className="font-bold text-slate-800 text-xs uppercase">Phân Tích Ma Trận Đề Gốc</h3>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/50">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Môn học</span>
                  <span className="font-bold text-slate-800 block mt-0.5">{generatedData.analysis.subject}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/50">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Đối tượng</span>
                  <span className="font-bold text-slate-800 block mt-0.5">{generatedData.analysis.grade}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/50">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Số câu hỏi</span>
                  <span className="font-bold text-slate-800 block mt-0.5">{generatedData.analysis.totalQuestions} câu ({generatedData.analysis.totalParts} phần)</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/50">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase">Độ khó</span>
                  <span className="font-bold text-emerald-600 block mt-0.5">{generatedData.analysis.difficulty}</span>
                </div>
              </div>
            </div>

            {/* Three Columns side-by-side matching screenshot 3 */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-4 w-full">
              
              {/* Column 1: Variant 1 */}
              <div className="flex flex-col gap-2">
                <div className="text-center font-bold text-[11px] text-teal-600 tracking-wider">
                  BƯỚC 1: ĐỀ & ĐÁP ÁN ĐỀ 1
                </div>
                <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-3xs flex flex-col h-[600px] overflow-y-auto text-xs font-sans leading-relaxed text-slate-700 select-all">
                  
                  {/* Exam content lines */}
                  <div className="flex flex-col">
                    {generatedData.variant1.examContent.split("\n").map((line, idx) => renderExamLine(line, idx))}
                  </div>

                  {/* Separator */}
                  <div className="my-6 border-t border-dashed border-slate-200" />

                  {/* Answers */}
                  <div className="font-bold text-slate-800 text-xs mb-3.5 uppercase text-teal-700">
                    Phần 2: Đáp án & giải thích đề số 1
                  </div>
                  <div className="flex flex-col font-mono text-slate-600 gap-1">
                    {generatedData.variant1.answers.split("\n").map((line, idx) => (
                      <div key={idx}>{line}</div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Column 2: Variant 2 */}
              <div className="flex flex-col gap-2">
                <div className="text-center font-bold text-[11px] text-teal-600 tracking-wider">
                  BƯỚC 2: ĐỀ & ĐÁP ÁN ĐỀ 2
                </div>
                <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-3xs flex flex-col h-[600px] overflow-y-auto text-xs font-sans leading-relaxed text-slate-700 select-all">
                  
                  {/* Exam content lines */}
                  <div className="flex flex-col">
                    {generatedData.variant2.examContent.split("\n").map((line, idx) => renderExamLine(line, idx))}
                  </div>

                  {/* Separator */}
                  <div className="my-6 border-t border-dashed border-slate-200" />

                  {/* Answers */}
                  <div className="font-bold text-slate-800 text-xs mb-3.5 uppercase text-teal-700">
                    Phần 2: Đáp án & giải thích đề số 2
                  </div>
                  <div className="flex flex-col font-mono text-slate-600 gap-1">
                    {generatedData.variant2.answers.split("\n").map((line, idx) => (
                      <div key={idx}>{line}</div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Column 3: Variant 3 */}
              <div className="flex flex-col gap-2">
                <div className="text-center font-bold text-[11px] text-teal-600 tracking-wider">
                  BƯỚC 3: ĐỀ & ĐÁP ÁN ĐỀ 3
                </div>
                <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-3xs flex flex-col h-[600px] overflow-y-auto text-xs font-sans leading-relaxed text-slate-700 select-all">
                  
                  {/* Exam content lines */}
                  <div className="flex flex-col">
                    {generatedData.variant3.examContent.split("\n").map((line, idx) => renderExamLine(line, idx))}
                  </div>

                  {/* Separator */}
                  <div className="my-6 border-t border-dashed border-slate-200" />

                  {/* Answers */}
                  <div className="font-bold text-slate-800 text-xs mb-3.5 uppercase text-teal-700">
                    Phần 2: Đáp án & giải thích đề số 3
                  </div>
                  <div className="flex flex-col font-mono text-slate-600 gap-1">
                    {generatedData.variant3.answers.split("\n").map((line, idx) => (
                      <div key={idx}>{line}</div>
                    ))}
                  </div>
                </div>
              </div>

            </div>

          </div>
        )}

      </main>

      {/* 5. Footer Section */}
      <footer className="mt-16 py-6 border-t border-slate-200 text-center text-xs text-slate-500 max-w-[1600px] mx-auto px-4">
        <p className="font-medium text-slate-600">
          Sinh 3 đề Tiếng Anh THCS v2.5
        </p>
        <p className="mt-1 text-slate-400">
          Thông tin bản quyền: Đinh Thành - 0915.213717
        </p>
      </footer>
    </div>
  );
}
