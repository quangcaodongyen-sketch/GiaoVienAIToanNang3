import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "25mb" })); // Increase limit to support base64 file payloads

// Helper function to initialize Gemini safely
function getGeminiClient(customApiKey?: string) {
  const apiKey = customApiKey || process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("Không tìm thấy API Key. Vui lòng nhập API Key Gemini của bạn để bắt đầu.");
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// 1. API endpoint to test the API key
app.post("/api/check-key", async (req, res) => {
  const { customApiKey, selectedModel } = req.body;
  try {
    const ai = getGeminiClient(customApiKey);
    const response = await ai.models.generateContent({
      model: selectedModel || "gemini-2.5-flash",
      contents: "Respond with only 'OK' if you can read this.",
    });
    
    const text = response.text;
    if (text) {
      return res.json({ success: true, message: "API Key hoạt động chính xác!" });
    }
    return res.status(400).json({ success: false, message: "Không nhận được phản hồi từ AI." });
  } catch (error: any) {
    console.error("Lỗi kiểm tra API Key:", error);
    return res.status(400).json({ 
      success: false, 
      message: error.message || "API Key không hợp lệ hoặc không có quyền truy cập." 
    });
  }
});

// 2. API endpoint to generate 3 variants from the original exam (supporting multimodal base64)
app.post("/api/generate", async (req, res) => {
  const { originalExam, fileData, customApiKey, selectedModel } = req.body;
  
  if ((!originalExam || originalExam.trim() === "") && !fileData) {
    return res.status(400).json({ success: false, message: "Vui lòng nhập nội dung hoặc tải lên file đề thi gốc." });
  }

  try {
    const ai = getGeminiClient(customApiKey);
    
    const systemInstruction = `Bạn là chuyên gia ra đề kiểm tra Tiếng Anh THCS (Trung học cơ sở, từ Lớp 6 đến Lớp 9). 
Hãy tạo đúng 3 đề kiểm tra biến thể khác nhau từ đề gốc do giáo viên cung cấp.
Giữ nguyên cấu trúc đề gốc bao gồm: số phần, số câu, dạng câu hỏi, mức độ khó, và ma trận kiến thức.
Không tạo câu hỏi vượt quá trình độ học sinh THCS. Mỗi đề phải có phần đề thi và đáp án đầy đủ.

Quy tắc đặt tiêu đề (Mã đề):
- Tuyệt đối KHÔNG ghi các chữ như "Biến thể nhẹ", "Biến thể trung bình", "Biến thể mới hơn", "Đề 1", "Đề 2", "Đề 3" vào trong tiêu đề hoặc nội dung đề thi.
- Thay vào đó, hãy dựa vào Lớp học của đề gốc để sinh mã đề tương ứng trong kết quả JSON (ví dụ: Lớp 6 thì ghi ĐỀ SỐ 601, ĐỀ SỐ 602, ĐỀ SỐ 603; Lớp 7 thì ghi ĐỀ SỐ 701, ĐỀ SỐ 702, ĐỀ SỐ 703; Lớp 8 thì ghi ĐỀ SỐ 801, ĐỀ SỐ 802, ĐỀ SỐ 803; Lớp 9 thì ghi ĐỀ SỐ 901, ĐỀ SỐ 902, ĐỀ SỐ 903).
- Tiêu đề (title) của 3 đề thi trong kết quả JSON lần lượt là "ĐỀ SỐ [Grade]01", "ĐỀ SỐ [Grade]02", "ĐỀ SỐ [Grade]03" (Ví dụ: "ĐỀ SỐ 801" nếu đề gốc được xác định là Lớp 8).

Quy tắc nội dung đáp án (Answers):
- Phần đáp án (answers) phải đầy đủ và chi tiết cho tất cả các câu hỏi trắc nghiệm và tự luận.
- Nếu đề thi có phần nghe (Listening): BẮT BUỘC phải đính kèm nội dung băng nghe nghe chi tiết (Audio Script / Listening Script) vào ngay trước phần đáp án của đề đó.
- Nếu đề thi có phần viết (Writing): BẮT BUỘC cung cấp đoạn văn/bài viết mẫu hoàn chỉnh chi tiết (không ghi dàn ý chung chung).
- Nếu đề thi có phần nói (Speaking): BẮT BUỘC cung cấp chi tiết cả câu hỏi gợi ý và câu trả lời mẫu đầy đủ cho học sinh.

Quy tắc sinh đề và định dạng đặc biệt bắt buộc:
- Không sao chép y nguyên câu hỏi gốc.
- Thay đổi tên người, địa danh, đồ vật, tình huống hoặc đổi từ vựng/ngữ pháp tương đương.
- Giữ nguyên dạng bài (ví dụ: Multiple Choice, Reading, Writing, Listening script nếu có).
- Mỗi câu trắc nghiệm có 4 đáp án A, B, C, D nếu đề gốc có 4 đáp án. Chỉ có đúng 1 đáp án đúng cho mỗi câu.
- Đáp án phải khớp chính xác với câu hỏi.
- KHÔNG sử dụng bảng biểu (table) cho phần văn bản trong đề thi (ví dụ: câu hỏi, bài đọc, câu trắc nghiệm), để tránh việc khó căn chỉnh khi tải về. Chỉ dùng văn bản thuần.
- Trong phần câu hỏi trắc nghiệm A, B, C, D: Nếu các phương án trả lời ngắn (khoảng 1-3 từ), hãy trình bày chung trên 1 dòng với khoảng cách hợp lý (ví dụ: A. cat      B. dog      C. bird      D. fish) với khoảng cách tối thiểu 6-8 dấu cách giữa các phương án. Nếu các phương án dài hơn, hãy chia thành 2 dòng (A, B trên dòng 1; C, D trên dòng 2). Chỉ viết mỗi phương án trên một dòng khi đáp án rất dài hoặc chứa câu hoàn chỉnh.
- Đối với các môn hoặc câu hỏi có công thức toán học/khoa học, hãy viết đúng định dạng ký tự toán học chuẩn Unicode (ví dụ: dùng x², √y, ±, etc.) để hiển thị và xuất Word không bị lỗi công thức.
- Không tự ý thêm tên xã, tên trường cụ thể vào đề thi để đảm bảo tính tổng quát (chỉ dùng các phần trống như TRƯỜNG THCS: ....................).
- Không tạo nội dung nhạy cảm, chính trị, bạo lực.
- Ngôn ngữ phù hợp học sinh lớp 6, 7, 8, 9.

Mức độ biến thể của 3 đề:
- Đề 1 (Biến thể nhẹ): Đổi từ vựng, ngữ cảnh, tên riêng hoặc tình huống đơn giản nhưng giữ nguyên cấu trúc ngữ pháp và kiểu câu hỏi.
- Đề 2 (Biến thể trung bình): Đổi câu hỏi và ngữ cảnh nhiều hơn, sử dụng các cấu trúc ngữ pháp tương đương cùng mức độ, nội dung bài đọc được viết lại mới.
- Đề 3 (Biến thể mới hơn): Kiểm tra cùng một lượng kiến thức, chủ đề và điểm ngữ pháp nhưng đổi mới hoàn toàn câu hỏi và bài tập, không trùng câu với đề gốc hay đề 1, 2.

Đảm bảo kết quả trả về bằng tiếng Việt dễ hiểu cho giáo viên, nhưng phần nội dung đề thi và đáp án tiếng Anh phải chuẩn ngữ pháp, tự nhiên và chính xác.`;

    let contents: any[] = [];
    if (fileData && fileData.base64) {
      const base64Data = fileData.base64.split(",")[1] || fileData.base64;
      contents.push({
        inlineData: {
          data: base64Data,
          mimeType: fileData.mimeType
        }
      });
      contents.push({
        text: `Dưới đây là tệp tin đề thi gốc do giáo viên tải lên.
Hãy đọc kỹ tệp tin này, nhận diện toàn bộ nội dung đề thi (bao gồm các phần trắc nghiệm, tự luận, bài đọc, câu hỏi và đáp án nếu có).
Sau đó, tiến hành phân tích ma trận kiến thức của đề gốc này: Xác định số phần, số câu, dạng câu hỏi, mức độ khó, chủ đề từ vựng và ngữ pháp.
Tiếp theo, hãy sinh ra đúng 3 đề kiểm tra biến thể tương ứng theo đúng các quy tắc sinh đề và định dạng đặc biệt bắt buộc ở phần hướng dẫn hệ thống:
- Đề 1 (Mã đề Grade 01)
- Đề 2 (Mã đề Grade 02)
- Đề 3 (Mã đề Grade 03)

Mỗi đề biến thể bắt buộc phải có đầy đủ 2 phần chính được viết rõ ràng trong văn bản:
PHẦN 1: ĐỀ THI
[Toàn bộ đề thi]

PHẦN 2: ĐÁP ÁN
[Mã đề tương ứng, Audio Script, bài viết mẫu chi tiết, bài nói mẫu chi tiết và đáp án tự luận/trắc nghiệm]

Vui lòng trả về kết quả dưới dạng JSON theo đúng cấu trúc của responseSchema.`
      });
    } else {
      contents.push({
        text: `Dưới đây là đề thi gốc do giáo viên cung cấp:
---
${originalExam}
---

Hãy phân tích đề thi gốc này: Xác định số phần, số câu, dạng câu hỏi, mức độ khó, chủ đề từ vựng và ngữ pháp.
Sau đó, sinh ra 3 đề biến thể tương ứng:
- Đề 1 (Mã đề Grade 01)
- Đề 2 (Mã đề Grade 02)
- Đề 3 (Mã đề Grade 03)

Mỗi đề biến thể bắt buộc phải có đầy đủ 2 phần chính được viết rõ ràng trong văn bản:
PHẦN 1: ĐỀ THI
[Toàn bộ đề thi]

PHẦN 2: ĐÁP ÁN
[Mã đề tương ứng, Audio Script, bài viết mẫu chi tiết, bài nói mẫu chi tiết và đáp án tự luận/trắc nghiệm]

Vui lòng trả về kết quả dưới dạng JSON theo đúng cấu trúc của responseSchema.`
      });
    }

    const response = await ai.models.generateContent({
      model: selectedModel || "gemini-2.5-flash",
      contents,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: {
              type: Type.OBJECT,
              properties: {
                subject: { type: Type.STRING },
                grade: { type: Type.STRING },
                totalQuestions: { type: Type.STRING },
                totalParts: { type: Type.STRING },
                skillsTested: { type: Type.STRING },
                difficulty: { type: Type.STRING }
              },
              required: ["subject", "grade", "totalQuestions", "totalParts", "skillsTested", "difficulty"]
            },
            variant1: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                examContent: { type: Type.STRING },
                answers: { type: Type.STRING }
              },
              required: ["title", "examContent", "answers"]
            },
            variant2: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                examContent: { type: Type.STRING },
                answers: { type: Type.STRING }
              },
              required: ["title", "examContent", "answers"]
            },
            variant3: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                examContent: { type: Type.STRING },
                answers: { type: Type.STRING }
              },
              required: ["title", "examContent", "answers"]
            }
          },
          required: ["analysis", "variant1", "variant2", "variant3"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Không nhận được nội dung sinh từ Gemini.");
    }

    const data = JSON.parse(text);
    return res.json({ success: true, data });
  } catch (error: any) {
    console.error("Lỗi sinh đề biến thể:", error);
    return res.status(500).json({ 
      success: false, 
      message: error.message || "Có lỗi xảy ra khi xử lý yêu cầu của bạn từ hệ thống Gemini." 
    });
  }
});

// Vite middleware setup
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://localhost:${PORT}`);
  });
}

startServer();
