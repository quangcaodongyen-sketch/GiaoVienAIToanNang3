/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
app.use(express.json({ limit: "20mb" }));

// Initialize the Google GenAI client safely with environment variable
const geminiApiKey = process.env.GEMINI_API_KEY;

let ai: GoogleGenAI | null = null;
if (geminiApiKey) {
  ai = new GoogleGenAI({
    apiKey: geminiApiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

// Helper to clean up and translate raw Gemini API error messages to Vietnamese
function getCleanErrorMessage(error: any): string {
  const message = error?.message || String(error);
  try {
    if (message.startsWith("{") && message.endsWith("}")) {
      const parsed = JSON.parse(message);
      if (parsed?.error) {
        const subMsg = parsed.error.message || "";
        const status = parsed.error.status || "";
        const code = parsed.error.code;
        
        if (subMsg.includes("high demand") || status === "UNAVAILABLE" || code === 503) {
          return "Mô hình AI hiện đang quá tải do lượng truy cập tăng cao đột biến. Vui lòng nhấn nút 'Chuẩn hóa' để thử lại sau vài giây.";
        }
        if (subMsg.includes("Quota exceeded") || subMsg.includes("exhausted") || code === 429) {
          return "Đã vượt quá hạn mức sử dụng API (Rate limit/Quota exceeded). Vui lòng thử lại sau một lát.";
        }
        if (subMsg.includes("API key not valid") || subMsg.includes("key is invalid") || subMsg.includes("API key") || code === 400) {
          return "Mã khóa API (GEMINI_API_KEY) không hợp lệ hoặc đã hết hạn. Vui lòng kiểm tra lại cấu hình.";
        }
        return `Lỗi từ hệ thống AI (Mã ${code || "không rõ"}): ${subMsg}`;
      }
    }
  } catch (e) {
    // Ignore parse error and fallback to standard checks
  }

  if (message.includes("503") || message.includes("UNAVAILABLE") || message.includes("high demand")) {
    return "Mô hình AI hiện đang quá tải do lượng truy cập tăng cao đột biến. Vui lòng nhấn nút 'Chuẩn hóa' để thử lại sau vài giây.";
  }
  if (message.includes("429") || message.includes("quota") || message.includes("LimitExceeded") || message.includes("exhausted")) {
    return "Hệ thống AI tạm thời hết hạn ngạch yêu cầu. Vui lòng thử lại sau ít phút.";
  }
  if (message.includes("API key") || message.includes("key is invalid")) {
    return "Cấu hình API Key (GEMINI_API_KEY) không chính xác hoặc không hoạt động. Vui lòng kiểm tra cài đặt secrets.";
  }

  return message;
}

// Wrapper with automatic retry with backoff for transient Gemini API errors (like 503/429)
// It will also automatically fallback to alternative models if a model is completely overloaded/unavailable.
async function generateContentWithRetry(aiClient: GoogleGenAI, params: any, retries = 3, delayMs = 1500) {
  let lastError;
  const originalModel = params.model || "gemini-3.5-flash";
  const fallbackModels = ["gemini-2.5-flash", "gemini-1.5-flash", "gemini-2.5-pro", "gemini-1.5-pro"];
  const modelsToTry = [originalModel, ...fallbackModels.filter(m => m !== originalModel)];

  for (const currentModel of modelsToTry) {
    let currentDelay = delayMs;
    params.model = currentModel;
    console.log(`[Gemini API] Đang chuẩn bị yêu cầu với mô hình: ${currentModel}`);
    
    for (let attempt = 1; attempt <= retries; attempt++) {
      try {
        return await aiClient.models.generateContent(params);
      } catch (err: any) {
        lastError = err;
        const errMsg = err?.message || String(err);
        
        const isTransient = 
          errMsg.includes("503") || 
          errMsg.includes("UNAVAILABLE") || 
          errMsg.includes("high demand") || 
          errMsg.includes("429") || 
          errMsg.includes("RESOURCE_EXHAUSTED") ||
          errMsg.includes("exhausted") ||
          err?.status === "UNAVAILABLE" ||
          err?.code === 503 ||
          err?.code === 429;
          
        if (isTransient && attempt < retries) {
          console.warn(`[Gemini API] Lượt thử ${attempt} cho mô hình ${currentModel} thất bại do lỗi tạm thời: ${errMsg}. Đang thử lại sau ${currentDelay}ms...`);
          await new Promise((resolve) => setTimeout(resolve, currentDelay));
          currentDelay *= 2; // Exponential backoff
        } else {
          console.error(`[Gemini API] Mô hình ${currentModel} gặp lỗi: ${errMsg}. Đang kiểm tra xem có mô hình thay thế khác không...`);
          break; // break retry loop to try the next fallback model
        }
      }
    }
  }
  throw lastError;
}

// API to check server status & API Key presence
app.get("/api/config", (req, res) => {
  res.json({
    hasApiKey: !!geminiApiKey,
    nodeEnv: process.env.NODE_ENV || "development",
  });
});

// Main standardization API endpoint using Gemini 3.5 Flash with structured JSON schema
app.post("/api/gemini/standardize", async (req, res) => {
  try {
    const { text, mode, options } = req.body;
    const clientApiKey = req.headers["x-gemini-key"] || req.body.userGeminiApiKey || options?.userGeminiApiKey;

    if (!text || text.trim() === "") {
      return res.status(400).json({ error: "Nội dung văn bản trống." });
    }

    let requestAi = ai;
    if (clientApiKey && typeof clientApiKey === "string" && clientApiKey.trim() !== "") {
      requestAi = new GoogleGenAI({
        apiKey: clientApiKey.trim(),
        httpOptions: {
          headers: {
            "User-Agent": "aistudio-build",
          },
        },
      });
    }

    if (!requestAi) {
      return res.status(500).json({
        error: "Gemini API Key chưa được cấu hình. Vui lòng thiết lập biến môi trường GEMINI_API_KEY hoặc điền API Key cá nhân trong phần Cấu hình.",
      });
    }

    const editMode = mode || "standard"; // light, standard, expert

    // Build model prompt based on the chosen mode
    let modeGuideline = "";
    if (editMode === "light") {
      modeGuideline = `Chế độ: SỬA NHẸ. Chỉ sửa lỗi chính tả hiển nhiên, lỗi dấu câu, khoảng trắng và lỗi viết hoa sai quy tắc hành chính. Giữ nguyên 99% cấu trúc câu và diễn đạt gốc. Tuyệt đối không viết lại câu hay rút gọn văn bản.`;
    } else if (editMode === "standard") {
      modeGuideline = `Chế độ: CHUẨN HÓA HÀNH CHÍNH (Mặc định). Phân tích cấu trúc, nhận diện loại văn bản, sửa tất cả lỗi chính tả, viết hoa, viết tắt, ngữ pháp, chuẩn hóa thể thức hành chính Việt Nam theo Nghị định 30/2020/NĐ-CP, sắp xếp lại các khối và phần tử của văn bản đúng vị trí thể thức hành chính, phân loại các mục rõ ràng.`;
    } else if (editMode === "expert") {
      modeGuideline = `Chế độ: BIÊN TẬP CHUYÊN SÂU. Sửa toàn bộ lỗi chính tả, thể thức như chế độ Chuẩn hóa hành chính. Ngoài ra, hãy viết lại những câu văn rườm rà, lặp ý, cải thiện văn phong hành chính để trang trọng, mạch lạc và súc tích hơn. Đề xuất các tiêu đề mục hoặc tóm tắt hợp lý hơn nếu cấu trúc gốc quá rời rạc, nhưng tuyệt đối phải giữ nguyên toàn bộ số liệu, tên người, ngày tháng và ý nghĩa cốt lõi.`;
    }

    const systemInstruction = `Bạn là chuyên gia văn thư, lưu trữ, ngôn ngữ tiếng Việt và thể thức văn bản hành chính Việt Nam theo Nghị định số 30/2020/NĐ-CP.

Nhiệm vụ của bạn là nhận diện, phân tích lỗi, chuẩn hóa nội dung, chuẩn hóa ngữ pháp/chính tả và tái cấu trúc văn bản đầu vào thành một cấu trúc văn bản hành chính Việt Nam hoàn chỉnh, chuẩn xác.

ÁP DỤNG CÁC QUY TẮC PHÁP LÝ TỪ NGHỊ ĐỊNH 30/2020/NĐ-CP:
1. Thể thức các khối đầu trang:
   - Khối trái: Cơ quan chủ quản (nếu có, chữ thường viết đứng), tên Cơ quan ban hành (chữ in hoa đậm, đứng), Số và ký hiệu văn bản (vd: "Số: 15/BC-THCSĐY" hoặc "Số: .../KH-...").
   - Khối phải: Quốc hiệu ("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", in hoa đậm), Tiêu ngữ ("Độc lập - Tự do - Hạnh phúc", chữ thường viết hoa đầu từ, đậm, có đường kẻ ngang mảnh bên dưới rộng bằng tiêu ngữ), Địa danh và Ngày tháng năm ban hành (vd: "Đồng Yên, ngày 20 tháng 7 năm 2026", in nghiêng).
2. Tiêu đề văn bản:
   - Tên loại văn bản (vd: BÁO CÁO, KẾ HOẠCH, QUYẾT ĐỊNH, THÔNG BÁO) in hoa đậm, đứng.
   - Trích yếu nội dung văn bản in thường đậm đứng (nếu có loại văn bản) hoặc in thường đứng nghiêng (nếu là công văn).
3. Đánh số mục nội dung:
   - Sử dụng thống nhất hệ thống đánh số phân cấp: I., II., III... (La Mã) -> 1., 2., 3... (Số thường) -> a), b), c)... (Chữ thường). Không được pha trộn sai quy cách (tránh kiểu 1, hoặc 1) hoặc I/).
4. Nơi nhận (khối trái cuối trang):
   - Chữ "Nơi nhận:" in đậm nghiêng. Các dòng nơi nhận cụ thể bắt đầu bằng gạch đầu dòng "-", kết thúc bằng dấu chấm phẩy ";". Dòng cuối cùng là "- Lưu: VT." hoặc tương tự.
5. Khối ký tên (khối phải cuối trang):
   - Chức vụ người ký (vd: "HIỆU TRƯỞNG", "CHỦ TỊCH") viết in hoa, in đậm. Họ tên người ký ở dòng cuối in đậm, đứng thường. Chừa trống dòng giữa để ký tên.
6. Bảo toàn dữ liệu:
   - Giữ nguyên tất cả các số liệu, thống kê, tên riêng, tên người, địa danh, ngày tháng thực tế, trừ lỗi chính tả/gõ dấu hiển nhiên. Không được bịa đặt thành tích hoặc tự tạo số liệu mới.
7. Xử lý thông tin thiếu:
   - Nếu thiếu ngày tháng, địa danh, số văn bản, người ký, chức vụ: Đặt các giá trị này là "..." hoặc để trống, và điền vào mảng missingFields để thông báo cho người dùng bổ sung. Không tự đoán hay tự bịa thông tin.
8. Phát hiện mâu thuẫn:
   - Nếu trong văn bản có thông tin mâu thuẫn (ví dụ lúc ghi năm học 2024-2025 lúc ghi 2025-2026, hoặc số liệu tổng lệch với số liệu thành phần), hãy chỉ ra mâu thuẫn này trong mảng warnings.

Cấu hình xử lý chế độ hiện tại:
${modeGuideline}

Bạn phải phân tích văn bản đầu vào và phản hồi dưới dạng một đối tượng JSON cấu trúc chuẩn xác theo đúng Schema được cung cấp.`;

    const modelToUse = req.body.model || "gemini-3.5-flash";

    const response = await generateContentWithRetry(requestAi, {
      model: modelToUse,
      contents: text,
      config: {
        systemInstruction,
        temperature: 0.1, // Low temperature for high precision and consistent administrative output
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            documentType: {
              type: Type.STRING,
              description: "Loại văn bản nhận diện được (Báo cáo, Kế hoạch, Thông báo, Quyết định, Tờ trình, Công văn, Biên bản, Giấy mời, v.v.)"
            },
            issuingAuthority: {
              type: Type.STRING,
              description: "Tên cơ quan chủ quản cấp trên (nếu có, vd: UBND HUYỆN BẮC QUANG). Để trống nếu không tìm thấy."
            },
            issuingOrganization: {
              type: Type.STRING,
              description: "Cơ quan/đơn vị ban hành văn bản (vd: TRƯỜNG THCS ĐỒNG YÊN)."
            },
            documentNumber: {
              type: Type.STRING,
              description: "Số văn bản (chỉ lấy phần số, vd: '15'. Nếu thiếu điền '...')"
            },
            documentSymbol: {
              type: Type.STRING,
              description: "Ký hiệu văn bản (vd: 'BC-THCSĐY'. Nếu thiếu điền '...')"
            },
            place: {
              type: Type.STRING,
              description: "Địa danh ban hành văn bản (vd: 'Đồng Yên'. Nếu thiếu điền '...')"
            },
            date: {
              type: Type.OBJECT,
              properties: {
                day: { type: Type.STRING, description: "Ngày ban hành (vd: '20', nếu thiếu điền '...')" },
                month: { type: Type.STRING, description: "Tháng ban hành (vd: '7', nếu thiếu điền '...')" },
                year: { type: Type.STRING, description: "Năm ban hành (vd: '2026', nếu thiếu điền '...')" }
              },
              required: ["day", "month", "year"]
            },
            title: {
              type: Type.STRING,
              description: "Tên loại văn bản viết in hoa (vd: BÁO CÁO, KẾ HOẠCH). Với công văn hành chính thì để trống hoặc để CÔNG VĂN."
            },
            subtitle: {
              type: Type.STRING,
              description: "Trích yếu nội dung văn bản (vd: 'Về việc tổng kết công tác giáo dục năm học 2025 - 2026')"
            },
            recipients: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Mảng danh sách các đối tượng kính gửi (phần Kính gửi ở đầu văn bản, nếu có)"
            },
            preamble: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Các câu văn phần căn cứ pháp lý mở đầu hoặc đặt vấn đề trước khi vào mục chính."
            },
            sections: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  level: { type: Type.INTEGER, description: "Cấp độ mục (1 đại diện cho I, II; 2 đại diện cho 1, 2; 3 đại diện cho a, b)" },
                  number: { type: Type.STRING, description: "Ký hiệu đầu mục (vd: 'I', '1', 'a')" },
                  title: { type: Type.STRING, description: "Tiêu đề của mục đó (vd: 'ĐẶC ĐIỂM TÌNH HÌNH')" },
                  paragraphs: {
                    type: Type.ARRAY,
                    items: { type: Type.STRING },
                    description: "Các đoạn văn bản nội dung thuộc mục này."
                  }
                },
                required: ["level", "number", "title", "paragraphs"]
              },
              description: "Danh sách toàn bộ các mục nội dung trong văn bản sắp xếp theo đúng trình tự phân cấp hành chính."
            },
            closingParagraph: {
              type: Type.STRING,
              description: "Đoạn văn kết thúc văn bản trước phần ký (vd: 'Trên đây là báo cáo tổng kết...')."
            },
            signatoryTitle: {
              type: Type.STRING,
              description: "Chức vụ người ký (vd: 'HIỆU TRƯỞNG', nếu thiếu điền '...')"
            },
            signatoryName: {
              type: Type.STRING,
              description: "Họ và tên người ký (vd: 'Nguyễn Văn A', nếu thiếu điền '...')"
            },
            distributionList: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "Danh sách nơi nhận ở cuối trang (gồm các gạch đầu dòng và - Lưu: VT...)"
            },
            changes: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.INTEGER },
                  location: { type: Type.STRING, description: "Phần văn bản bị sửa (vd: 'Địa danh', 'Mục I.1', 'Nội dung')" },
                  original: { type: Type.STRING, description: "Nội dung ban đầu" },
                  corrected: { type: Type.STRING, description: "Nội dung sau khi sửa" },
                  type: { type: Type.STRING, description: "Loại lỗi: 'Chính tả', 'Dấu câu', 'Viết hoa', 'Viết tắt', 'Diễn đạt', 'Thể thức', 'Bố cục', 'Khác'" },
                  reason: { type: Type.STRING, description: "Lý do sửa, căn cứ pháp lý hoặc lỗi cụ thể" }
                },
                required: ["id", "location", "original", "corrected", "type", "reason"]
              },
              description: "Mảng thống kê chi tiết toàn bộ các điểm đã được chỉnh sửa so với văn bản gốc."
            },
            missingFields: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  field: { type: Type.STRING, description: "Tên trường bị thiếu (vd: 'documentNumber', 'date', 'signatoryName')" },
                  description: { type: Type.STRING, description: "Mô tả nội dung thiếu và yêu cầu điền." }
                },
                required: ["field", "description"]
              },
              description: "Danh sách các thành phần thể thức bắt buộc bị thiếu trong văn bản gốc."
            },
            warnings: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  type: { type: Type.STRING, description: "Loại cảnh báo mâu thuẫn (vd: 'Năm học không nhất quán', 'Số liệu mâu thuẫn')" },
                  description: { type: Type.STRING, description: "Mô tả cụ thể điểm mâu thuẫn cần người dùng tự kiểm tra." }
                },
                required: ["type", "description"]
              },
              description: "Cảnh báo mâu thuẫn dữ liệu logic phát hiện được trong văn bản."
            },
            confidenceScore: {
              type: Type.NUMBER,
              description: "Điểm tin cậy ước lượng từ 0.00 đến 1.00"
            }
          },
          required: [
            "documentType",
            "issuingAuthority",
            "issuingOrganization",
            "documentNumber",
            "documentSymbol",
            "place",
            "date",
            "title",
            "subtitle",
            "recipients",
            "preamble",
            "sections",
            "closingParagraph",
            "signatoryTitle",
            "signatoryName",
            "distributionList",
            "changes",
            "missingFields",
            "warnings",
            "confidenceScore"
          ]
        },
      },
    });

    const responseText = response.text;
    if (!responseText) {
      throw new Error("Không nhận được phản hồi từ mô hình Gemini.");
    }

    // Parse safety check
    let parsedData;
    try {
      parsedData = JSON.parse(responseText.trim());
    } catch (parseError) {
      console.error("Lỗi parse JSON gốc của Gemini:", responseText);
      // Try to extract JSON between ```json and ```
      const match = responseText.match(/```json\s*([\s\S]*?)\s*```/);
      if (match && match[1]) {
        parsedData = JSON.parse(match[1].trim());
      } else {
        throw new Error("Phản hồi từ Gemini không đúng định dạng JSON yêu cầu.");
      }
    }

    return res.json(parsedData);
  } catch (error: any) {
    console.error("Lỗi xử lý chuẩn hóa văn bản:", error);
    const cleanMsg = getCleanErrorMessage(error);
    return res.status(500).json({ error: cleanMsg });
  }
});

// Configure Vite or serving production build
async function startServer() {
  const PORT = 3000;
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
