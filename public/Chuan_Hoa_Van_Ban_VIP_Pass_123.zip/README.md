# Chuẩn Hóa Văn Bản Hành Chính AI

Ứng dụng web thông minh chuyên dụng để phân tích, sửa lỗi chính tả, chuẩn hóa từ ngữ, tái lập và cấu trúc lại toàn bộ thể thức các loại văn bản hành chính Việt Nam dựa trên **Nghị định số 30/2020/NĐ-CP** và Phụ lục kỹ thuật trình bày văn bản hành chính đi kèm.

Phát triển bởi Đinh Văn Thành - ĐT/Zalo: 0915.213717

---

## 🌟 Tính Năng Nổi Bật

1. **Chuẩn Hóa Thể Thức (Nghị định 30/2020/NĐ-CP)**: Tự động chia các phần tử của văn bản thành hai khối đầu trang (trái/phải), định vị Quốc hiệu, Tiêu ngữ, Tên loại, Trích yếu, Số/Ký hiệu, Địa danh, Ngày tháng, Khối nơi nhận và Khối chữ ký người có thẩm quyền đúng quy cách tuyệt đối.
2. **Sửa Lỗi Ngôn Ngữ Hành Chính**: Tự động sửa lỗi chính tả tiếng Việt, dấu câu, khoảng trắng, viết hoa sai quy cách, chuẩn hóa tên đơn vị hành chính và địa phương nhưng giữ nguyên tuyệt đối số liệu và ngữ cảnh gốc.
3. **Phân Tích Độc Lập Chế Độ**:
   - **Sửa Nhẹ**: Sửa lỗi chính tả & viết hoa nhỏ, giữ nguyên 99% nguyên văn.
   - **Chuẩn Hóa Hành Chính (Mặc định)**: Sắp xếp lại bố cục, phân tách các khối đầu và cuối văn bản, đánh số lại phân cấp mục lục chuẩn.
   - **Biên Tập Chuyên Sâu**: Viết lại các câu văn rườm rà lặp ý, nâng cấp văn phong trang trọng, súc tích.
4. **Trình Đọc File Word Tích Hợp (Mammoth)**: Cho phép kéo thả hoặc tải trực tiếp tệp `.docx` gốc, phân tách cấu trúc bảng biểu, tiêu đề và văn bản một cách nguyên bản để xem trước.
5. **Xuất File Word `.docx` Thật Sự**: Tạo và tải xuống tệp Microsoft Word chuẩn xác sử dụng cơ chế Bảng ẩn hai cột, bảo toàn định dạng để người dùng có thể in ấn và sử dụng ngay không bị chạy lệch dòng.
6. **So Sánh Trực Quan & Bảng Lỗi**: Giao diện tô màu so sánh chi tiết giữa bản gốc và bản đã sửa đổi, kèm theo bảng thống kê lỗi chi tiết phân loại lỗi (chính tả, thể thức, bố cục, v.v.).
7. **Trình Đánh Giá Thể Thức & Chấm Điểm**: Chạy bộ quy tắc kiểm tra tự động xem văn bản có đầy đủ thành phần bắt buộc chưa và chấm điểm độ hoàn thiện trước khi cho tải xuống.

---

## 🛠️ Công Nghệ Sử Dụng

- **Frontend**: React 19, TypeScript, Tailwind CSS, Motion (animations), Lucide Icons.
- **Backend**: Node.js (Express) tích hợp làm Server-Side Proxy cho Gemini API bảo vệ khóa bí mật.
- **AI SDK**: `@google/genai` (sử dụng dòng mô hình tối tân `gemini-3.5-flash`).
- **Xử lý Word**: `docx` (tạo tệp Word), `mammoth` (phân tích đọc tệp Word).

---

## ⚙️ Hướng Dẫn Cài Đặt và Chạy Môi Trường Local

### 1. Chuẩn Bị Môi Trường
Đảm bảo bạn đã cài đặt Node.js (phiên bản 18 trở lên).

### 2. Thiết Lập Khóa Gemini API
Tạo tệp `.env` dựa trên tệp `.env.example` và bổ sung khóa Gemini API của bạn:
```env
GEMINI_API_KEY="AIzaSy..."
```

### 3. Cài Đặt Các Gói Phụ Thuộc
```bash
npm install
```

### 4. Khởi Chạy Chế Độ Phát Triển (Development)
```bash
npm run dev
```
Ứng dụng sẽ chạy tại địa chỉ `http://localhost:3000`.

### 5. Biên Dịch Sản Phẩm (Production Build)
```bash
npm run build
```
Quá trình này sẽ biên dịch mã nguồn Client sang thư mục `dist/` và đóng gói Server TypeScript thành một tệp CommonJS duy nhất `dist/server.cjs` thông qua esbuild để chạy độc lập cực kỳ nhanh chóng.

### 6. Khởi Chạy Sản Phẩm Đã Biên Dịch
```bash
npm start
```
