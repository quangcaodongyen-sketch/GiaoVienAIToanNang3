/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  AlignmentType,
} from "docx";
import { StandardizedDocument, AppSettings } from "../types";

/**
 * Convert millimeters to dxa (twips)
 * 1 mm = 56.7 dxa
 */
const mmToDxa = (mm: number): number => {
  return Math.round(mm * 56.7);
};

export async function exportToDocx(
  docData: StandardizedDocument,
  settings: AppSettings
): Promise<Blob> {
  const fontSizeHalfPts = settings.fontSize * 2; // docx uses half-points (e.g., 14pt = 28)
  const defaultFont = "Times New Roman";

  // Margins depending on standard/custom settings (using standard margins from Decree 30)
  // Top: 20-25mm, Bottom: 20-25mm, Left: 30-35mm, Right: 15-20mm
  const topMargin = mmToDxa(20);
  const bottomMargin = mmToDxa(20);
  const leftMargin = mmToDxa(30);
  const rightMargin = mmToDxa(15);

  // Line spacing mapping
  // Decree 30 specifies line spacing of 1.0 to 1.5. Standard is usually 1.15 to 1.2
  const lineSpacingValue = Math.round(settings.lineSpacing * 240); // 240 is 1 line spacing in dxa

  // Build the Header Table (Bảng đầu trang gồm 2 cột ẩn)
  const headerRow = new TableRow({
    children: [
      // Left Column: Authority and Organ
      new TableCell({
        width: { size: 45, type: WidthType.PERCENTAGE },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 40 },
            children: [
              new TextRun({
                text: docData.issuingAuthority ? docData.issuingAuthority.toUpperCase() : "",
                font: defaultFont,
                size: fontSizeHalfPts - 2, // Usually 1-2pt smaller than the content
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 120 },
            children: [
              new TextRun({
                text: docData.issuingOrganization ? docData.issuingOrganization.toUpperCase() : "CƠ QUAN BAN HÀNH",
                bold: true,
                font: defaultFont,
                size: fontSizeHalfPts - 2,
              }),
            ],
          }),
          // Short decorative line (1/3 length)
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 160 },
            children: [
              new TextRun({
                text: "─────────",
                font: defaultFont,
                size: 20,
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 200 },
            children: [
              new TextRun({
                text: `Số: ${docData.documentNumber || "..."}/${docData.documentSymbol || "..."}`,
                font: defaultFont,
                size: fontSizeHalfPts - 2,
              }),
            ],
          }),
        ],
      }),

      // Right Column: Motto and Slogan
      new TableCell({
        width: { size: 55, type: WidthType.PERCENTAGE },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 40 },
            children: [
              new TextRun({
                text: "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM",
                bold: true,
                font: defaultFont,
                size: fontSizeHalfPts - 2,
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 100 },
            children: [
              new TextRun({
                text: "Độc lập - Tự do - Hạnh phúc",
                bold: true,
                font: defaultFont,
                size: fontSizeHalfPts,
              }),
            ],
          }),
          // Decorative underline (full length of slogan)
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 160 },
            children: [
              new TextRun({
                text: "──────────────────",
                font: defaultFont,
                size: 20,
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.RIGHT,
            spacing: { after: 200 },
            children: [
              new TextRun({
                text: `${docData.place || "..."}, ngày ${docData.date?.day || "..."} tháng ${docData.date?.month || "..."} năm ${docData.date?.year || "..."}`,
                italics: true,
                font: defaultFont,
                size: fontSizeHalfPts,
              }),
            ],
          }),
        ],
      }),
    ],
  });

  const headerTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: "auto" },
      bottom: { style: BorderStyle.NONE, size: 0, color: "auto" },
      left: { style: BorderStyle.NONE, size: 0, color: "auto" },
      right: { style: BorderStyle.NONE, size: 0, color: "auto" },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "auto" },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: "auto" },
    },
    rows: [headerRow],
  });

  const bodyElements: any[] = [headerTable];

  // 1. Spacing paragraph
  bodyElements.push(
    new Paragraph({
      spacing: { before: 400, after: 200 },
    })
  );

  // 2. Title and Subtitle Block
  if (docData.title) {
    bodyElements.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 200, after: 80 },
        children: [
          new TextRun({
            text: docData.title.toUpperCase(),
            bold: true,
            font: defaultFont,
            size: fontSizeHalfPts + 2, // 14pt -> 15pt
          }),
        ],
      })
    );
  }

  if (docData.subtitle) {
    bodyElements.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { before: 80, after: 300 },
        children: [
          new TextRun({
            text: docData.subtitle,
            bold: true,
            font: defaultFont,
            size: fontSizeHalfPts,
          }),
        ],
      })
    );
  }

  // 3. Recipients (Kính gửi)
  if (docData.recipients && docData.recipients.length > 0) {
    const isSingle = docData.recipients.length === 1;
    if (isSingle) {
      bodyElements.push(
        new Paragraph({
          spacing: { before: 100, after: 200 },
          children: [
            new TextRun({ text: "Kính gửi: ", bold: true, font: defaultFont, size: fontSizeHalfPts }),
            new TextRun({ text: docData.recipients[0], font: defaultFont, size: fontSizeHalfPts }),
          ],
        })
      );
    } else {
      bodyElements.push(
        new Paragraph({
          spacing: { before: 100, after: 80 },
          children: [
            new TextRun({ text: "Kính gửi: ", bold: true, font: defaultFont, size: fontSizeHalfPts }),
          ],
        })
      );

      docData.recipients.forEach((rec, idx) => {
        const isLast = idx === docData.recipients.length - 1;
        bodyElements.push(
          new Paragraph({
            indent: { left: 720 }, // 0.5 inch indent
            spacing: { before: 40, after: 40 },
            children: [
              new TextRun({
                text: `- ${rec}${isLast ? "." : ";"}`,
                font: defaultFont,
                size: fontSizeHalfPts,
              }),
            ],
          })
        );
      });
    }
  }

  // 4. Preamble (Căn cứ pháp lý)
  if (docData.preamble && docData.preamble.length > 0) {
    docData.preamble.forEach((p) => {
      bodyElements.push(
        new Paragraph({
          alignment: AlignmentType.BOTH,
          indent: { firstLine: 720 },
          spacing: { before: 100, after: 100, line: lineSpacingValue },
          children: [
            new TextRun({
              text: p,
              italics: true,
              font: defaultFont,
              size: fontSizeHalfPts,
            }),
          ],
        })
      );
    });
  }

  // 5. Main Sections
  if (docData.sections && docData.sections.length > 0) {
    docData.sections.forEach((sec) => {
      // Heading section
      const isLevel1 = sec.level === 1;
      const isLevel2 = sec.level === 2;

      let prefix = "";
      if (sec.number) {
        const trimmed = sec.number.trim();
        prefix = trimmed.endsWith(".") || trimmed.endsWith(")") ? trimmed + " " : trimmed + ". ";
      }

      bodyElements.push(
        new Paragraph({
          alignment: AlignmentType.LEFT,
          spacing: { before: 240, after: 120 },
          children: [
            new TextRun({
              text: `${prefix}${sec.title}`,
              bold: isLevel1 || isLevel2,
              italics: sec.level === 3,
              font: defaultFont,
              size: isLevel1 ? fontSizeHalfPts + 1 : fontSizeHalfPts,
            }),
          ],
        })
      );

      // Paragraphs within sections
      if (sec.paragraphs && sec.paragraphs.length > 0) {
        sec.paragraphs.forEach((para) => {
          bodyElements.push(
            new Paragraph({
              alignment: AlignmentType.BOTH,
              indent: { firstLine: 720 }, // Text indent for Viet document (1 - 1.27 cm)
              spacing: { before: 80, after: 80, line: lineSpacingValue },
              children: [
                new TextRun({
                  text: para,
                  font: defaultFont,
                  size: fontSizeHalfPts,
                }),
              ],
            })
          );
        });
      }
    });
  }

  // 6. Closing Paragraph
  if (docData.closingParagraph) {
    bodyElements.push(
      new Paragraph({
        alignment: AlignmentType.BOTH,
        indent: { firstLine: 720 },
        spacing: { before: 200, after: 200, line: lineSpacingValue },
        children: [
          new TextRun({
            text: docData.closingParagraph,
            font: defaultFont,
            size: fontSizeHalfPts,
          }),
        ],
      })
    );
  }

  // Spacing before footer
  bodyElements.push(
    new Paragraph({
      spacing: { before: 400, after: 200 },
    })
  );

  // 7. Footer Block (Bảng ẩn 2 cột gồm Nơi nhận ở Trái và Phần ký ở Phải)
  const leftCellChildren: any[] = [
    new Paragraph({
      spacing: { after: 60 },
      children: [
        new TextRun({
          text: "Nơi nhận:",
          bold: true,
          italics: true,
          font: defaultFont,
          size: fontSizeHalfPts - 2, // Standard places the label 1-2 points smaller
        }),
      ],
    }),
  ];

  if (docData.distributionList && docData.distributionList.length > 0) {
    docData.distributionList.forEach((dist) => {
      let cleanDist = dist.trim();
      if (cleanDist.startsWith("-")) {
        cleanDist = cleanDist.substring(1).trim();
      }
      leftCellChildren.push(
        new Paragraph({
          spacing: { before: 20, after: 20 },
          children: [
            new TextRun({
              text: `- ${cleanDist}`,
              font: defaultFont,
              size: fontSizeHalfPts - 4, // Nơi nhận size 11 or 12
            }),
          ],
        })
      );
    });
  } else {
    // Default fallback distribution list
    leftCellChildren.push(
      new Paragraph({
        spacing: { before: 20, after: 20 },
        children: [
          new TextRun({
            text: "- Như kính gửi;",
            font: defaultFont,
            size: fontSizeHalfPts - 4,
          }),
        ],
      }),
      new Paragraph({
        spacing: { before: 20, after: 20 },
        children: [
          new TextRun({
            text: "- Lưu: VT.",
            font: defaultFont,
            size: fontSizeHalfPts - 4,
          }),
        ],
      })
    );
  }

  const rightCellChildren: any[] = [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 120 },
      children: [
        new TextRun({
          text: docData.signatoryTitle ? docData.signatoryTitle.toUpperCase() : "HIỆU TRƯỞNG",
          bold: true,
          font: defaultFont,
          size: fontSizeHalfPts,
        }),
      ],
    }),
    // 4 empty lines for physical signature spacing
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 120 } }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 120 } }),
    new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 120 } }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 120 },
      children: [
        new TextRun({
          text: docData.signatoryName || "Nguyễn Văn A",
          bold: true,
          font: defaultFont,
          size: fontSizeHalfPts,
        }),
      ],
    }),
  ];

  const footerTable = new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: "auto" },
      bottom: { style: BorderStyle.NONE, size: 0, color: "auto" },
      left: { style: BorderStyle.NONE, size: 0, color: "auto" },
      right: { style: BorderStyle.NONE, size: 0, color: "auto" },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: "auto" },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: "auto" },
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            width: { size: 45, type: WidthType.PERCENTAGE },
            children: leftCellChildren,
          }),
          new TableCell({
            width: { size: 55, type: WidthType.PERCENTAGE },
            children: rightCellChildren,
          }),
        ],
      }),
    ],
  });

  bodyElements.push(footerTable);

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: topMargin,
              bottom: bottomMargin,
              left: leftMargin,
              right: rightMargin,
            },
          },
        },
        children: bodyElements,
      },
    ],
  });

  return await Packer.toBlob(doc);
}
