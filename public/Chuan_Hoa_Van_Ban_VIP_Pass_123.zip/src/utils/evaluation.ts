/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { StandardizedDocument, ScoreReport } from "../types";

export function evaluateDocument(data: StandardizedDocument, originalText: string): ScoreReport {
  const checks: ScoreReport["checks"] = [];

  // 1. Content Checks
  const hasAuthority = !!data.issuingOrganization && data.issuingOrganization.trim() !== "CƠ QUAN BAN HÀNH" && data.issuingOrganization.trim() !== "...";
  checks.push({
    name: "Cơ quan ban hành",
    passed: hasAuthority,
    type: "content",
    message: hasAuthority
      ? `Phát hiện cơ quan ban hành: "${data.issuingOrganization}"`
      : "Thiếu tên Cơ quan/Đơn vị ban hành văn bản chính thức.",
  });

  const hasTitleAndSubtitle = !!data.title && !!data.subtitle && data.title.trim() !== "" && data.subtitle.trim() !== "";
  checks.push({
    name: "Tên loại & Trích yếu",
    passed: hasTitleAndSubtitle,
    type: "content",
    message: hasTitleAndSubtitle
      ? `Đầy đủ tiêu đề: ${data.title} - ${data.subtitle}`
      : "Thiếu tên loại văn bản hoặc trích yếu nội dung chính.",
  });

  // Verify that numbers/critical items from original aren't lost
  const originalNumbers = (originalText.match(/\d+/g) || []) as string[];
  const correctedNumbers = (JSON.stringify(data).match(/\d+/g) || []) as string[];
  let numbersLost = false;
  const missingNumbers: string[] = [];
  
  for (const num of originalNumbers) {
    if (num.length > 1 && !correctedNumbers.includes(num)) {
      numbersLost = true;
      missingNumbers.push(num);
    }
  }

  checks.push({
    name: "Bảo toàn số liệu quan trọng",
    passed: !numbersLost || missingNumbers.length === 0,
    type: "content",
    message: !numbersLost || missingNumbers.length === 0
      ? "Đã đối soát. Tất cả số liệu, tỷ lệ phần trăm được bảo toàn tuyệt đối."
      : `Phát hiện khả năng mất số liệu từ bản gốc: [${missingNumbers.slice(0, 3).join(", ")}].`,
  });

  // 2. Grammar Checks
  const spellingCorrections = data.changes.filter(c => c.type === "Chính tả" || c.type === "Viết hoa").length;
  checks.push({
    name: "Lỗi chính tả & viết hoa",
    passed: spellingCorrections < 10,
    type: "grammar",
    message: spellingCorrections === 0
      ? "Không phát hiện lỗi chính tả hay lỗi viết hoa sai quy cách."
      : `Đã tự động rà soát & chỉnh sửa ${spellingCorrections} lỗi chính tả, viết hoa danh từ riêng, tên địa phương.`,
  });

  const punctuationCorrections = data.changes.filter(c => c.type === "Dấu câu" || c.type === "Viết tắt").length;
  checks.push({
    name: "Dấu câu & Khoảng trắng",
    passed: punctuationCorrections < 10,
    type: "grammar",
    message: punctuationCorrections === 0
      ? "Khoảng cách trước/sau dấu câu hoàn hảo đúng quy định văn thư."
      : `Chuẩn hóa thành công ${punctuationCorrections} khoảng trắng thừa, dấu câu sai quy tắc.`,
  });

  // 3. Format Checks
  const hasNationalMotto = true; // Handled by our layout builder
  checks.push({
    name: "Quốc hiệu & Tiêu ngữ",
    passed: true,
    type: "format",
    message: "Có đủ 'CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM' (In hoa đậm) và 'Độc lập - Tự do - Hạnh phúc' (Đậm đứng).",
  });

  const hasDocNumberAndSymbol = !!data.documentNumber && data.documentNumber !== "..." && !!data.documentSymbol && data.documentSymbol !== "...";
  checks.push({
    name: "Số & Ký hiệu văn bản",
    passed: hasDocNumberAndSymbol,
    type: "format",
    message: hasDocNumberAndSymbol
      ? `Số ký hiệu hợp thức: ${data.documentNumber}/${data.documentSymbol}`
      : "Số văn bản hoặc ký hiệu đang dùng dấu placeholder '...' cần bổ sung.",
  });

  const hasPlaceAndDate = !!data.place && data.place !== "..." && !!data.date?.day && data.date.day !== "..." && !!data.date?.year && data.date.year !== "...";
  checks.push({
    name: "Địa danh & Ngày tháng năm ban hành",
    passed: hasPlaceAndDate,
    type: "format",
    message: hasPlaceAndDate
      ? `${data.place}, ngày ${data.date.day} tháng ${data.date.month} năm ${data.date.year}`
      : "Thiếu thông tin địa danh hoặc ngày tháng ban hành (hiện là '...').",
  });

  // 4. Layout Checks
  const hasSignatory = !!data.signatoryTitle && data.signatoryTitle !== "..." && !!data.signatoryName && data.signatoryName !== "...";
  checks.push({
    name: "Khối chữ ký người có thẩm quyền",
    passed: hasSignatory,
    type: "layout",
    message: hasSignatory
      ? `Đầy đủ chữ ký: ${data.signatoryTitle} - ${data.signatoryName}`
      : "Thiếu chức vụ người ký hoặc họ tên người ký.",
  });

  const hasRecipientsAndDist = (data.recipients && data.recipients.length > 0) || (data.distributionList && data.distributionList.length > 0);
  checks.push({
    name: "Nơi nhận & Nơi kính gửi",
    passed: hasRecipientsAndDist,
    type: "layout",
    message: hasRecipientsAndDist
      ? "Nơi nhận được thiết kế đúng vị trí góc trái dưới trang."
      : "Thiếu danh sách nơi nhận lưu văn thư hoặc nơi kính gửi đầu văn bản.",
  });

  // Structural hierarchy checks (nested sections check)
  let sectionIndexCorrect = true;
  let sectionIssueMessage = "Mục lục phân cấp hoàn hảo (La Mã I, II -> Số thường 1, 2 -> Chữ thường a, b).";
  
  if (data.sections && data.sections.length > 1) {
    // Basic verification of order
    const levels = data.sections.map(s => s.level);
    for (let i = 1; i < levels.length; i++) {
      if (levels[i] - levels[i-1] > 1) {
        sectionIndexCorrect = false;
        sectionIssueMessage = "Hệ thống phân mục nhảy cấp không liên tục (ví dụ từ cấp I nhảy ngay xuống cấp a).";
        break;
      }
    }
  }

  checks.push({
    name: "Hệ thống mục lục liên tục",
    passed: sectionIndexCorrect,
    type: "layout",
    message: sectionIssueMessage,
  });

  // Calculate segment scores (out of 100)
  const computeSegmentScore = (type: "content" | "grammar" | "format" | "layout"): number => {
    const segments = checks.filter(c => c.type === type);
    const passed = segments.filter(c => c.passed);
    return Math.round((passed.length / segments.length) * 100);
  };

  const contentScore = computeSegmentScore("content");
  const grammarScore = computeSegmentScore("grammar");
  const formatScore = computeSegmentScore("format");
  const layoutScore = computeSegmentScore("layout");

  const overallPercent = Math.round((checks.filter(c => c.passed).length / checks.length) * 100);

  return {
    contentScore,
    grammarScore,
    formatScore,
    layoutScore,
    overallPercent,
    checks,
  };
}
