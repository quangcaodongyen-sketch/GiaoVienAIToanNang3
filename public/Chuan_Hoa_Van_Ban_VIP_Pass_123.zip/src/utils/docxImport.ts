/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import mammoth from "mammoth";

export interface ParsedDoc {
  text: string;
  html: string;
}

export async function parseDocxFile(file: File): Promise<ParsedDoc> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const arrayBuffer = e.target?.result as ArrayBuffer;
        
        // Convert to HTML to preserve structure (tables, lists, paragraphs)
        const htmlResult = await mammoth.convertToHtml({ arrayBuffer });
        
        // Extract raw text for API processing
        const textResult = await mammoth.extractRawText({ arrayBuffer });
        
        resolve({
          text: textResult.value,
          html: htmlResult.value,
        });
      } catch (error) {
        console.error("Lỗi đọc file Word bằng Mammoth:", error);
        reject(new Error("Không thể đọc cấu trúc file Word này. Đảm bảo file không bị lỗi hoặc khóa bảo mật."));
      }
    };
    reader.onerror = () => reject(new Error("Lỗi đọc file."));
    reader.readAsArrayBuffer(file);
  });
}
