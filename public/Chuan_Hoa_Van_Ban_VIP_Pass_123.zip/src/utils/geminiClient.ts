export const GEMINI_RESPONSE_SCHEMA = {
  type: "OBJECT",
  properties: {
    documentType: {
      type: "STRING",
      description: "Loại văn bản nhận diện được (Báo cáo, Kế hoạch, Thông báo, Quyết định, Tờ trình, Công văn, Biên bản, Giấy mời, v.v.)"
    },
    issuingAuthority: {
      type: "STRING",
      description: "Tên cơ quan chủ quản cấp trên (nếu có, vd: UBND HUYỆN BẮC QUANG). Để trống nếu không tìm thấy."
    },
    issuingOrganization: {
      type: "STRING",
      description: "Cơ quan/đơn vị ban hành văn bản (vd: TRƯỜNG THCS ĐỒNG YÊN)."
    },
    documentNumber: {
      type: "STRING",
      description: "Số văn bản (chỉ lấy phần số, vd: '15'. Nếu thiếu điền '...')"
    },
    documentSymbol: {
      type: "STRING",
      description: "Ký hiệu văn bản (vd: 'BC-THCSĐY'. Nếu thiếu điền '...')"
    },
    place: {
      type: "STRING",
      description: "Địa danh ban hành văn bản (vd: 'Đồng Yên'. Nếu thiếu điền '...')"
    },
    date: {
      type: "OBJECT",
      properties: {
        day: { type: "STRING", description: "Ngày ban hành (vd: '20', nếu thiếu điền '...')" },
        month: { type: "STRING", description: "Tháng ban hành (vd: '7', nếu thiếu điền '...')" },
        year: { type: "STRING", description: "Năm ban hành (vd: '2026', nếu thiếu điền '...')" }
      },
      required: ["day", "month", "year"]
    },
    title: {
      type: "STRING",
      description: "Tên loại văn bản viết in hoa (vd: BÁO CÁO, KẾ HOẠCH). Với công văn hành chính thì để trống hoặc để CÔNG VĂN."
    },
    subtitle: {
      type: "STRING",
      description: "Trích yếu nội dung văn bản (vd: 'Về việc tổng kết công tác giáo dục năm học 2025 - 2026')"
    },
    recipients: {
      type: "ARRAY",
      items: { type: "STRING" },
      description: "Mảng danh sách các đối tượng kính gửi (phần Kính gửi ở đầu văn bản, nếu có)"
    },
    preamble: {
      type: "ARRAY",
      items: { type: "STRING" },
      description: "Các câu văn phần căn cứ pháp lý mở đầu hoặc đặt vấn đề trước khi vào mục chính."
    },
    sections: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          level: { type: "INTEGER", description: "Cấp độ mục (1 đại diện cho I, II; 2 đại diện cho 1, 2; 3 đại diện cho a, b)" },
          number: { type: "STRING", description: "Ký hiệu đầu mục (vd: 'I', '1', 'a')" },
          title: { type: "STRING", description: "Tiêu đề của mục đó (vd: 'ĐẶC ĐIỂM TÌNH HÌNH')" },
          paragraphs: {
            type: "ARRAY",
            items: { type: "STRING" },
            description: "Các đoạn văn bản nội dung thuộc mục này."
          }
        },
        required: ["level", "number", "title", "paragraphs"]
      },
      description: "Danh sách toàn bộ các mục nội dung trong văn bản sắp xếp theo đúng trình tự phân cấp hành chính."
    },
    closingParagraph: {
      type: "STRING",
      description: "Đoạn văn kết thúc văn bản trước phần ký (vd: 'Trên đây là báo cáo tổng kết...')."
    },
    signatoryTitle: {
      type: "STRING",
      description: "Chức vụ người ký (vd: 'HIỆU TRƯỞNG', nếu thiếu điền '...')"
    },
    signatoryName: {
      type: "STRING",
      description: "Họ và tên người ký (vd: 'Nguyễn Văn A', nếu thiếu điền '...')"
    },
    distributionList: {
      type: "ARRAY",
      items: { type: "STRING" },
      description: "Danh sách nơi nhận ở cuối trang (gồm các gạch đầu dòng và - Lưu: VT...)"
    },
    changes: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          id: { type: "INTEGER" },
          location: { type: "STRING", description: "Phần văn bản bị sửa (vd: 'Địa danh', 'Mục I.1', 'Nội dung')" },
          original: { type: "STRING", description: "Nội dung ban đầu" },
          corrected: { type: "STRING", description: "Nội dung sau khi sửa" },
          type: { type: "STRING", description: "Loại lỗi: 'Chính tả', 'Dấu câu', 'Viết hoa', 'Viết tắt', 'Diễn đạt', 'Thể thức', 'Bố cục', 'Khác'" },
          reason: { type: "STRING", description: "Lý do sửa, căn cứ pháp lý hoặc lỗi cụ thể" }
        },
        required: ["id", "location", "original", "corrected", "type", "reason"]
      },
      description: "Mảng thống kê chi tiết toàn bộ các điểm đã được chỉnh sửa so với văn bản gốc."
    },
    missingFields: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          field: { type: "STRING", description: "Tên trường bị thiếu (vd: 'documentNumber', 'date', 'signatoryName')" },
          description: { type: "STRING", description: "Mô tả nội dung thiếu và yêu cầu điền." }
        },
        required: ["field", "description"]
      },
      description: "Danh sách các thành phần thể thức bắt buộc bị thiếu trong văn bản gốc."
    },
    warnings: {
      type: "ARRAY",
      items: {
        type: "OBJECT",
        properties: {
          type: { type: "STRING", description: "Loại cảnh báo mâu thuẫn (vd: 'Năm học không nhất quán', 'Số liệu mâu thuẫn')" },
          description: { type: "STRING", description: "Mô tả cụ thể điểm mâu thuẫn cần người dùng tự kiểm tra." }
        },
        required: ["type", "description"]
      },
      description: "Cảnh báo mâu thuẫn dữ liệu logic phát hiện được trong văn bản."
    },
    confidenceScore: {
      type: "NUMBER",
      description: "Điểm tin cậy ước lượng từ 0.00 đến 1.00"
    }
  },
  required: [
    "documentType",
    "issuingAuthority",
    "issuingOrganization",
    "documentNumber",
    "documentSymbol",
    "place",
    "date",
    "title",
    "subtitle",
    "recipients",
    "preamble",
    "sections",
    "closingParagraph",
    "signatoryTitle",
    "signatoryName",
    "distributionList",
    "changes",
    "missingFields",
    "warnings",
    "confidenceScore"
  ]
};

export async function runGeminiClientSide(
  apiKey: string,
  text: string,
  mode: string,
  preferredModel: string = "gemini-2.5-flash"
): Promise<any> {
  const editMode = mode || "standard";
  let modeGuideline = "";
  if (editMode === "light") {
    modeGuideline = `Chế độ: SỬA NHẸ. Chỉ sửa lỗi chính tả hiển nhiên, lỗi dấu câu, khoảng trắng và lỗi viết hoa sai quy tắc hành chính. Giữ nguyên 99% cấu trúc câu và diễn đạt gốc. Tuyệt đối không viết lại câu hay rút gọn văn bản.`;
  } else if (editMode === "standard") {
    modeGuideline = `Chế độ: CHUẨN HÓA HÀNH CHÍNH (Mặc định). Phân tích cấu trúc, nhận diện loại văn bản, sửa tất cả lỗi chính tả, viết hoa, viết tắt, ngữ pháp, chuẩn hóa thể thức hành chính Việt Nam theo Nghị định 30/2020/NĐ-CP, sắp xếp lại các khối và phần tử của văn bản đúng vị trí thể thức hành chính, phân loại các mục rõ ràng.`;
  } else if (editMode === "expert") {
    modeGuideline = `Chế độ: BIÊN TẬP CHUYÊN SÂU. Sửa toàn bộ lỗi chính tả, thể thức như chế độ Chuẩn hóa hành chính. Ngoài ra, hãy viết lại những câu văn rườm rà, lặp ý, cải thiện văn phong hành chính để trang trọng, mạch lạc và súc tích hơn. Đề xuất các tiêu đề mục hoặc tóm tắt hợp lý hơn nếu cấu trúc gốc quá rời rạc, nhưng tuyệt đối phải giữ nguyên toàn bộ số liệu, tên người, ngày tháng và ý nghĩa cốt lõi.`;
  }

  const systemInstruction = `Bạn là chuyên gia văn thư, lưu trữ, ngôn ngữ tiếng Việt và thể thức văn bản hành chính Việt Nam theo Nghị định số 30/2020/NĐ-CP.

Nhiệm vụ của bạn là nhận diện, phân tích lỗi, chuẩn hóa nội dung, chuẩn hóa ngữ pháp/chính tả và tái cấu trúc văn bản đầu vào thành một cấu trúc văn bản hành chính Việt Nam hoàn chỉnh, chuẩn xác.

ÁP DỤNG CÁC QUY TẮC PHÁP LÝ TỪ NGHỊ ĐỊNH 30/2020/NĐ-CP:
1. Thể thức các khối đầu trang:
   - Khối trái: Cơ quan chủ quản (nếu có, chữ thường viết đứng), tên Cơ quan ban hành (chữ in hoa đậm, đứng), Số và ký hiệu văn bản (vd: "Số: 15/BC-THCSĐY" hoặc "Số: .../KH-...").
   - Khối phải: Quốc hiệu ("CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM", in hoa đậm), Tiêu ngữ ("Độc lập - Tự do - Hạnh phúc", chữ thường viết hoa đầu từ, đậm, có đường kẻ ngang mảnh bên dưới rộng bằng tiêu ngữ), Địa danh và Ngày tháng năm ban hành (vd: "Đồng Yên, ngày 20 tháng 7 năm 2026", in nghiêng).
2. Tiêu đề văn bản:
   - Tên loại văn bản (vd: BÁO CÁO, KẾ HOẠCH, QUYẾT ĐỊNH, THÔNG BÁO) in hoa đậm, đứng.
   - Trích yếu nội dung văn bản in thường đậm đứng (nếu có loại văn bản) hoặc in thường đứng nghiêng (nếu là công văn).
3. Đánh số mục nội dung:
   - Sử dụng thống nhất hệ thống đánh số phân cấp: I., II., III... (La Mã) -> 1., 2., 3... (Số thường) -> a), b), c)... (Chữ thường). Không được pha trộn sai quy cách (tránh kiểu 1, hoặc 1) hoặc I/).
4. Nơi nhận (khối trái cuối trang):
   - Chữ "Nơi nhận:" in đậm nghiêng. Các dòng nơi nhận cụ thể bắt đầu bằng gạch đầu dòng "-", kết thúc bằng dấu chấm phẩy ";". Dòng cuối cùng là "- Lưu: VT." hoặc tương tự.
5. Khối ký tên (khối phải cuối trang):
   - Chức vụ người ký (vd: "HIỆU TRƯỞNG", "CHỦ TỊCH") viết in hoa, in đậm. Họ tên người ký ở dòng cuối in đậm, đứng thường. Chừa trống dòng giữa để ký tên.
6. Bảo toàn dữ liệu:
   - Giữ nguyên tất cả các số liệu, thống kê, tên riêng, tên người, địa danh, ngày tháng thực tế, trừ lỗi chính tả/gõ dấu hiển nhiên. Không được bịa đặt thành tích hoặc tự tạo số liệu mới.
7. Xử lý thông tin thiếu:
   - Nếu thiếu ngày tháng, địa danh, số văn bản, người ký, chức vụ: Đặt các giá trị này là "..." hoặc để trống, và điền vào mảng missingFields để thông báo cho người dùng bổ sung. Không tự đoán hay tự bịa thông tin.
8. Phát hiện mâu thuẫn:
   - Nếu trong văn bản có thông tin mâu thuẫn (ví dụ lúc ghi năm học 2024-2025 lúc ghi 2025-2026, hoặc số liệu tổng lệch với số liệu thành phần), hãy chỉ ra mâu thuẫn này trong mảng warnings.

Cấu hình xử lý chế độ hiện tại:
${modeGuideline}

Bạn phải phân tích văn bản đầu vào và phản hồi dưới dạng một đối tượng JSON cấu trúc chuẩn xác theo đúng Schema được cung cấp.`;

  const fallbackModels = ["gemini-2.5-flash", "gemini-1.5-flash", "gemini-2.5-pro", "gemini-3.5-flash"];
  const modelsToTry = [preferredModel, ...fallbackModels.filter(m => m !== preferredModel)];
  
  let lastError: any = null;

  for (const model of modelsToTry) {
    try {
      console.log(`[Client Gemini] Đang gửi yêu cầu trực tiếp bằng mô hình: ${model}`);
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [
                {
                  text: text
                }
              ]
            }
          ],
          systemInstruction: {
            parts: [
              {
                text: systemInstruction
              }
            ]
          },
          generationConfig: {
            temperature: 0.1,
            responseMimeType: "application/json",
            responseSchema: GEMINI_RESPONSE_SCHEMA
          }
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`API Error (${response.status}): ${errorText}`);
      }

      const resJson = await response.json();
      const responseText = resJson?.candidates?.[0]?.content?.parts?.[0]?.text;
      
      if (!responseText) {
        throw new Error("Không có phản hồi nội dung từ API.");
      }

      return JSON.parse(responseText.trim());
    } catch (err: any) {
      console.warn(`[Client Gemini] Mô hình ${model} thất bại:`, err);
      lastError = err;
    }
  }

  throw lastError || new Error("Không thể kết nối và chuẩn hóa tài liệu qua API.");
}
