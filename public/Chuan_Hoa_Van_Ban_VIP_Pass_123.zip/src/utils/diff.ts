/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface DiffPart {
  type: "added" | "removed" | "unchanged";
  text: string;
}

/**
 * Computes a word-by-word difference between original and corrected text
 * using a standard Longest Common Subsequence (LCS) algorithm.
 */
export function computeWordDiff(original: string, corrected: string): DiffPart[] {
  // Tokenize text into words, spaces, and punctuation
  const tokenize = (str: string): string[] => {
    // Splits by spaces and keeps punctuation as separate tokens
    return str.split(/(\s+|[.,!?;:()""''\-\n])/g).filter(Boolean);
  };

  const a = tokenize(original);
  const b = tokenize(corrected);

  const n = a.length;
  const m = b.length;

  // Build the LCS matrix
  const dp: number[][] = Array.from({ length: n + 1 }, () => Array(m + 1).fill(0));

  for (let i = 1; i <= n; i++) {
    for (let j = 1; j <= m; j++) {
      if (a[i - 1] === b[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }

  // Backtrack to build the diff
  const result: DiffPart[] = [];
  let i = n;
  let j = m;

  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && a[i - 1] === b[j - 1]) {
      result.push({ type: "unchanged", text: a[i - 1] });
      i--;
      j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      result.push({ type: "added", text: b[j - 1] });
      j--;
    } else {
      result.push({ type: "removed", text: a[i - 1] });
      i--;
    }
  }

  // Backtracking produces reverse order, so we reverse it back
  result.reverse();

  // Merge contiguous items of the same type to keep output short and readable
  const merged: DiffPart[] = [];
  for (const part of result) {
    if (merged.length > 0 && merged[merged.length - 1].type === part.type) {
      merged[merged.length - 1].text += part.text;
    } else {
      merged.push({ ...part });
    }
  }

  return merged;
}
