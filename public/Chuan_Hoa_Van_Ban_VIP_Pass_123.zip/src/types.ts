/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface DocDate {
  day: string;
  month: string;
  year: string;
}

export interface DocSection {
  level: number;
  number: string;
  title: string;
  paragraphs: string[];
}

export interface DocChange {
  id: number;
  location: string;
  original: string;
  corrected: string;
  type: "Chính tả" | "Dấu câu" | "Viết hoa" | "Viết tắt" | "Diễn đạt" | "Thể thức" | "Bố cục" | "Khác";
  reason: string;
}

export interface MissingField {
  field: string;
  description: string;
}

export interface Warning {
  type: string;
  description: string;
}

export interface StandardizedDocument {
  documentType: string;
  issuingAuthority: string;
  issuingOrganization: string;
  documentNumber: string;
  documentSymbol: string;
  place: string;
  date: DocDate;
  title: string;
  subtitle: string;
  recipients: string[];
  preamble: string[];
  sections: DocSection[];
  closingParagraph: string;
  signatoryTitle: string;
  signatoryName: string;
  distributionList: string[];
  changes: DocChange[];
  missingFields: MissingField[];
  warnings: Warning[];
  confidenceScore: number;
}

export interface AppSettings {
  geminiModel: string;
  fontSize: 13 | 14;
  lineSpacing: number; // e.g. 1.15, 1.5, 2.0
  editMode: "light" | "standard" | "expert"; // Sửa nhẹ, Chuẩn hóa hành chính, Biên tập chuyên sâu
  defaultAuthority: string;
  defaultOrganization: string;
  defaultPlace: string;
  defaultSignatoryTitle: string;
  defaultSignatoryName: string;
  showDiffs: boolean;
  autoDownload: boolean;
  userGeminiApiKey?: string;
}

export interface ScoreReport {
  contentScore: number;
  grammarScore: number;
  formatScore: number;
  layoutScore: number;
  overallPercent: number;
  checks: {
    name: string;
    passed: boolean;
    type: "content" | "grammar" | "format" | "layout";
    message: string;
  }[];
}
