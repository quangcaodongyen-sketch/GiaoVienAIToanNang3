/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { StandardizedDocument } from "../types";
import { Edit3, User, Calendar, MapPin, Award, ListPlus, Hash, FileCheck } from "lucide-react";

interface ManualEditorProps {
  data: StandardizedDocument;
  onChange: (updatedData: StandardizedDocument) => void;
}

export const ManualEditor: React.FC<ManualEditorProps> = ({ data, onChange }) => {
  const handleFieldChange = (field: keyof StandardizedDocument, value: any) => {
    onChange({
      ...data,
      [field]: value,
    });
  };

  const handleDateChange = (dateField: "day" | "month" | "year", value: string) => {
    onChange({
      ...data,
      date: {
        ...data.date,
        [dateField]: value,
      },
    });
  };

  const handleRecipientsChange = (value: string) => {
    const list = value
      .split("\n")
      .map((item) => item.replace(/^- /, "").trim())
      .filter((item) => item !== "");
    handleFieldChange("recipients", list);
  };

  const handleDistributionListChange = (value: string) => {
    const list = value
      .split("\n")
      .map((item) => item.replace(/^- /, "").trim())
      .filter((item) => item !== "");
    handleFieldChange("distributionList", list);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-sm p-4 md:p-6 space-y-6">
      <div className="flex items-center space-x-2 text-blue-600 border-b border-slate-100 pb-3">
        <Edit3 className="h-4 w-4" />
        <h3 className="font-bold text-slate-800 text-sm">Hiệu chỉnh thông tin thể thức & nội dung</h3>
      </div>

      <div className="space-y-4 text-xs md:text-sm">
        {/* Row 1: Authority & Organization */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Cơ quan chủ quản cấp trên
            </label>
            <input
              type="text"
              value={data.issuingAuthority || ""}
              onChange={(e) => handleFieldChange("issuingAuthority", e.target.value)}
              className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
              placeholder="VD: UBND XÃ ĐỒNG YÊN"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Cơ quan ban hành văn bản
            </label>
            <input
              type="text"
              value={data.issuingOrganization || ""}
              onChange={(e) => handleFieldChange("issuingOrganization", e.target.value)}
              className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm font-semibold text-blue-900"
              placeholder="VD: TRƯỜNG THCS ĐỒNG YÊN"
            />
          </div>
        </div>

        {/* Row 2: Document Number & Symbol */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="flex items-center space-x-1 text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              <Hash className="h-3.5 w-3.5 text-slate-400" />
              <span>Số văn bản</span>
            </label>
            <input
              type="text"
              value={data.documentNumber || ""}
              onChange={(e) => handleFieldChange("documentNumber", e.target.value)}
              className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
              placeholder="VD: 15"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Ký hiệu văn bản
            </label>
            <input
              type="text"
              value={data.documentSymbol || ""}
              onChange={(e) => handleFieldChange("documentSymbol", e.target.value)}
              className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm font-mono"
              placeholder="VD: BC-THCSĐY"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Loại văn bản (AI nhận diện)
            </label>
            <select
              value={data.documentType || ""}
              onChange={(e) => handleFieldChange("documentType", e.target.value)}
              className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
            >
              <option value="Báo cáo">Báo cáo</option>
              <option value="Kế hoạch">Kế hoạch</option>
              <option value="Thông báo">Thông báo</option>
              <option value="Quyết định">Quyết định</option>
              <option value="Tờ trình">Tờ trình</option>
              <option value="Công văn">Công văn</option>
              <option value="Biên bản">Biên bản</option>
              <option value="Giấy mời">Giấy mời</option>
              <option value="Giấy giới thiệu">Giấy giới thiệu</option>
              <option value="Đề nghị">Đề nghị</option>
              <option value="Phương án">Phương án</option>
              <option value="Chương trình">Chương trình</option>
              <option value="Hướng dẫn">Hướng dẫn</option>
              <option value="Quy chế">Quy chế</option>
              <option value="Nội quy">Nội quy</option>
            </select>
          </div>
        </div>

        {/* Row 3: Place & Date */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-slate-50 p-3 rounded-lg border border-slate-100">
          <div>
            <label className="flex items-center space-x-1 text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              <MapPin className="h-3.5 w-3.5 text-slate-400" />
              <span>Địa danh ban hành</span>
            </label>
            <input
              type="text"
              value={data.place || ""}
              onChange={(e) => handleFieldChange("place", e.target.value)}
              className="w-full rounded border border-slate-200 bg-white px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
              placeholder="VD: Đồng Yên"
            />
          </div>

          <div>
            <label className="flex items-center space-x-1 text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              <Calendar className="h-3.5 w-3.5 text-slate-400" />
              <span>Ngày</span>
            </label>
            <input
              type="text"
              value={data.date?.day || ""}
              onChange={(e) => handleDateChange("day", e.target.value)}
              className="w-full rounded border border-slate-200 bg-white px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm text-center font-mono"
              placeholder="Ngày"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Tháng
            </label>
            <input
              type="text"
              value={data.date?.month || ""}
              onChange={(e) => handleDateChange("month", e.target.value)}
              className="w-full rounded border border-slate-200 bg-white px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm text-center font-mono"
              placeholder="Tháng"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Năm
            </label>
            <input
              type="text"
              value={data.date?.year || ""}
              onChange={(e) => handleDateChange("year", e.target.value)}
              className="w-full rounded border border-slate-200 bg-white px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm text-center font-mono"
              placeholder="Năm"
            />
          </div>
        </div>

        {/* Row 4: Title & Subtitle */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Tên tiêu đề chính (In hoa)
            </label>
            <input
              type="text"
              value={data.title || ""}
              onChange={(e) => handleFieldChange("title", e.target.value)}
              className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm font-bold text-slate-900"
              placeholder="VD: BÁO CÁO"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
              Trích yếu nội dung
            </label>
            <input
              type="text"
              value={data.subtitle || ""}
              onChange={(e) => handleFieldChange("subtitle", e.target.value)}
              className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm"
              placeholder="VD: Về việc tổng kết công tác..."
            />
          </div>
        </div>

        {/* Row 5: Single/Multiple Recipients (Kính gửi) */}
        <div>
          <label className="flex items-center space-x-1 text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
            <ListPlus className="h-3.5 w-3.5 text-slate-400" />
            <span>Nơi kính gửi (Kính gửi ở đầu) - Mỗi đối tượng một dòng</span>
          </label>
          <textarea
            value={data.recipients?.map((r) => `- ${r}`).join("\n") || ""}
            onChange={(e) => handleRecipientsChange(e.target.value)}
            rows={2}
            className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm font-mono"
            placeholder="- Ủy ban nhân dân xã Đồng Yên&#10;- Phòng Văn hóa - Xã hội"
          />
        </div>

        {/* Row 6: Signatory Title & Name */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-blue-50/40 p-3 rounded-lg border border-blue-100/50">
          <div>
            <label className="flex items-center space-x-1 text-xs font-semibold text-blue-950 uppercase tracking-wider mb-1">
              <Award className="h-3.5 w-3.5 text-blue-400" />
              <span>Chức vụ người ký</span>
            </label>
            <input
              type="text"
              value={data.signatoryTitle || ""}
              onChange={(e) => handleFieldChange("signatoryTitle", e.target.value)}
              className="w-full rounded border border-blue-200 bg-white px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm uppercase font-bold text-blue-900"
              placeholder="VD: HIỆU TRƯỞNG"
            />
          </div>

          <div>
            <label className="flex items-center space-x-1 text-xs font-semibold text-blue-950 uppercase tracking-wider mb-1">
              <User className="h-3.5 w-3.5 text-blue-400" />
              <span>Họ tên người ký</span>
            </label>
            <input
              type="text"
              value={data.signatoryName || ""}
              onChange={(e) => handleFieldChange("signatoryName", e.target.value)}
              className="w-full rounded border border-blue-200 bg-white px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm font-bold text-slate-800"
              placeholder="VD: Nguyễn Văn A"
            />
          </div>
        </div>

        {/* Row 7: Distribution List (Nơi nhận ở cuối) */}
        <div>
          <label className="flex items-center space-x-1 text-xs font-semibold text-slate-600 uppercase tracking-wider mb-1">
            <FileCheck className="h-3.5 w-3.5 text-slate-400" />
            <span>Danh sách nơi nhận (Nơi nhận ở cuối trang) - Mỗi đối tượng một dòng</span>
          </label>
          <textarea
            value={data.distributionList?.map((d) => `- ${d}`).join("\n") || ""}
            onChange={(e) => handleDistributionListChange(e.target.value)}
            rows={3}
            className="w-full rounded border border-slate-200 px-3 py-1.5 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 text-sm font-mono"
            placeholder="- Như trên&#10;- Lưu: VT."
          />
        </div>
      </div>
    </div>
  );
};
