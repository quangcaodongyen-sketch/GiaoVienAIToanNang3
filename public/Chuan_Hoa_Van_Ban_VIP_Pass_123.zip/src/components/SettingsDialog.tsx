/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { AppSettings } from "../types";
import { X, Settings, Sparkles, Sliders, Type, FileText } from "lucide-react";

interface SettingsDialogProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onUpdateSettings: (settings: Partial<AppSettings>) => void;
}

export const SettingsDialog: React.FC<SettingsDialogProps> = ({
  isOpen,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-200">
          <div className="flex items-center space-x-2.5">
            <Settings className="h-5 w-5 text-blue-600 animate-spin-slow" />
            <h2 className="text-lg font-bold text-slate-800">Cấu hình tham số chuẩn hóa</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Section 1: AI Engine Settings */}
          <div>
            <h3 className="flex items-center space-x-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
              <Sparkles className="h-3.5 w-3.5 text-blue-500" />
              <span>Cấu hình Trí tuệ nhân tạo</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Mô hình Gemini
                </label>
                <select
                  value={settings.geminiModel}
                  onChange={(e) => onUpdateSettings({ geminiModel: e.target.value })}
                  className="w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="gemini-2.5-flash">Gemini 2.5 Flash (Ổn định, Nhanh nhất)</option>
                  <option value="gemini-3.5-flash">Gemini 3.5 Flash (Thế hệ mới)</option>
                  <option value="gemini-2.5-pro">Gemini 2.5 Pro (Lập luận chuyên sâu)</option>
                  <option value="gemini-3.1-pro-preview">Gemini 3.1 Pro (Phân tích nâng cao)</option>
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Mô hình pro sẽ tối ưu hóa việc phân tích đối với các văn bản cực kỳ phức tạp.
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Mức độ chuẩn hóa & biên tập
                </label>
                <select
                  value={settings.editMode}
                  onChange={(e) => onUpdateSettings({ editMode: e.target.value as any })}
                  className="w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="light">Sửa nhẹ (Chỉ sửa chính tả & viết hoa lỗi nhỏ)</option>
                  <option value="standard">Chuẩn hóa hành chính (Khuyên dùng - Nghị định 30)</option>
                  <option value="expert">Biên tập chuyên sâu (Tối ưu hóa văn phong rành mạch)</option>
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  Cấp độ chuyên sâu sẽ đề xuất viết lại câu rườm rà nhưng không thay đổi số liệu.
                </p>
              </div>
            </div>

            {/* Custom Gemini API Key field */}
            <div className="mt-4 bg-blue-50/50 rounded-lg p-3.5 border border-blue-100/50">
              <label className="block text-xs font-bold text-blue-900 uppercase tracking-wider mb-1.5 flex items-center space-x-1.5">
                <Sparkles className="h-4 w-4 text-blue-600" />
                <span>Mã khóa Gemini API của bạn (Chạy miễn phí & Không quá tải)</span>
              </label>
              <input
                type="password"
                value={settings.userGeminiApiKey || ""}
                onChange={(e) => onUpdateSettings({ userGeminiApiKey: e.target.value })}
                className="w-full rounded border border-slate-300 bg-white px-3 py-1.5 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                placeholder="Dán mã API Key (AI Studio) của bạn vào đây..."
              />
              <p className="text-[11px] text-slate-600 mt-1.5 leading-relaxed">
                * Điền mã khóa cá nhân nếu máy chủ chung bị quá tải hoặc khi bạn chạy ứng dụng này trên Vercel độc lập. Mã khóa được lưu an toàn tại trình duyệt của bạn (localStorage) và chỉ gửi tới API để phân tích văn bản. Nhận khóa miễn phí tại <a href="https://aistudio.google.com/" target="_blank" rel="noreferrer" className="text-blue-600 underline font-semibold hover:text-blue-800">Google AI Studio</a>.
              </p>
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Section 2: Layout & Typography */}
          <div>
            <h3 className="flex items-center space-x-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
              <Type className="h-3.5 w-3.5 text-blue-500" />
              <span>Định dạng & Trình bày văn bản (Nghị định 30)</span>
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Cỡ chữ nội dung chính
                </label>
                <div className="flex space-x-4 mt-1">
                  <label className="flex items-center space-x-2 text-sm text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="fontSize"
                      checked={settings.fontSize === 13}
                      onChange={() => onUpdateSettings({ fontSize: 13 })}
                      className="text-blue-600 focus:ring-blue-500 h-4 w-4"
                    />
                    <span>Cỡ chữ 13 (Khổ nhỏ, nhiều thông tin)</span>
                  </label>
                  <label className="flex items-center space-x-2 text-sm text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="fontSize"
                      checked={settings.fontSize === 14}
                      onChange={() => onUpdateSettings({ fontSize: 14 })}
                      className="text-blue-600 focus:ring-blue-500 h-4 w-4"
                    />
                    <span>Cỡ chữ 14 (Tiêu chuẩn hành chính đứng)</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1.5">
                  Khoảng cách dòng (Line Spacing)
                </label>
                <select
                  value={settings.lineSpacing.toString()}
                  onChange={(e) => onUpdateSettings({ lineSpacing: parseFloat(e.target.value) })}
                  className="w-full rounded border border-slate-300 bg-white px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="1.0">1.0 (Dày)</option>
                  <option value="1.15">1.15 (Tiêu chuẩn tối ưu)</option>
                  <option value="1.2">1.2 (Thông thoáng)</option>
                  <option value="1.3">1.3 (Dễ đọc nhất)</option>
                  <option value="1.5">1.5 (Rộng rãi)</option>
                </select>
              </div>
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Section 3: Default Administrative Fields */}
          <div>
            <h3 className="flex items-center space-x-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
              <FileText className="h-3.5 w-3.5 text-blue-500" />
              <span>Giá trị mặc định điền khi văn bản thiếu thông tin</span>
            </h3>
            <p className="text-xs text-amber-600 bg-amber-50 rounded p-3 mb-4 leading-relaxed">
              * Hệ thống chỉ sử dụng các trường mặc định dưới đây khi văn bản gốc hoàn toàn thiếu thông tin tương ứng và được người dùng phê duyệt để tránh làm sai lệch ngữ cảnh.
            </p>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Cơ quan chủ quản cấp trên
                  </label>
                  <input
                    type="text"
                    value={settings.defaultAuthority}
                    onChange={(e) => onUpdateSettings({ defaultAuthority: e.target.value })}
                    className="w-full rounded border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="VD: UBND XÃ ĐỒNG YÊN"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Cơ quan ban hành mặc định
                  </label>
                  <input
                    type="text"
                    value={settings.defaultOrganization}
                    onChange={(e) => onUpdateSettings({ defaultOrganization: e.target.value })}
                    className="w-full rounded border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="VD: TRƯỜNG THCS ĐỒNG YÊN"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Địa danh mặc định
                  </label>
                  <input
                    type="text"
                    value={settings.defaultPlace}
                    onChange={(e) => onUpdateSettings({ defaultPlace: e.target.value })}
                    className="w-full rounded border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="VD: Đồng Yên"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Chức vụ người ký
                  </label>
                  <input
                    type="text"
                    value={settings.defaultSignatoryTitle}
                    onChange={(e) => onUpdateSettings({ defaultSignatoryTitle: e.target.value })}
                    className="w-full rounded border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="VD: HIỆU TRƯỞNG"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 mb-1">
                    Họ tên người ký
                  </label>
                  <input
                    type="text"
                    value={settings.defaultSignatoryName}
                    onChange={(e) => onUpdateSettings({ defaultSignatoryName: e.target.value })}
                    className="w-full rounded border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                    placeholder="VD: Nguyễn Văn A"
                  />
                </div>
              </div>
            </div>
          </div>

          <hr className="border-slate-200" />

          {/* Section 4: Output Settings */}
          <div>
            <h3 className="flex items-center space-x-2 text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">
              <Sliders className="h-3.5 w-3.5 text-blue-500" />
              <span>Cài đặt hệ thống khác</span>
            </h3>
            <div className="space-y-3">
              <label className="flex items-center space-x-3 text-sm text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.showDiffs}
                  onChange={(e) => onUpdateSettings({ showDiffs: e.target.checked })}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <span>Mặc định tự động hiển thị tô màu so sánh văn bản sửa đổi</span>
              </label>

              <label className="flex items-center space-x-3 text-sm text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.autoDownload}
                  onChange={(e) => onUpdateSettings({ autoDownload: e.target.checked })}
                  className="rounded border-slate-300 text-blue-600 focus:ring-blue-500 h-4 w-4"
                />
                <span>Tự động kích hoạt tải xuống tệp .docx sau khi xử lý thành công</span>
              </label>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium text-sm transition active:scale-95 shadow-sm"
          >
            Lưu & Áp dụng
          </button>
        </div>
      </div>
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fade-in {
          animation: fadeIn 0.2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
        }
        .animate-spin-slow {
          animation: spin 3s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};
