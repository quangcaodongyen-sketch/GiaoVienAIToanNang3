/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { StandardizedDocument, AppSettings } from "../types";

interface DocumentPreviewProps {
  data: StandardizedDocument;
  settings: AppSettings;
}

export const DocumentPreview: React.FC<DocumentPreviewProps> = ({ data, settings }) => {
  const fontSizeClass = settings.fontSize === 13 ? "text-[13px] md:text-[13px]" : "text-[14px] md:text-[14px]";
  const lineSpacingStyle = { lineHeight: settings.lineSpacing.toString() };

  return (
    <div className="w-full bg-slate-50 p-4 md:p-8 rounded-lg border border-slate-200 shadow-inner overflow-x-auto">
      {/* simulated A4 page */}
      <div
        id="a4-document-preview"
        className={`mx-auto bg-white border border-slate-300 shadow-md min-h-[1100px] text-slate-950 font-serif p-8 md:p-12 w-full max-w-[800px] leading-relaxed select-all ${fontSizeClass}`}
        style={{
          fontFamily: "'Times New Roman', Times, serif",
          ...lineSpacingStyle,
        }}
      >
        {/* TOP HEADER BLOCK - 2 COLUMNS */}
        <div className="flex justify-between items-start gap-4 mb-8 w-full">
          {/* Left Block (Cơ quan chủ quản & Cơ quan ban hành) */}
          <div className="text-center flex flex-col items-center w-[42%] shrink-0">
            {data.issuingAuthority && (
              <span className="text-[12px] uppercase text-slate-800 tracking-tight whitespace-nowrap">
                {data.issuingAuthority}
              </span>
            )}
            <span className="text-[12px] font-bold uppercase text-slate-900 tracking-tight mt-0.5 whitespace-nowrap">
              {data.issuingOrganization || "CƠ QUAN BAN HÀNH"}
            </span>
            {/* Short line beneath organization */}
            <div className="w-20 h-[1.5px] bg-slate-950 mt-1.5 mb-2"></div>
            <span className="text-[12px] text-slate-800 font-sans mt-0.5 whitespace-nowrap">
              Số: {data.documentNumber || "..."}/{data.documentSymbol || "..."}
            </span>
          </div>

          {/* Right Block (Quốc hiệu & Tiêu ngữ) */}
          <div className="text-center flex flex-col items-center w-[58%] shrink-0">
            <span className="text-[12px] font-bold uppercase text-slate-950 tracking-tight whitespace-nowrap">
              CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM
            </span>
            <span className="text-[13px] font-bold text-slate-900 mt-1 whitespace-nowrap">
              Độc lập - Tự do - Hạnh phúc
            </span>
            {/* Elegant horizontal line */}
            <div className="w-32 h-[1.5px] bg-slate-950 mt-1.5 mb-2"></div>
            <span className="text-[13px] italic text-slate-800 mt-0.5 self-end pr-2 md:pr-4 whitespace-nowrap">
              {data.place || "..."}, ngày {data.date?.day || "..."} tháng {data.date?.month || "..."} năm {data.date?.year || "..."}
            </span>
          </div>
        </div>

        {/* TITLE AND SUBTITLE */}
        <div className="text-center my-6">
          {data.title && (
            <h1 className="text-[15px] font-bold uppercase tracking-wide text-slate-950 mb-1">
              {data.title}
            </h1>
          )}
          {data.subtitle && (
            <p className="text-[14px] font-bold text-slate-900 leading-normal max-w-lg mx-auto">
              {data.subtitle}
            </p>
          )}
        </div>

        {/* RECIPIENTS (KÍNH GỬI) */}
        {data.recipients && data.recipients.length > 0 && (
          <div className="mb-6 pl-4">
            <span className="font-bold">Kính gửi:</span>
            {data.recipients.length === 1 ? (
              <span className="ml-1.5">{data.recipients[0]}</span>
            ) : (
              <ul className="list-none pl-6 mt-1 space-y-1">
                {data.recipients.map((rec, idx) => (
                  <li key={idx} className="relative before:content-['-'] before:absolute before:-left-4">
                    {rec}
                    {idx === data.recipients.length - 1 ? "." : ";"}
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}

        {/* PREAMBLE (CĂN CỨ PHÁP LÝ) */}
        {data.preamble && data.preamble.length > 0 && (
          <div className="space-y-2 mb-6">
            {data.preamble.map((pre, idx) => (
              <p key={idx} className="italic text-justify text-slate-900 leading-relaxed text-indent-1">
                {pre}
              </p>
            ))}
          </div>
        )}

        {/* MAIN BODY SECTIONS */}
        <div className="space-y-6">
          {data.sections && data.sections.length > 0 ? (
            data.sections.map((sec, idx) => {
              const isLevel1 = sec.level === 1;
              const isLevel2 = sec.level === 2;

              return (
                <div key={idx} className="space-y-2">
                  <h2
                    className={`text-slate-950 text-left ${
                      isLevel1
                        ? "font-bold uppercase text-[14px] mt-6"
                        : isLevel2
                        ? "font-bold text-[14px]"
                        : "italic font-medium text-[14px]"
                    }`}
                  >
                    {sec.number ? (sec.number.trim().endsWith(".") || sec.number.trim().endsWith(")") ? `${sec.number.trim()} ` : `${sec.number.trim()}. `) : ""}
                    {sec.title}
                  </h2>

                  {sec.paragraphs && sec.paragraphs.length > 0 && (
                    <div className="space-y-3">
                      {sec.paragraphs.map((p, pIdx) => (
                        <p key={pIdx} className="text-justify text-slate-900 leading-relaxed text-indent-1">
                          {p}
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <p className="text-slate-400 italic text-center py-8">Chưa có nội dung chính.</p>
          )}
        </div>

        {/* CLOSING PARAGRAPH */}
        {data.closingParagraph && (
          <div className="mt-6 mb-8 text-justify text-slate-900 text-indent-1">
            {data.closingParagraph}
          </div>
        )}

        {/* FOOTER SIGNATURE & RECIPIENTS BLOCK */}
        <div className="grid grid-cols-12 gap-2 mt-8 pt-6 border-t border-dotted border-slate-200 items-start">
          {/* Left Column (Nơi nhận) */}
          <div className="col-span-5 flex flex-col items-start text-[11px] leading-tight text-slate-800">
            <span className="font-bold italic mb-1 text-[11.5px]">Nơi nhận:</span>
            {data.distributionList && data.distributionList.length > 0 ? (
              <ul className="list-none pl-3 space-y-1">
                {data.distributionList.map((dl, idx) => {
                  let cleanDl = dl.trim();
                  if (cleanDl.startsWith("-")) {
                    cleanDl = cleanDl.substring(1).trim();
                  }
                  return (
                    <li key={idx} className="relative before:content-['-'] before:absolute before:-left-3 text-justify">
                      {cleanDl}
                    </li>
                  );
                })}
              </ul>
            ) : (
              <ul className="list-none pl-3 space-y-1">
                <li className="relative before:content-['-'] before:absolute before:-left-3">- Như kính gửi;</li>
                <li className="relative before:content-['-'] before:absolute before:-left-3">- Lưu: VT.</li>
              </ul>
            )}
          </div>

          {/* Right Column (Chữ ký & Họ tên) */}
          <div className="col-span-7 text-center flex flex-col items-center">
            <span className="font-bold uppercase text-slate-950 tracking-tight text-[13px]">
              {data.signatoryTitle || "HIỆU TRƯỞNG"}
            </span>
            {/* Simulated Signature Area */}
            <div className="h-24 flex items-center justify-center italic text-slate-300 text-xs select-none">
              (Ký tên, đóng dấu)
            </div>
            <span className="font-bold text-slate-950 text-[13px] mt-1">
              {data.signatoryName || "Nguyễn Văn A"}
            </span>
          </div>
        </div>
      </div>

      {/* Tailwind helper class for Vietnamese paragraph indentation */}
      <style>{`
        .text-indent-1 {
          text-indent: 1.25rem;
        }
      `}</style>
    </div>
  );
};
