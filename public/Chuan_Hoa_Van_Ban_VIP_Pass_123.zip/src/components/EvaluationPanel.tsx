/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { StandardizedDocument, ScoreReport } from "../types";
import { evaluateDocument } from "../utils/evaluation";
import { CheckCircle2, AlertTriangle, ShieldCheck, Award, Info } from "lucide-react";

interface EvaluationPanelProps {
  data: StandardizedDocument;
  originalText: string;
}

export const EvaluationPanel: React.FC<EvaluationPanelProps> = ({ data, originalText }) => {
  const report: ScoreReport = evaluateDocument(data, originalText);

  // Critical errors are when placeholders like '...' are present in mandatory fields
  const hasCriticalPlaceholders =
    data.documentNumber === "..." ||
    data.documentSymbol === "..." ||
    data.place === "..." ||
    data.date.day === "..." ||
    data.date.month === "..." ||
    data.date.year === "..." ||
    data.signatoryTitle === "..." ||
    data.signatoryName === "...";

  return (
    <div className="bg-white border border-slate-200 rounded-lg shadow-sm p-4 md:p-6 space-y-6">
      {/* Header and summary status */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-4">
        <div>
          <h3 className="font-bold text-slate-800 text-sm flex items-center space-x-2">
            <Award className="h-4.5 w-4.5 text-blue-600" />
            <span>Trình kiểm tra chất lượng & Đánh giá thể thức</span>
          </h3>
          <p className="text-xs text-slate-500 mt-1">
            Hệ thống tự động chấm điểm dựa trên Nghị định số 30/2020/NĐ-CP về công tác văn thư.
          </p>
        </div>

        {/* Readiness Badge */}
        <div className="flex items-center">
          {hasCriticalPlaceholders ? (
            <div className="flex items-center space-x-2 bg-amber-50 border border-amber-200 text-amber-800 rounded-lg px-4 py-2">
              <AlertTriangle className="h-5 w-5 text-amber-600 animate-pulse" />
              <div className="text-left">
                <p className="text-xs font-bold uppercase tracking-wider">Cần hoàn thiện</p>
                <p className="text-[10px] text-amber-700 font-medium">Bổ sung các trường khuyết thiếu (...)</p>
              </div>
            </div>
          ) : (
            <div className="flex items-center space-x-2 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-lg px-4 py-2">
              <ShieldCheck className="h-5 w-5 text-emerald-600" />
              <div className="text-left">
                <p className="text-xs font-bold uppercase tracking-wider text-emerald-800">Sẵn sàng tải về</p>
                <p className="text-[10px] text-emerald-600 font-medium">Bố cục và thể thức đạt chuẩn 100%</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Score Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {/* Overall Circular Score */}
        <div className="col-span-2 md:col-span-1 flex flex-col items-center justify-center p-4 bg-slate-50 rounded-xl border border-slate-150">
          <div className="relative flex items-center justify-center">
            {/* Simple SVGCircle Progress */}
            <svg className="w-20 h-20">
              <circle
                className="text-slate-200"
                strokeWidth="6"
                stroke="currentColor"
                fill="transparent"
                r="34"
                cx="40"
                cy="40"
              />
              <circle
                className={report.overallPercent >= 90 ? "text-emerald-500" : "text-blue-600"}
                strokeWidth="6"
                strokeDasharray={2 * Math.PI * 34}
                strokeDashoffset={2 * Math.PI * 34 * (1 - report.overallPercent / 100)}
                strokeLinecap="round"
                stroke="currentColor"
                fill="transparent"
                r="34"
                cx="40"
                cy="40"
                transform="rotate(-90 40 40)"
              />
            </svg>
            <span className="absolute text-xl font-bold font-mono text-slate-800">
              {report.overallPercent}%
            </span>
          </div>
          <span className="text-xs font-bold text-slate-600 mt-2 text-center">Độ hoàn thiện</span>
        </div>

        {/* Categories Scores */}
        <div className="col-span-2 md:col-span-4 grid grid-cols-2 gap-3">
          <div className="bg-white p-3 rounded-lg border border-slate-100 flex flex-col justify-between shadow-xs">
            <span className="text-xs font-medium text-slate-500">Nội dung cốt lõi</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-lg font-bold font-mono text-slate-800">{report.contentScore}/100</span>
              <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="bg-blue-600 h-full" style={{ width: `${report.contentScore}%` }}></div>
              </div>
            </div>
          </div>

          <div className="bg-white p-3 rounded-lg border border-slate-100 flex flex-col justify-between shadow-xs">
            <span className="text-xs font-medium text-slate-500">Chính tả & Ngữ pháp</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-lg font-bold font-mono text-slate-800">{report.grammarScore}/100</span>
              <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="bg-emerald-500 h-full" style={{ width: `${report.grammarScore}%` }}></div>
              </div>
            </div>
          </div>

          <div className="bg-white p-3 rounded-lg border border-slate-100 flex flex-col justify-between shadow-xs">
            <span className="text-xs font-medium text-slate-500">Thể thức hành chính</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-lg font-bold font-mono text-slate-800">{report.formatScore}/100</span>
              <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="bg-purple-600 h-full" style={{ width: `${report.formatScore}%` }}></div>
              </div>
            </div>
          </div>

          <div className="bg-white p-3 rounded-lg border border-slate-100 flex flex-col justify-between shadow-xs">
            <span className="text-xs font-medium text-slate-500">Bố cục & Trình bày</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-lg font-bold font-mono text-slate-800">{report.layoutScore}/100</span>
              <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                <div className="bg-amber-500 h-full" style={{ width: `${report.layoutScore}%` }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Checklist */}
      <div className="bg-slate-50 rounded-xl p-4 border border-slate-150">
        <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-3 flex items-center space-x-1">
          <Info className="h-4 w-4 text-blue-500" />
          <span>Chi tiết danh mục kiểm thử bắt buộc</span>
        </h4>

        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
          {report.checks.map((check, idx) => (
            <div
              key={idx}
              className={`flex items-start space-x-3 p-2.5 rounded-lg border transition ${
                check.passed
                  ? "bg-white border-slate-100 text-slate-800 hover:border-slate-200"
                  : "bg-amber-50/50 border-amber-100 text-amber-900 hover:bg-amber-50"
              }`}
            >
              <div className="mt-0.5 shrink-0">
                {check.passed ? (
                  <CheckCircle2 className="h-4 w-4 text-emerald-500" />
                ) : (
                  <AlertTriangle className="h-4 w-4 text-amber-500 animate-pulse" />
                )}
              </div>
              <div className="text-left text-xs">
                <div className="flex items-center space-x-2">
                  <span className="font-bold">{check.name}</span>
                  <span
                    className={`text-[8.5px] px-1.5 py-0.2 rounded-full uppercase font-bold tracking-tight border ${
                      check.type === "content"
                        ? "bg-blue-50 border-blue-200 text-blue-700"
                        : check.type === "grammar"
                        ? "bg-emerald-50 border-emerald-200 text-emerald-700"
                        : check.type === "format"
                        ? "bg-purple-50 border-purple-200 text-purple-700"
                        : "bg-amber-50 border-amber-200 text-amber-700"
                    }`}
                  >
                    {check.type === "content"
                      ? "Nội dung"
                      : check.type === "grammar"
                      ? "Ngữ pháp"
                      : check.type === "format"
                      ? "Thể thức"
                      : "Bố cục"}
                  </span>
                </div>
                <p className="text-slate-500 mt-0.5 leading-normal">{check.message}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
