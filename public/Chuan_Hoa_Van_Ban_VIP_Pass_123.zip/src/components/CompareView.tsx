/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { DocChange } from "../types";
import { computeWordDiff, DiffPart } from "../utils/diff";
import { Check, Clipboard, Search, AlertCircle } from "lucide-react";

interface CompareViewProps {
  originalText: string;
  correctedText: string;
  changes: DocChange[];
  showDiffHighlights: boolean;
  onToggleHighlights: () => void;
}

export const CompareView: React.FC<CompareViewProps> = ({
  originalText,
  correctedText,
  changes,
  showDiffHighlights,
  onToggleHighlights,
}) => {
  const [copied, setCopied] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  const diffParts: DiffPart[] = computeWordDiff(originalText, correctedText);

  const handleCopy = () => {
    navigator.clipboard.writeText(correctedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredChanges = changes.filter(
    (change) =>
      change.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      change.original.toLowerCase().includes(searchTerm.toLowerCase()) ||
      change.corrected.toLowerCase().includes(searchTerm.toLowerCase()) ||
      change.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
      change.reason.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Visual Diff Panel */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden">
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="h-2 w-2 rounded-full bg-blue-600"></span>
            <h3 className="font-semibold text-slate-800 text-sm">So sánh văn bản trực quan</h3>
          </div>
          <div className="flex items-center space-x-3 text-xs">
            <button
              onClick={onToggleHighlights}
              className={`px-3 py-1.5 rounded border transition ${
                showDiffHighlights
                  ? "bg-blue-50 border-blue-200 text-blue-700 font-medium"
                  : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
              }`}
            >
              {showDiffHighlights ? "Tắt tô màu thay đổi" : "Bật tô màu thay đổi"}
            </button>
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1 px-3 py-1.5 bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 rounded transition"
            >
              {copied ? (
                <>
                  <Check className="h-3.5 w-3.5 text-green-500" />
                  <span>Đã sao chép</span>
                </>
              ) : (
                <>
                  <Clipboard className="h-3.5 w-3.5" />
                  <span>Sao chép toàn bộ</span>
                </>
              )}
            </button>
          </div>
        </div>

        <div className="p-4 md:p-6 max-h-[500px] overflow-y-auto font-mono text-sm leading-relaxed bg-slate-950 text-slate-100 rounded-b-lg">
          {showDiffHighlights ? (
            <div className="whitespace-pre-wrap">
              {diffParts.map((part, idx) => {
                if (part.type === "added") {
                  return (
                    <span
                      key={idx}
                      className="bg-emerald-950/80 text-emerald-300 px-1 py-0.5 rounded border border-emerald-800/50 mx-0.5"
                      title="Nội dung được thêm"
                    >
                      {part.text}
                    </span>
                  );
                } else if (part.type === "removed") {
                  return (
                    <span
                      key={idx}
                      className="bg-rose-950/80 text-rose-300 line-through decoration-rose-500 px-1 py-0.5 rounded border border-rose-900/50 mx-0.5"
                      title="Nội dung đã bị xóa"
                    >
                      {part.text}
                    </span>
                  );
                } else {
                  return <span key={idx}>{part.text}</span>;
                }
              })}
            </div>
          ) : (
            <div className="whitespace-pre-wrap">{correctedText}</div>
          )}
        </div>
        <div className="bg-slate-50 border-t border-slate-200 px-4 py-2 text-xs text-slate-500 flex flex-wrap gap-4">
          <span className="flex items-center space-x-1.5">
            <span className="h-2 w-2 bg-emerald-500/30 border border-emerald-500 rounded"></span>
            <span>Phần thêm mới</span>
          </span>
          <span className="flex items-center space-x-1.5">
            <span className="h-2 w-2 bg-rose-500/30 border border-rose-500 line-through rounded"></span>
            <span>Phần lược bỏ/sửa đổi</span>
          </span>
        </div>
      </div>

      {/* Corrections Table */}
      <div className="bg-white border border-slate-200 rounded-lg shadow-sm overflow-hidden">
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <AlertCircle className="h-4 w-4 text-amber-600" />
            <h3 className="font-semibold text-slate-800 text-sm">
              Bảng thống kê chi tiết lỗi sửa đổi ({changes.length} mục)
            </h3>
          </div>
          {/* Search bar inside changes */}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="Tìm kiếm lỗi..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 bg-white border border-slate-200 rounded text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          {filteredChanges.length > 0 ? (
            <table className="w-full border-collapse text-left text-xs md:text-sm">
              <thead>
                <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-medium select-none">
                  <th className="px-4 py-3 text-center w-12">STT</th>
                  <th className="px-4 py-3 w-32">Vị trí</th>
                  <th className="px-4 py-3 bg-rose-50/50 w-1/4">Nội dung gốc</th>
                  <th className="px-4 py-3 bg-emerald-50/50 w-1/4">Nội dung sau sửa</th>
                  <th className="px-4 py-3 w-28 text-center">Phân loại</th>
                  <th className="px-4 py-3 text-slate-600">Lý do điều chỉnh</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {filteredChanges.map((change, idx) => (
                  <tr key={change.id || idx} className="hover:bg-slate-50/80 transition-colors">
                    <td className="px-4 py-3 text-center text-slate-500 font-mono select-none">
                      {idx + 1}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-700">
                      {change.location}
                    </td>
                    <td className="px-4 py-3 bg-rose-50/20 text-rose-700 font-mono whitespace-pre-wrap break-all border-l-2 border-l-rose-300">
                      {change.original}
                    </td>
                    <td className="px-4 py-3 bg-emerald-50/20 text-emerald-800 font-mono whitespace-pre-wrap break-all border-l-2 border-l-emerald-300">
                      {change.corrected}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span
                        className={`inline-block px-2 py-1 rounded-full text-[10px] font-semibold border ${
                          change.type === "Chính tả"
                            ? "bg-blue-50 border-blue-200 text-blue-700"
                            : change.type === "Thể thức"
                            ? "bg-purple-50 border-purple-200 text-purple-700"
                            : change.type === "Viết hoa"
                            ? "bg-amber-50 border-amber-200 text-amber-700"
                            : change.type === "Bố cục"
                            ? "bg-orange-50 border-orange-200 text-orange-700"
                            : "bg-slate-50 border-slate-200 text-slate-700"
                        }`}
                      >
                        {change.type}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-600 italic leading-relaxed">
                      {change.reason}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-8 text-slate-400 text-sm">
              Không tìm thấy lỗi sửa đổi phù hợp.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
