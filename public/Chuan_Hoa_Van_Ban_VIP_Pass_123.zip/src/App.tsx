/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  Sparkles,
  FileText,
  Copy,
  RotateCcw,
  FileDown,
  Settings,
  Sun,
  Moon,
  HelpCircle,
  RefreshCw,
  Check,
  Loader2,
  Trash2,
  Clipboard,
  UploadCloud,
  AlertTriangle,
  Printer,
  ChevronRight,
  Info,
  Layers,
  Heart,
  Sliders
} from "lucide-react";
import { StandardizedDocument, AppSettings } from "./types";
import { DocumentPreview } from "./components/DocumentPreview";
import { CompareView } from "./components/CompareView";
import { SettingsDialog } from "./components/SettingsDialog";
import { ManualEditor } from "./components/ManualEditor";
import { EvaluationPanel } from "./components/EvaluationPanel";
import { parseDocxFile } from "./utils/docxImport";
import { exportToDocx } from "./utils/docxExport";
import { evaluateDocument } from "./utils/evaluation";
import { runGeminiClientSide } from "./utils/geminiClient";

// Default administrative mock text
const MOCK_TEMPLATE = `UBND XÃ ĐỒNG YÊN
TRƯỜNG THCS ĐỒNG YÊN

Số  15 /BC - THCSĐY

CỘNG HOÀ XÃ HỘI CHỦ NGHĨA VIỆT NAM
độc lập - tự do - hạnh phúc

Đồng yên, ngày  20  tháng 7 năm 2026

BÁO CÁO
V/v tổng kết công tác giáo dục năm học 2025-2026

Kính gửi:
- Uỷ ban nhân dân xã Đồng Yên
- Phòng văn hóa xã hội xã Đồng Yên.

Thực hiện kế hoạch số: 12/KH-UBND ngày 05/9/2025 của UBND xã đồng yên về việc thực hiện nhiệm vụ năm học 2025 - 2026. Trường THCS Đồng Yên báo cáo kết quả thực hiện như sau:

I. ĐẶC ĐIỂM TÌNH HÌNH

Năm học 2025-2026 nhà trường có tổng số 16 lớp với 575 học sinh, trong đó học sinh nữ là 286 em.

II KẾT QUẢ ĐẠT ĐƯỢC

1, Công tác chuyên môn

Nhà trường đã tổ chức dạy học đúng chương trình của bộ GD&ĐT.

Nơi nhận

* Như kính gửi
* lưu VT

HIỆU TRƯỞNG

Nguyễn Văn A`;

export default function App() {
  const [originalText, setOriginalText] = useState("");
  const [lastOriginalText, setLastOriginalText] = useState(""); // For restore functionality
  const [fileName, setFileName] = useState("");
  const [isDragOver, setIsDragOver] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // App settings state
  const [settings, setSettings] = useState<AppSettings>({
    geminiModel: "gemini-2.5-flash",
    fontSize: 14,
    lineSpacing: 1.15,
    editMode: "standard",
    defaultAuthority: "UBND XÃ ĐỒNG YÊN",
    defaultOrganization: "TRƯỜNG THCS ĐỒNG YÊN",
    defaultPlace: "Đồng Yên",
    defaultSignatoryTitle: "HIỆU TRƯỞNG",
    defaultSignatoryName: "Nguyễn Văn A",
    showDiffs: true,
    autoDownload: false,
    userGeminiApiKey: "",
  });

  // Load settings on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem("qd_doc_settings");
      if (saved) {
        const parsed = JSON.parse(saved);
        setSettings((prev) => ({ ...prev, ...parsed }));
      }
    } catch (e) {
      console.error("Lỗi khi tải cấu hình:", e);
    }
  }, []);

  // Save settings when they change
  useEffect(() => {
    try {
      localStorage.setItem("qd_doc_settings", JSON.stringify(settings));
    } catch (e) {
      console.error("Lỗi khi lưu cấu hình:", e);
    }
  }, [settings]);

  // Standardized document state
  const [documentData, setDocumentData] = useState<StandardizedDocument | null>(null);
  
  // Tab states
  const [activeTab, setActiveTab] = useState<"preview" | "compare" | "score">("preview");
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [isManualEditOpen, setIsManualEditOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [copied, setCopied] = useState(false);

  // Initialize with empty text area so user doesn't have to clear sample text on startup
  useEffect(() => {
    setOriginalText("");
  }, []);

  const handleUpdateSettings = (newSettings: Partial<AppSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Plain text reconstruction helper for copying/comparing
  const getReconstructedText = (data: StandardizedDocument): string => {
    let out = "";
    const leftBlock = [
      data.issuingAuthority,
      data.issuingOrganization,
      `Số: ${data.documentNumber || "..."}/${data.documentSymbol || "..."}`
    ].filter(Boolean).join("\n");

    const rightBlock = [
      "CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM",
      "Độc lập - Tự do - Hạnh phúc",
      `${data.place || "..."}, ngày ${data.date?.day || "..."} tháng ${data.date?.month || "..."} năm ${data.date?.year || "..."}`
    ].join("\n");

    out += `[CỘT TRÁI]\n${leftBlock}\n\n[CỘT PHẢI]\n${rightBlock}\n\n`;

    if (data.title) {
      out += `${data.title.toUpperCase()}\n`;
    }
    if (data.subtitle) {
      out += `${data.subtitle}\n\n`;
    }

    if (data.recipients && data.recipients.length > 0) {
      out += `Kính gửi:\n${data.recipients.map(r => `- ${r}`).join("\n")}\n\n`;
    }

    if (data.preamble && data.preamble.length > 0) {
      out += data.preamble.join("\n") + "\n\n";
    }

    if (data.sections && data.sections.length > 0) {
      data.sections.forEach((sec) => {
        const prefix = sec.number ? `${sec.number}. ` : "";
        out += `${prefix}${sec.title}\n`;
        sec.paragraphs.forEach((p) => {
          out += `${p}\n`;
        });
        out += "\n";
      });
    }

    if (data.closingParagraph) {
      out += `${data.closingParagraph}\n\n`;
    }

    out += `[CỘT TRÁI - CUỐI TRANG]\nNơi nhận:\n${data.distributionList?.map(d => `- ${d}`).join("\n") || ""}\n\n`;
    out += `[CỘT PHẢI - CUỐI TRANG]\n${data.signatoryTitle || "HIỆU TRƯỞNG"}\n\n${data.signatoryName || "Nguyễn Văn A"}\n`;

    return out;
  };

  // API standardization trigger
  const handleStandardize = async () => {
    if (!originalText.trim()) {
      setError("Vui lòng nhập hoặc tải file văn bản.");
      return;
    }

    setLoading(true);
    setError(null);
    setLastOriginalText(originalText);

    try {
      let data: StandardizedDocument;

      // Decide whether to use direct client-side Gemini call or backend proxy
      if (settings.userGeminiApiKey && settings.userGeminiApiKey.trim() !== "") {
        console.log("Sử dụng kết nối Gemini trực tiếp từ trình duyệt khách...");
        try {
          data = await runGeminiClientSide(
            settings.userGeminiApiKey.trim(),
            originalText,
            settings.editMode,
            settings.geminiModel
          );
        } catch (clientErr: any) {
          console.error("Lỗi gọi Gemini trực tiếp từ trình duyệt khách:", clientErr);
          const rawMessage = clientErr?.message || String(clientErr);
          if (rawMessage.includes("API_KEY_INVALID") || rawMessage.includes("key is invalid") || rawMessage.includes("400")) {
            throw new Error("Mã khóa Gemini API cá nhân của bạn không hợp lệ hoặc đã hết hạn. Vui lòng kiểm tra lại cấu hình.");
          } else if (rawMessage.includes("503") || rawMessage.includes("UNAVAILABLE") || rawMessage.includes("overloaded")) {
            throw new Error("Mô hình AI hiện đang quá tải do lượng truy cập tăng cao đột biến. Vui lòng thử lại sau vài giây.");
          } else {
            throw new Error(`Lỗi gọi Gemini API trực tiếp: ${rawMessage}`);
          }
        }
      } else {
        console.log("Gửi yêu cầu tới máy chủ trung gian...");
        const response = await fetch("/api/gemini/standardize", {
          method: "POST",
          headers: { 
            "Content-Type": "application/json",
            "x-gemini-key": settings.userGeminiApiKey || ""
          },
          body: JSON.stringify({
            text: originalText,
            mode: settings.editMode,
            model: settings.geminiModel,
            options: settings,
          }),
        });

        const contentType = response.headers.get("content-type") || "";

        if (!response.ok) {
          let errMsg = "Gặp sự cố kết nối tới máy chủ.";
          if (contentType.includes("application/json")) {
            try {
              const errData = await response.json();
              errMsg = errData.error || errMsg;
            } catch (e) {
              errMsg = "Không thể phân tích lỗi JSON từ máy chủ.";
            }
          } else {
            try {
              const rawText = await response.text();
              if (rawText.includes("<!DOCTYPE") || rawText.includes("<html") || response.status === 404) {
                errMsg = "Trang web đang chạy trên môi trường tĩnh Vercel (Static SPA) không có API backend. Vui lòng bấm nút 'Cài đặt' (bánh răng) ở trên để dán mã khóa Gemini API cá nhân của bạn để ứng dụng hoạt động trực tiếp hoàn toàn miễn phí!";
              } else {
                errMsg = rawText.slice(0, 150) || `Lỗi máy chủ (Mã trạng thái ${response.status}).`;
              }
            } catch (e) {
              errMsg = `Lỗi kết nối máy chủ (Mã trạng thái ${response.status}).`;
            }
          }
          throw new Error(errMsg);
        }

        if (!contentType.includes("application/json")) {
          try {
            const rawText = await response.text();
            if (rawText.includes("<!DOCTYPE") || rawText.includes("<html")) {
              throw new Error("Trang web đang chạy trên môi trường tĩnh Vercel (Static SPA) không có API backend. Vui lòng bấm nút 'Cài đặt' (bánh răng) ở trên để dán mã khóa Gemini API cá nhân của bạn để ứng dụng hoạt động trực tiếp hoàn toàn miễn phí!");
            } else {
              throw new Error("Phản hồi trả về không phải là JSON hợp lệ.");
            }
          } catch (e: any) {
            throw new Error(e.message || "Phản hồi từ máy chủ không đúng định dạng JSON.");
          }
        }

        data = await response.json();
      }
      
      // Override empty or placeholder values with defaults only if the user confirmed/requested
      const enrichedData = { ...data };
      if (!enrichedData.place || enrichedData.place === "...") {
        enrichedData.place = settings.defaultPlace;
      }
      if (!enrichedData.issuingOrganization || enrichedData.issuingOrganization === "CƠ QUAN BAN HÀNH") {
        enrichedData.issuingOrganization = settings.defaultOrganization;
      }
      if (!enrichedData.issuingAuthority || enrichedData.issuingAuthority === "") {
        enrichedData.issuingAuthority = settings.defaultAuthority;
      }
      if (!enrichedData.signatoryTitle || enrichedData.signatoryTitle === "...") {
        enrichedData.signatoryTitle = settings.defaultSignatoryTitle;
      }
      if (!enrichedData.signatoryName || enrichedData.signatoryName === "...") {
        enrichedData.signatoryName = settings.defaultSignatoryName;
      }

      setDocumentData(enrichedData);
      setActiveTab("preview");
      
      // Auto download word if enabled
      if (settings.autoDownload) {
        setTimeout(() => handleDownloadDocx(enrichedData), 500);
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Không thể chuẩn hóa văn bản. Vui lòng kiểm tra API Key hoặc thử lại.");
    } finally {
      setLoading(false);
    }
  };

  // Clipboard copy
  const handleCopyText = () => {
    if (!documentData) return;
    const plainText = getReconstructedText(documentData);
    navigator.clipboard.writeText(plainText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Clean raw inputs
  const handleClear = () => {
    setOriginalText("");
    setFileName("");
  };

  // Restore inputs
  const handleRestore = () => {
    if (lastOriginalText) {
      setOriginalText(lastOriginalText);
    }
  };

  // Paste from clipboard
  const handlePasteClipboard = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setOriginalText(text);
      }
    } catch (err) {
      setError("Không thể tự động dán văn bản. Bạn vui lòng sử dụng phím Ctrl+V hoặc Cmd+V.");
    }
  };

  // Handle Drag & Drop uploading
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      await handleFileLoad(files[0]);
    }
  };

  const handleFileInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      await handleFileLoad(files[0]);
    }
  };

  const handleFileLoad = async (file: File) => {
    setFileName(file.name);
    setError(null);
    setLoading(true);

    try {
      if (file.name.endsWith(".docx")) {
        const parsed = await parseDocxFile(file);
        setOriginalText(parsed.text);
      } else if (file.name.endsWith(".txt")) {
        const text = await file.text();
        setOriginalText(text);
      } else {
        throw new Error("Hệ thống chỉ hỗ trợ tải lên tệp .docx hoặc .txt.");
      }
    } catch (err: any) {
      setError(err.message || "Lỗi đọc file văn bản.");
    } finally {
      setLoading(false);
    }
  };

  // Export to docx download trigger
  const handleDownloadDocx = async (dataToExport = documentData) => {
    if (!dataToExport) return;
    try {
      const blob = await exportToDocx(dataToExport, settings);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      
      const docTypeSlug = dataToExport.documentType 
        ? dataToExport.documentType.toLowerCase().replace(/\s+/g, "-")
        : "van-ban";
      const dateSlug = dataToExport.date?.day !== "..." 
        ? `${dataToExport.date.day}-${dataToExport.date.month}-${dataToExport.date.year}`
        : "chuandieu";

      link.href = url;
      link.download = `Chuan-hoa-${docTypeSlug}-${dateSlug}.docx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
      setError("Có sự cố xảy ra khi đóng gói tệp tin Word .docx.");
    }
  };

  // Printing trigger
  const handlePrint = () => {
    window.print();
  };

  const wordCount = originalText ? originalText.split(/\s+/).filter(Boolean).length : 0;
  const charCount = originalText ? originalText.length : 0;

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-200 ${darkMode ? "bg-slate-950 text-slate-100" : "bg-slate-50 text-slate-800"}`}>
      {/* GLOBAL HEADER */}
      <header className={`border-b ${darkMode ? "bg-slate-900 border-slate-800" : "bg-white border-slate-200"} py-4 px-4 md:px-8 shadow-xs`}>
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Logo & Description */}
          <div className="flex items-center space-x-3 text-left">
            <div className="p-2.5 bg-indigo-600 rounded-xl text-white shadow-md shadow-indigo-600/20">
              <Sparkles className="h-6 w-6 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg md:text-xl font-bold uppercase tracking-tight text-slate-900 dark:text-white">
                  Chuẩn hóa văn bản hành chính AI
                </h1>
                <span className="bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full border border-indigo-200 dark:border-indigo-900">
                  Nghị định 30
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Sửa lỗi nội dung, tái cấu trúc thể thức hành chính Việt Nam và xuất Word đúng chuẩn.
              </p>
            </div>
          </div>

          {/* Quick Toolbar */}
          <div className="flex items-center space-x-2 self-start md:self-auto">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className={`p-2 rounded-lg border transition ${darkMode ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"}`}
              title="Cài đặt cấu hình"
            >
              <Settings className="h-4 w-4" />
            </button>
            <button
              onClick={() => setIsHelpOpen(true)}
              className={`p-2 rounded-lg border transition ${darkMode ? "bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"}`}
              title="Cẩm nang Thể thức Nghị định 30"
            >
              <HelpCircle className="h-4 w-4" />
            </button>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 rounded-lg border transition ${darkMode ? "bg-slate-800 border-slate-700 text-yellow-400 hover:bg-slate-700" : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"}`}
              title="Đổi chủ đề"
            >
              {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>

            {/* Developer watermark */}
            <div className="hidden lg:flex flex-col text-right pl-4 border-l border-slate-200 dark:border-slate-800">
              <span className="text-[10px] font-semibold text-slate-400">Phát triển bởi:</span>
              <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400">Đinh Văn Thành</span>
              <span className="text-[10px] text-slate-500">ĐT/Zalo: 0915.213717</span>
            </div>
          </div>
        </div>
      </header>

      {/* MAIN LAYOUT CONTAINER */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-4 md:px-8 py-6 flex flex-col gap-6">
        
        {/* API KEY INSTRUCTION BANNER */}
        {!settings.userGeminiApiKey && (
          <div className="bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 text-amber-900 dark:text-amber-200 p-4 rounded-xl flex items-start justify-between gap-4 text-xs md:text-sm shadow-sm transition">
            <div className="flex items-start space-x-3 text-left w-full">
              <span className="p-1.5 bg-amber-100 dark:bg-amber-900/40 rounded-lg text-amber-700 dark:text-amber-300 mt-0.5">
                <Sparkles className="h-4 w-4 text-amber-600 dark:text-amber-400" />
              </span>
              <div className="flex-1">
                <p className="font-bold text-amber-950 dark:text-amber-100">Chưa thiết lập Mã khóa Gemini API cá nhân (Dành cho Vercel & Tránh quá tải máy chủ)</p>
                <p className="mt-1 text-slate-600 dark:text-slate-300 leading-relaxed text-xs">
                  Để đảm bảo ứng dụng hoạt động 100% ổn định, không bao giờ bị quá tải hoặc khi bạn chạy phiên bản độc lập trên Vercel, vui lòng điền mã khóa API cá nhân. Mã khóa sẽ được lưu trữ an toàn trong trình duyệt của bạn (localStorage) và chỉ gửi trực tiếp tới máy chủ AI.
                </p>
                <div className="mt-2.5 flex flex-wrap items-center gap-2.5">
                  <a
                    href="https://aistudio.google.com/"
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-lg text-xs transition shadow-2xs"
                  >
                    Lấy Key miễn phí từ Google AI Studio →
                  </a>
                  <button
                    onClick={() => setIsSettingsOpen(true)}
                    className="inline-flex items-center px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 text-slate-800 font-semibold rounded-lg text-xs transition shadow-2xs dark:bg-slate-800 dark:hover:bg-slate-700 dark:border-slate-700 dark:text-slate-200"
                  >
                    Nhập mã khóa cấu hình
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* UPPER BANNER / MOBILE CREDIT WATERMARK */}
        <div className="lg:hidden bg-indigo-50/50 dark:bg-slate-900 border border-indigo-100 dark:border-slate-800 rounded-lg p-3 flex justify-between items-center text-xs">
          <div>
            <span className="font-semibold text-slate-400">Tác giả:</span>
            <span className="font-bold text-indigo-700 dark:text-indigo-400 ml-1">Đinh Văn Thành</span>
          </div>
          <div className="text-slate-500">
            Zalo/SĐT: 0915.213717
          </div>
        </div>

        {/* ERRORS DISPLAY */}
        {error && (
          <div className="bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900 text-rose-800 dark:text-rose-200 p-4 rounded-xl flex items-start space-x-3 text-sm">
            <AlertTriangle className="h-5 w-5 text-rose-500 shrink-0 mt-0.5" />
            <div className="text-left flex-1">
              <p className="font-bold">Đã xảy ra lỗi</p>
              <p className="mt-0.5 opacity-90 leading-relaxed">{error}</p>
            </div>
          </div>
        )}

        {/* TWO-COLUMN HIGH-DENSITY EDITOR BOARD */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_48px_1fr] gap-4 items-stretch">
          
          {/* LEFT PANEL: ORIGINAL TEXT */}
          <div className="flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-lg shadow-xs overflow-hidden">
            {/* Left Panel Header */}
            <div className="flex items-center justify-between px-4 py-2.5 bg-slate-50 dark:bg-slate-950/40 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center space-x-2">
                <span className="bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-mono text-[10px] font-bold px-1.5 py-0.5 rounded">
                  GỐC
                </span>
                <h2 className="font-bold text-slate-800 dark:text-slate-100 text-xs uppercase tracking-wide">Văn bản gốc cần chuẩn hóa</h2>
              </div>
              <div className="flex items-center space-x-1.5 text-[11px]">
                <button
                  onClick={() => setOriginalText(MOCK_TEMPLATE)}
                  className="px-2.5 py-1 bg-white hover:bg-slate-50 border border-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded font-semibold transition shadow-2xs"
                  title="Điền văn bản báo cáo mẫu sai lệch để test"
                >
                  Dùng mẫu
                </button>
                {lastOriginalText && (
                  <button
                    onClick={handleRestore}
                    className="p-1 bg-white hover:bg-slate-50 border border-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded transition shadow-2xs"
                    title="Khôi phục nội dung trước"
                  >
                    <RotateCcw className="h-3.5 w-3.5" />
                  </button>
                )}
                <button
                  onClick={handleClear}
                  className="p-1 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 rounded transition"
                  title="Xóa nội dung"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            {/* Input area & Drag-Drop overlay */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className="relative flex-1"
            >
              <textarea
                value={originalText}
                onChange={(e) => setOriginalText(e.target.value)}
                placeholder="Dán văn bản hành chính thô, sai lỗi chính tả, sai bố cục hoặc kéo thả tệp Word .docx vào đây..."
                className="w-full h-[580px] p-4 bg-white dark:bg-slate-900 border-0 focus:ring-0 focus:outline-none text-xs font-sans leading-relaxed resize-none"
              />

              {/* Drag over indicator */}
              {isDragOver && (
                <div className="absolute inset-0 bg-blue-600/10 backdrop-blur-xs flex flex-col items-center justify-center pointer-events-none border-2 border-dashed border-blue-600">
                  <UploadCloud className="h-10 w-10 text-blue-600 animate-bounce" />
                  <span className="font-bold text-blue-800 mt-2 text-xs">Thả file Word (.docx) để trích xuất văn bản</span>
                </div>
              )}
            </div>

            {/* Input Footer toolbar */}
            <div className="flex items-center justify-between gap-3 px-4 py-2.5 bg-slate-50 dark:bg-slate-950/30 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center space-x-2">
                <label className="flex items-center space-x-1 px-2.5 py-1 bg-white hover:bg-slate-100 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 rounded text-[11px] cursor-pointer transition font-semibold shadow-2xs">
                  <UploadCloud className="h-3.5 w-3.5" />
                  <span>{fileName ? "Đổi file Word" : "Tải file Word"}</span>
                  <input
                    type="file"
                    accept=".docx,.txt"
                    onChange={handleFileInputChange}
                    className="hidden"
                  />
                </label>
                {fileName && (
                  <span className="text-[10px] text-blue-600 dark:text-blue-400 font-mono truncate max-w-[120px]" title={fileName}>
                    📂 {fileName}
                  </span>
                )}
              </div>

              {/* Counter metadata */}
              <div className="flex items-center space-x-2 text-[10px] text-slate-400 dark:text-slate-500 font-mono">
                <span>{wordCount} từ</span>
                <span>•</span>
                <span>{charCount} ký tự</span>
              </div>

              {/* Submit trigger inside card footer for high efficiency */}
              <button
                onClick={handleStandardize}
                disabled={loading}
                className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white font-bold rounded text-[11px] transition flex items-center space-x-1.5 shadow-sm active:scale-97"
                id="standardize-btn-left-card"
              >
                {loading ? (
                  <>
                    <Loader2 className="h-3 w-3 animate-spin" />
                    <span>Đang xử lý...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-3.5 w-3.5 animate-pulse" />
                    <span>Chuẩn hóa</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* CENTER ACTION COLUMN - ICON BUTTON WITH DECORATIVE LINE */}
          <div className="hidden lg:flex flex-col items-center justify-center relative min-h-[580px]">
            <button
              onClick={handleStandardize}
              disabled={loading}
              className="z-10 w-12 h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full shadow-lg flex items-center justify-center transition-all hover:scale-105 active:scale-95 disabled:bg-slate-300 disabled:cursor-not-allowed group border-4 border-slate-50 dark:border-slate-950"
              title="Chuẩn hóa ngay lập tức"
              id="standardize-btn-center-col"
            >
              {loading ? (
                <Loader2 className="h-5 w-5 animate-spin" />
              ) : (
                <ChevronRight className="h-6 w-6 text-white group-hover:translate-x-0.5 transition-transform" />
              )}
            </button>
            <div className="h-full w-[1px] bg-slate-200 dark:bg-slate-800 absolute"></div>
          </div>

          {/* RIGHT PANEL: STANDARDIZED RESULT */}
          <div className="flex flex-col bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-850 rounded-lg shadow-xs overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2.5 bg-blue-50/50 dark:bg-slate-950/40 border-b border-blue-100 dark:border-slate-800">
              <div className="flex items-center space-x-2">
                <span className="bg-blue-600 text-white font-mono text-[10px] font-bold px-1.5 py-0.5 rounded shadow-2xs">
                  KẾT QUẢ AI
                </span>
                <h2 className="font-bold text-blue-900 dark:text-blue-400 text-xs uppercase tracking-wide">Văn bản đã được chuẩn hóa</h2>
              </div>
              {documentData && (
                <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/30 px-2 py-0.5 rounded border border-emerald-100 dark:border-emerald-900/50">
                  AI nhận diện: {documentData.documentType} ({Math.round(documentData.confidenceScore * 100)}%)
                </span>
              )}
            </div>

            {documentData ? (
              <div className="space-y-4">
                {/* Result tabs */}
                <div className="flex border-b border-slate-200 dark:border-slate-800 gap-1.5 p-1 bg-slate-150/60 dark:bg-slate-900/40 rounded-lg">
                  <button
                    onClick={() => setActiveTab("preview")}
                    className={`flex-1 text-center py-2 rounded-md font-semibold text-xs transition ${
                      activeTab === "preview"
                        ? "bg-white dark:bg-slate-800 shadow-sm text-blue-700 dark:text-blue-400"
                        : "text-slate-600 dark:text-slate-400 hover:text-slate-800 hover:bg-slate-200/50 dark:hover:bg-slate-800/50"
                    }`}
                  >
                    Trình xem trước A4
                  </button>
                  <button
                    onClick={() => setActiveTab("compare")}
                    className={`flex-1 text-center py-2 rounded-md font-semibold text-xs transition ${
                      activeTab === "compare"
                        ? "bg-white dark:bg-slate-800 shadow-sm text-blue-700 dark:text-blue-400"
                        : "text-slate-600 dark:text-slate-400 hover:text-slate-800 hover:bg-slate-200/50 dark:hover:bg-slate-800/50"
                    }`}
                  >
                    Bảng lỗi & So sánh
                  </button>
                  <button
                    onClick={() => setActiveTab("score")}
                    className={`flex-1 text-center py-2 rounded-md font-semibold text-xs transition ${
                      activeTab === "score"
                        ? "bg-white dark:bg-slate-800 shadow-sm text-blue-700 dark:text-blue-400"
                        : "text-slate-600 dark:text-slate-400 hover:text-slate-800 hover:bg-slate-200/50 dark:hover:bg-slate-800/50"
                    }`}
                  >
                    Đánh giá thể thức
                  </button>
                </div>

                {/* Main results switch */}
                <div className="min-h-[580px] max-h-[800px] overflow-y-auto">
                  {activeTab === "preview" && (
                    <div className="space-y-4">
                      {/* Manual editor toggle button */}
                      <div className="flex justify-between items-center bg-blue-50/50 dark:bg-slate-900 border border-blue-100/50 dark:border-slate-800 p-3 rounded-xl">
                        <div className="flex items-center space-x-2 text-xs">
                          <Sliders className="h-4 w-4 text-blue-500" />
                          <span className="font-semibold text-slate-700 dark:text-slate-300">Thông tin thể thức khuyết thiếu?</span>
                        </div>
                        <button
                          onClick={() => setIsManualEditOpen(!isManualEditOpen)}
                          className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-lg transition active:scale-95"
                        >
                          {isManualEditOpen ? "Đóng hiệu chỉnh" : "Hiệu chỉnh thủ công"}
                        </button>
                      </div>

                      {isManualEditOpen && (
                        <ManualEditor data={documentData} onChange={(updated) => setDocumentData(updated)} />
                      )}

                      <DocumentPreview data={documentData} settings={settings} />
                    </div>
                  )}

                  {activeTab === "compare" && (
                    <CompareView
                      originalText={originalText}
                      correctedText={getReconstructedText(documentData)}
                      changes={documentData.changes}
                      showDiffHighlights={settings.showDiffs}
                      onToggleHighlights={() => handleUpdateSettings({ showDiffs: !settings.showDiffs })}
                    />
                  )}

                  {activeTab === "score" && (
                    <EvaluationPanel data={documentData} originalText={originalText} />
                  )}
                </div>

                {/* Toolbar for the Standardized result */}
                <div className="flex flex-wrap gap-2 justify-center lg:justify-end items-center bg-slate-100/50 dark:bg-slate-900 p-3 rounded-xl">
                  <button
                    onClick={handlePrint}
                    className="flex items-center space-x-1 px-4 py-2 bg-blue-100 hover:bg-blue-200 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 rounded-lg text-xs font-semibold transition"
                    title="In trực tiếp"
                  >
                    <Printer className="h-4 w-4" />
                    <span>In ngay</span>
                  </button>
                  <button
                    onClick={handleCopyText}
                    className="flex items-center space-x-1 px-4 py-2 bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 text-slate-700 dark:text-slate-300 rounded-lg text-xs font-semibold transition"
                  >
                    {copied ? (
                      <>
                        <Check className="h-4 w-4 text-green-500" />
                        <span>Đã sao chép</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-4 w-4" />
                        <span>Sao chép thô</span>
                      </>
                    )}
                  </button>
                  <button
                    onClick={() => handleDownloadDocx()}
                    className="flex items-center space-x-1 px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition shadow-md shadow-blue-600/10 active:scale-95"
                    title="Tải tệp tin Word .docx mở bằng Microsoft Word"
                  >
                    <FileDown className="h-4 w-4" />
                    <span>Tải tệp Word (.docx)</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center min-h-[580px] bg-white dark:bg-slate-900 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 p-8 text-center">
                <div className="p-4 bg-blue-50 dark:bg-slate-800 rounded-full text-blue-600 dark:text-blue-400 mb-4 animate-bounce">
                  <Sparkles className="h-8 w-8" />
                </div>
                <h3 className="font-bold text-slate-700 dark:text-slate-300 text-sm">Chưa có kết quả chuẩn hóa</h3>
                <p className="text-xs text-slate-400 max-w-sm mt-1 leading-normal">
                  Vui lòng nhập hoặc tải file văn bản của bạn vào ô bên trái, sau đó nhấn nút "Chuẩn hóa thể thức hành chính ngay".
                </p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* HIGH-DENSITY BOTTOM DASHBOARD / FOOTER */}
      <footer className={`border-t ${darkMode ? "bg-slate-900 border-slate-800 text-slate-200" : "bg-white border-slate-200 text-slate-800"} py-4 px-4 md:px-8 mt-8 shadow-inner`}>
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
          
          {/* Column 1: Quality Score Analytics */}
          <div className="flex flex-col justify-between">
            <div>
              <div className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-bold tracking-wider mb-2">
                Phân tích chất lượng văn bản
              </div>
              {documentData ? (
                (() => {
                  const report = evaluateDocument(documentData, originalText);
                  return (
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between items-center text-[11px] font-medium text-slate-600 dark:text-slate-400">
                          <span>Nội dung cốt lõi</span>
                          <span className="font-bold text-blue-600 dark:text-blue-400">{report.contentScore}/100</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mt-0.5">
                          <div className="h-full bg-blue-600" style={{ width: `${report.contentScore}%` }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between items-center text-[11px] font-medium text-slate-600 dark:text-slate-400">
                          <span>Thể thức & Bố cục</span>
                          <span className="font-bold text-emerald-600 dark:text-emerald-400">{report.formatScore}/100</span>
                        </div>
                        <div className="w-full h-1.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden mt-0.5">
                          <div className="h-full bg-emerald-500" style={{ width: `${report.formatScore}%` }}></div>
                        </div>
                      </div>
                    </div>
                  );
                })()
              ) : (
                <div className="text-xs text-slate-400 italic py-4">
                  Chưa có dữ liệu phân tích. Hãy nhấn chuẩn hóa để bắt đầu.
                </div>
              )}
            </div>
            <div className="text-[10px] text-slate-400 mt-2">
              Tiêu chuẩn: Nghị định 30/2020/NĐ-CP
            </div>
          </div>

          {/* Column 2: Changelog / Sửa đổi */}
          <div className="flex flex-col">
            <div className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-bold tracking-wider mb-2">
              Nhật ký thay đổi {documentData ? `(${documentData.changes.length} lỗi đã sửa)` : ""}
            </div>
            <div className="flex-1 min-h-[90px] max-h-[120px] overflow-y-auto border border-slate-100 dark:border-slate-800 rounded bg-slate-50 dark:bg-slate-950">
              {documentData && documentData.changes.length > 0 ? (
                <table className="w-full text-[10px] text-left border-collapse">
                  <thead className="sticky top-0 bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                    <tr>
                      <th className="p-1.5 border-b border-slate-300 dark:border-slate-700 font-bold">Vị trí</th>
                      <th className="p-1.5 border-b border-slate-300 dark:border-slate-700 font-bold">Lỗi</th>
                      <th className="p-1.5 border-b border-slate-300 dark:border-slate-700 font-bold">Đã sửa</th>
                    </tr>
                  </thead>
                  <tbody className="text-slate-600 dark:text-slate-400 divide-y divide-slate-100 dark:divide-slate-900">
                    {documentData.changes.map((change, index) => (
                      <tr key={index} className="hover:bg-slate-100/50 dark:hover:bg-slate-900/50">
                        <td className="p-1.5 font-semibold">{change.field || change.type}</td>
                        <td className="p-1.5 text-rose-600 line-through truncate max-w-[100px]">{change.original}</td>
                        <td className="p-1.5 text-emerald-600 font-semibold truncate max-w-[100px]">{change.corrected}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="flex items-center justify-center h-full text-xs text-slate-400 italic">
                  Chưa phát hiện lỗi chỉnh sửa
                </div>
              )}
            </div>
          </div>

          {/* Column 3: AI Type & Author info */}
          <div className="flex flex-col justify-between border-t md:border-t-0 md:border-l border-slate-150 dark:border-slate-800 pt-4 md:pt-0 md:pl-6 text-center md:text-right">
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 dark:text-slate-500 uppercase font-bold block">
                Loại văn bản AI nhận diện
              </span>
              <span className="text-sm font-bold text-blue-800 dark:text-blue-400 block">
                {documentData ? documentData.documentType : "Chưa phân tích"}
              </span>
            </div>
            
            <div className="flex flex-col items-center md:items-end mt-4">
              <span className="text-[10px] text-slate-400 font-semibold">Tác giả:</span>
              <span className="text-xs font-bold text-blue-700 dark:text-blue-400">Đinh Văn Thành</span>
              <span className="text-[10px] text-slate-500">ĐT/Zalo: 0915.213717</span>
            </div>
          </div>

        </div>
      </footer>

      {/* SETTINGS DIALOG */}
      <SettingsDialog
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      {/* HELP / INSTRUCTIONS DIALOG */}
      {isHelpOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white text-slate-800 rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl overflow-hidden max-h-[85vh] flex flex-col animate-fade-in">
            <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-200">
              <div className="flex items-center space-x-2 text-blue-600">
                <HelpCircle className="h-5 w-5" />
                <h2 className="text-base font-bold">Cẩm nang Quy chuẩn Thể thức - Nghị định 30/2020/NĐ-CP</h2>
              </div>
              <button
                onClick={() => setIsHelpOpen(false)}
                className="p-1 rounded-full hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition"
              >
                <HelpCircle className="h-5 w-5 hidden" />
                <span className="text-xs font-semibold px-2 cursor-pointer text-slate-600">Đóng</span>
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-4 text-xs md:text-sm text-left leading-relaxed">
              <div>
                <h3 className="font-bold text-blue-900 mb-1.5">1. Thành phần đầu trang (Khối trái và Khối phải)</h3>
                <ul className="list-disc pl-5 space-y-1 text-slate-600">
                  <li><strong>Cơ quan chủ quản (nếu có):</strong> Chữ thường viết đứng, đặt ở khối trái trên tên cơ quan ban hành.</li>
                  <li><strong>Cơ quan ban hành:</strong> Viết IN HOA, IN ĐẬM, ĐỨNG. Căn giữa khối bên trái. Có dòng kẻ phụ đứng rộng bằng 1/3 đến 1/2 độ dài tên cơ quan bên dưới.</li>
                  <li><strong>Quốc hiệu:</strong> &ldquo;CỘNG HÒA XÃ HỘI CHỦ NGHĨA VIỆT NAM&rdquo; - Viết IN HOA, IN ĐẬM, ĐỨNG.</li>
                  <li><strong>Tiêu ngữ:</strong> &ldquo;Độc lập - Tự do - Hạnh phúc&rdquo; - Chữ thường đứng, in đậm, chữ cái đầu của các từ cụm viết hoa. Có đường kẻ ngang mảnh bên dưới rộng bằng tiêu ngữ.</li>
                  <li><strong>Địa danh, Ngày tháng:</strong> Đặt dưới tiêu ngữ, in nghiêng đứng. Phải viết đúng chính tả địa danh hành chính cấp tỉnh hoặc huyện.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-blue-900 mb-1.5">2. Tiêu đề văn bản & Số hiệu</h3>
                <ul className="list-disc pl-5 space-y-1 text-slate-600">
                  <li><strong>Số & Ký hiệu:</strong> Trình bày dạng: &ldquo;Số: 15/BC-THCSĐY&rdquo;. Không có khoảng trắng xung quanh dấu gạch chéo, dấu gạch nối viết khít.</li>
                  <li><strong>Tên loại:</strong> Viết IN HOA, IN ĐẬM, cỡ lớn, căn giữa trang.</li>
                  <li><strong>Trích yếu:</strong> Viết in thường đứng đậm ngay sát bên dưới tên loại để mô tả nội dung tóm lược.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-blue-900 mb-1.5">3. Trình bày nội dung</h3>
                <ul className="list-disc pl-5 space-y-1 text-slate-600">
                  <li><strong>Lề trang tiêu chuẩn:</strong> Lề trên 20-25mm, Lề dưới 20-25mm, Lề trái 30-35mm, Lề phải 15-20mm.</li>
                  <li><strong>Thụt dòng:</strong> Mỗi đầu dòng đoạn văn phải thụt vào từ 1cm đến 1.27cm (0.5 inch).</li>
                  <li><strong>Hệ thống phân mục:</strong> Dùng chữ số La Mã (I., II.) &rarr; Chữ số thường (1., 2.) &rarr; Chữ cái thường phân nhánh (a), b)). Không dùng lẫn lộn.</li>
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-blue-900 mb-1.5">4. Ký tên & Nơi nhận</h3>
                <ul className="list-disc pl-5 space-y-1 text-slate-600">
                  <li><strong>Khối ký tên:</strong> Đặt ở góc phải bên dưới văn bản. Chức danh (vd: HIỆU TRƯỞNG) viết IN HOA ĐẬM. Họ tên người ký (vd: Nguyễn Văn A) viết in thường đậm đứng ở dòng cuối cùng.</li>
                  <li><strong>Nơi nhận:</strong> Góc trái cuối trang. Chữ &ldquo;Nơi nhận:&rdquo; in đậm nghiêng. Các dòng sau trình bày gạch đầu dòng, cuối cùng là &ldquo;- Lưu: VT.&rdquo;</li>
                </ul>
              </div>
            </div>

            <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex justify-end">
              <button
                onClick={() => setIsHelpOpen(false)}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium text-xs transition"
              >
                Đã hiểu
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
