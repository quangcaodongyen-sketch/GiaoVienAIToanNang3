# StudioAI Pro - Hệ Thống Chỉnh Sửa & Xử Lý Ảnh AI Toàn Năng
**Tác quyền & Bản quyền**: Thầy giáo Đinh Văn Thành (Hotline / Zalo: `0915.213717`)

---

## 1. Giới Thiệu
StudioAI Pro là nền tảng chỉnh sửa và tạo ảnh thẻ, ảnh nghệ thuật AI chuyên nghiệp, được xây dựng theo chuẩn giao diện hiện đại của AppVip nhưng đã được gỡ bỏ 100% mọi dấu vết, thông tin thương hiệu bên thứ 3 và không niêm yết giá cả thương mại.

Toàn bộ quyền hạn được thiết lập ở cấp độ **Admin VIP Cao Cấp** dành riêng cho Thầy giáo Đinh Văn Thành với **Credits Vô Hạn**.

---

## 2. Cách Chạy Web Cục Bộ (Offline Trên Máy Tính)
1. Mở thư mục `C:\Users\Admin\Desktop\Web_Chinh_Anh_AI`.
2. Nhấp đúp chuột vào file **`Chay_Web_Cuc_Bo.bat`**.
3. Trình duyệt sẽ tự động mở tại: `http://127.0.0.1:7860`.
4. Mọi tính năng chỉnh ảnh, đổi phông, thay trang phục, generative fill, xếp khổ in 10x15 đều chạy ngay lập tức.

---

## 3. Cách Triển Khai Lên Web (Online Bất Cứ Lúc Nào)
Toàn bộ mã nguồn đã được cấu hình tối ưu để đưa lên Vercel, Netlify, GitHub Pages hoặc máy chủ VPS bất cứ lúc nào.
- Chỉ cần đưa các thư mục: `index.html`, `css/`, `js/`, `assets/` lên thư mục gốc của website hoặc thư mục con `/anhthe/`.
- Domain chính thức đang triển khai: **`https://dekiemtraso.com/anhthe`**
