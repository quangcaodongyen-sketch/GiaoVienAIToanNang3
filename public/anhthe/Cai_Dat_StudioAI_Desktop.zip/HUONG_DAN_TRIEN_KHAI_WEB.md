# 🪄 StudioAI Pro - Hướng Dẫn Vận Hành & Triển Khai Web

**Hệ Thống Chỉnh Sửa & Xử Lý Ảnh Thẻ AI Toàn Năng**  
Tác quyền: **Thầy giáo Đinh Văn Thành** • Hotline/Zalo: **0915.213717**  
*100% mã nguồn độc lập, sạch sẽ, không chứa bất kỳ thông tin bản quyền hay dấu vết của bên thứ ba.*

---

## 🚀 1. Khởi Chạy Cục Bộ Trên Máy Tính (Offline 1-Click)

Bạn có thể chạy ứng dụng trực tiếp trên máy tính Windows mà không cần kết nối internet:

1. **Nhấp đúp chuột** vào file: `Chay_Web_Cuc_Bo.bat`
2. Hệ thống sẽ tự động khởi động máy chủ cục bộ tại địa chỉ:
   ```
   http://127.0.0.1:7860
   ```
3. Trình duyệt mặc định (Edge/Chrome) sẽ tự động mở giao diện StudioAI Pro với đầy đủ tính năng:
   - Làm ảnh thẻ hàng loạt (3x4, 4x6, 2x3, 3.5x4.5, 5x5).
   - Tự động xoay thẳng mặt, căn chuẩn tỷ lệ vai và đầu 68%.
   - Tách nền sạch tóc tơ và khử sạch viền xanh phông vải cũ.
   - Thay phông nền Studio xanh tỏa sáng, trắng CCCD, đỏ visa, xám studio hoặc trong suốt PNG.
   - Ghép trang phục AI (Vest nam cà vạt, Sơ mi trắng cổ Đức, Vest nữ).
   - Xóa vật thể AI (Magic Eraser bôi cọ xóa mụn, rác, người thừa).
   - Làm nét, nâng sáng gương mặt và làm mịn da tự nhiên.
   - Xếp khổ in ảnh thẻ 300 DPI (giấy 10x15cm và A4 danh sách học sinh).
   - Xuất trọn bộ ảnh thẻ chuẩn Lab in ấn dạng file ZIP.

---

## 🌐 2. Đẩy Lên GitHub & Triển Khai Lên Web (Online)

### Bước 2.1: Đưa mã nguồn lên GitHub cá nhân
Mở Command Prompt hoặc PowerShell tại thư mục này và gõ:
```bash
git init
git add .
git commit -m "Khoi tao he thong StudioAI Pro V2026"
git branch -M main
git remote add origin https://github.com/TAI_KHOAN_CUA_BAN/StudioAI_Pro.git
git push -u origin main
```

### Bước 2.2: Triển khai miễn phí lên Render.com (Khuyên dùng)
1. Đăng nhập [render.com](https://render.com) bằng tài khoản GitHub.
2. Nhấp **New +** -> **Web Service** -> Chọn kho lưu trữ `StudioAI_Pro`.
3. Cấu hình các thông số:
   - **Name**: `studioai-pro`
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn api.app:app --host 0.0.0.0 --port $PORT`
4. Bấm **Create Web Service**. Sau 2-3 phút, bạn sẽ có một đường link website chạy 24/7 (Ví dụ: `https://studioai-pro.onrender.com`).

### Bước 2.3: Triển khai lên Vercel
Thư mục đã có sẵn file cấu hình `vercel.json`. Bạn chỉ cần:
```bash
npm install -g vercel
vercel
```

---

## 📁 3. Cấu Trúc Mã Nguồn Chuẩn Dự Án

```
Web_Chinh_Anh_AI/
│
├── Chay_Web_Cuc_Bo.bat          # File chạy 1-Click trên Windows
├── server.py                   # Bộ khởi chạy máy chủ cục bộ & tự mở trình duyệt
├── requirements.txt            # Danh sách thư viện Python cần thiết
├── Procfile                    # File cấu hình chạy trên Render / Railway / Heroku
├── vercel.json                 # File cấu hình chạy trên Vercel Serverless
├── HUONG_DAN_TRIEN_KHAI_WEB.md # Tài liệu hướng dẫn sử dụng và triển khai
│
├── api/
│   └── app.py                  # FastAPI Backend: Xử lý upload, quét thư mục, crop, inpaint, in ấn, zip
│
├── core/
│   ├── face_engine.py          # AI YuNet phát hiện 5 điểm mốc khuôn mặt, xoay thẳng mặt, căn bố cục
│   ├── background_engine.py    # AI tách nền rembg + lọc khử viền xanh vải rèm + phông nền Studio
│   ├── clothing_engine.py      # Ghép tự động trang phục Vest nam, Sơ mi trắng, Vest nữ
│   ├── enhance_engine.py       # Bộ lọc làm mịn da tự nhiên, unsharp mask làm nét mắt tóc
│   ├── inpaint_engine.py       # Cọ xóa vật thể ma thuật (OpenCV Telea Inpainting)
│   ├── print_sheet_engine.py   # Xếp ảnh khổ in 10x15cm và A4 kèm vạch cắt kéo chuẩn 300 DPI
│   └── processor.py            # Nhạc trưởng xử lý Master Ultra-HD 1062x1416px
│
├── static/
│   ├── index.html              # Giao diện SaaS Dashboard hiện đại (Dark/Light mode, Split Before/After)
│   ├── css/
│   │   └── style.css           # Toàn bộ CSS hệ thống thiết kế giao diện Studio cao cấp
│   └── js/
│       └── app.js              # Bộ điều khiển frontend: kéo trượt trước/sau, cọ xóa, chọn thư mục...
│
├── models/
│   ├── face_detection_yunet_2023mar.onnx   # Model AI YuNet nhận diện khuôn mặt siêu tốc 30ms
│   └── haarcascade_frontalface_default.xml # Model dự phòng
│
└── assets/
    ├── clothes/                # Ảnh trang phục mẫu PNG trong suốt (Vest, Sơ mi)
    └── sample_images/          # Ảnh mẫu Nam, Nữ, Học sinh để thử nghiệm ngay
```

---

## 📞 Hỗ Trợ & Bản Quyền
- **Tác giả**: Thầy giáo Đinh Văn Thành
- **Zalo / Hotline**: 0915.213717
- Hệ sinh thái phần mềm giáo viên & công cụ AI chuyên nghiệp.
