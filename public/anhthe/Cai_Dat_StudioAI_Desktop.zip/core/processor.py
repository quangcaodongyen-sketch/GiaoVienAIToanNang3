import os
import time
import io
import base64
from PIL import Image, ImageOps

from .face_engine import FaceEngine
from .background_engine import BackgroundEngine, BACKGROUND_PRESETS
from .enhance_engine import EnhanceEngine
from .clothing_engine import ClothingEngine, CLOTHING_PRESETS
from .print_sheet_engine import PrintSheetEngine, PHOTO_SIZES
from .inpaint_engine import InpaintEngine

MASTER_RESOLUTIONS = {
    "3x4": {"w": 1062, "h": 1416, "print_w": 354, "print_h": 472, "name": "3 x 4 cm"},
    "4x6": {"w": 1416, "h": 2124, "print_w": 472, "print_h": 708, "name": "4 x 6 cm"},
    "2x3": {"w": 708, "h": 1062, "print_w": 236, "print_h": 354, "name": "2 x 3 cm"},
    "3.5x4.5": {"w": 1239, "h": 1593, "print_w": 413, "print_h": 531, "name": "3.5 x 4.5 cm"},
    "5x5": {"w": 1770, "h": 1770, "print_w": 590, "print_h": 590, "name": "5 x 5 cm"},
}

class PhotoCardProcessor:
    def __init__(self):
        print("[PhotoCardProcessor] Initializing AI models...")
        self.face_engine = FaceEngine()
        self.bg_engine = BackgroundEngine()
        self.enhance_engine = EnhanceEngine()
        self.clothing_engine = ClothingEngine()
        self.print_engine = PrintSheetEngine()
        self.inpaint_engine = InpaintEngine()
        print("[PhotoCardProcessor] AI models initialized successfully.")

    def process_single(
        self,
        pil_img,
        size_key="3x4",
        bg_preset="blue_studio_radial",
        custom_bg_hex=None,
        clothing_id="none",
        clothes_scale=1.0,
        clothes_y_offset=0,
        skin_smooth=25,
        brightness=6,
        contrast=6,
        sharpness=20
    ):
        """
        Processes portrait at Master Ultra-HD resolution with upright head posture & clean hair matting.
        """
        start_time = time.time()

        spec = MASTER_RESOLUTIONS.get(size_key, MASTER_RESOLUTIONS["3x4"])
        target_w = spec["w"]
        target_h = spec["h"]

        pil_img = ImageOps.exif_transpose(pil_img)
        if pil_img.mode != "RGB":
            pil_img = pil_img.convert("RGB")

        # 1. Align & Crop to natural upright ID photo posture
        cropped_img, face_info = self.face_engine.align_and_crop(
            pil_img,
            target_w=target_w,
            target_h=target_h,
            face_ratio=0.68,
            top_margin_ratio=0.10
        )

        # 2. AI Background Removal with backdrop curtain spill suppression
        rgba_person = self.bg_engine.remove_background(cropped_img, feather_radius=1.2)

        # 3. Clothing Replacement if requested
        if clothing_id and clothing_id != "none":
            rgba_person = self.clothing_engine.apply_clothing(
                rgba_person,
                clothing_id=clothing_id,
                face_info=face_info,
                scale_adj=clothes_scale,
                y_offset_adj=clothes_y_offset
            )

        # 4. Composite over target background
        composited = self.bg_engine.apply_background(
            rgba_person,
            preset_key=bg_preset,
            custom_hex=custom_bg_hex
        )

        # 5. Natural portrait retouching & lighting boost
        final_img = self.enhance_engine.enhance_portrait(
            composited,
            skin_smooth=skin_smooth,
            brightness=brightness,
            contrast=contrast,
            sharpness=sharpness
        )

        elapsed = time.time() - start_time

        return {
            "original_cropped": cropped_img,
            "final_img": final_img,
            "face_info": face_info,
            "size_key": size_key,
            "dimensions": (target_w, target_h),
            "print_dimensions": (spec["print_w"], spec["print_h"]),
            "elapsed_seconds": round(elapsed, 2)
        }
