import os
import cv2
import numpy as np
from PIL import Image

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLOTHES_DIR = os.path.join(BASE_DIR, "assets", "clothes")

CLOTHING_PRESETS = [
    {
        "id": "none",
        "name": "Giữ nguyên trang phục gốc",
        "gender": "all",
        "file": None
    },
    {
        "id": "vest_nam_den",
        "name": "Vest Đen Cà Vạt Xanh (Nam)",
        "gender": "male",
        "file": "vest_nam_den.png"
    },
    {
        "id": "so_mi_nam_trang",
        "name": "Sơ Mi Trắng Cổ Đức (Nam)",
        "gender": "male",
        "file": "so_mi_nam_trang.png"
    },
    {
        "id": "vest_nu_den",
        "name": "Vest Đen Công Sở (Nữ)",
        "gender": "female",
        "file": "vest_nu_den.png"
    }
]

class ClothingEngine:
    def __init__(self):
        self.templates = {}
        self._load_templates()

    def _load_templates(self):
        for preset in CLOTHING_PRESETS:
            cid = preset["id"]
            cfile = preset["file"]
            if cfile:
                path = os.path.join(CLOTHES_DIR, cfile)
                if os.path.exists(path):
                    try:
                        self.templates[cid] = Image.open(path).convert("RGBA")
                    except Exception as e:
                        print(f"[ClothingEngine] Error loading {cfile}: {e}")

    def get_presets(self):
        result = []
        for p in CLOTHING_PRESETS:
            result.append({
                "id": p["id"],
                "name": p["name"],
                "gender": p["gender"],
                "available": (p["id"] == "none" or p["id"] in self.templates)
            })
        return result

    def apply_clothing(self, person_img, clothing_id="none", face_info=None, scale_adj=1.0, y_offset_adj=0):
        if clothing_id == "none" or clothing_id not in self.templates:
            return person_img

        template = self.templates[clothing_id].copy()
        target_w, target_h = person_img.size

        base_template_w = int(target_w * 1.02 * scale_adj)
        aspect = template.size[1] / template.size[0]
        base_template_h = int(base_template_w * aspect)

        resized_template = template.resize((base_template_w, base_template_h), Image.Resampling.LANCZOS)
        pos_x = int((target_w - base_template_w) / 2)

        # In natural 68% face ratio framing, chin is around 56-58% of target_h
        chin_y_est = int(target_h * 0.58)
        pos_y = chin_y_est - int(base_template_h * 0.16) + int(y_offset_adj)

        combined = person_img.convert("RGBA").copy()
        overlay_canvas = Image.new("RGBA", (target_w, target_h), (0, 0, 0, 0))
        overlay_canvas.paste(resized_template, (pos_x, pos_y), resized_template)

        final_img = Image.alpha_composite(combined, overlay_canvas)
        return final_img
