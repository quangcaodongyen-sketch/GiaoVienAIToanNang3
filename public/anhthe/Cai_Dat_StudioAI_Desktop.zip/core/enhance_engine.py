import cv2
import numpy as np
from PIL import Image

class EnhanceEngine:
    def __init__(self):
        pass

    def enhance_portrait(self, pil_img, skin_smooth=25, brightness=6, contrast=6, sharpness=20):
        """
        Enhances portrait:
        - skin_smooth: 0 to 100. Uses Bilateral Filtering + skin mask to preserve eyes/mouth/hair.
        - brightness: -50 to 50.
        - contrast: -50 to 50.
        - sharpness: 0 to 100. Unsharp masking for crisp eyes and hair strands.
        """
        has_alpha = (pil_img.mode == "RGBA")
        if has_alpha:
            r, g, b, alpha = pil_img.split()
            rgb_img = Image.merge("RGB", (r, g, b))
        else:
            rgb_img = pil_img.convert("RGB")
            alpha = None

        cv_img = cv2.cvtColor(np.array(rgb_img), cv2.COLOR_RGB2BGR)

        # 1. Skin Smoothing (Bilateral Filter with Skin Mask)
        if skin_smooth > 0:
            d = int(5 + (skin_smooth / 100.0) * 8)
            sigma_color = 15 + skin_smooth * 0.6
            sigma_space = 15 + skin_smooth * 0.6

            filtered = cv2.bilateralFilter(cv_img, d=d, sigmaColor=sigma_color, sigmaSpace=sigma_space)

            # Skin color range in YCrCb
            ycrcb = cv2.cvtColor(cv_img, cv2.COLOR_BGR2YCrCb)
            lower_skin = np.array([0, 133, 77], dtype=np.uint8)
            upper_skin = np.array([255, 175, 127], dtype=np.uint8)
            skin_mask = cv2.inRange(ycrcb, lower_skin, upper_skin)

            skin_mask = cv2.GaussianBlur(skin_mask, (15, 15), 0)
            skin_weight = (skin_mask.astype(np.float32) / 255.0)[:, :, None]

            factor = float(skin_smooth) / 100.0
            blend_weight = skin_weight * factor
            cv_img = (filtered * blend_weight + cv_img * (1.0 - blend_weight)).astype(np.uint8)

        # 2. Brightness & Contrast
        if brightness != 0 or contrast != 0:
            f_img = cv_img.astype(np.float32) + float(brightness)
            alpha_c = 1.0 + (contrast / 100.0)
            f_img = (f_img - 128.0) * alpha_c + 128.0
            cv_img = np.clip(f_img, 0, 255).astype(np.uint8)

        # 3. Sharpness (Unsharp Mask)
        if sharpness > 0:
            gaussian = cv2.GaussianBlur(cv_img, (0, 0), 2.0)
            weight = (sharpness / 100.0) * 0.7
            sharpened = cv2.addWeighted(cv_img, 1.0 + weight, gaussian, -weight, 0)
            cv_img = np.clip(sharpened, 0, 255).astype(np.uint8)

        result_rgb = Image.fromarray(cv2.cvtColor(cv_img, cv2.COLOR_BGR2RGB))
        if has_alpha and alpha is not None:
            r, g, b = result_rgb.split()
            return Image.merge("RGBA", (r, g, b, alpha))
        return result_rgb
