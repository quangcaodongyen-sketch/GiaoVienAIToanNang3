import cv2
import numpy as np
from PIL import Image, ImageFilter
from rembg import remove, new_session

BACKGROUND_PRESETS = {
    "blue_studio_radial": {
        "name": "Xanh Đèn Studio Tỏa Sáng (Chuyên Nghiệp)",
        "hex": "#0072C6",
        "center_rgb": (38, 166, 254),
        "edge_rgb": (2, 90, 162),
        "is_gradient": True
    },
    "blue_standard": {
        "name": "Xanh Chuẩn Studio (#0B84D4)",
        "hex": "#0B84D4",
        "rgb": (11, 132, 212),
        "is_gradient": False
    },
    "white_cccd": {
        "name": "Trắng CCCD / Hộ Chiếu (#FFFFFF)",
        "hex": "#FFFFFF",
        "rgb": (255, 255, 255),
        "is_gradient": False
    },
    "blue_light": {
        "name": "Xanh Dương Nhạt (#3A86FF)",
        "hex": "#3A86FF",
        "rgb": (58, 134, 255),
        "is_gradient": False
    },
    "red_visa": {
        "name": "Đỏ Thẻ Đảng / Visa (#D32F2F)",
        "hex": "#D32F2F",
        "rgb": (211, 47, 47),
        "is_gradient": False
    },
    "gray_studio": {
        "name": "Xám Studio Neutral (#E2E8F0)",
        "hex": "#E2E8F0",
        "rgb": (226, 232, 240),
        "is_gradient": False
    },
    "transparent": {
        "name": "Trong Suốt (PNG)",
        "hex": "transparent",
        "rgb": None,
        "is_gradient": False
    }
}

class BackgroundEngine:
    def __init__(self):
        self.session = None
        self._init_session()

    def _init_session(self):
        try:
            self.session = new_session("u2net_human_seg")
        except Exception as e:
            print(f"[BackgroundEngine] Fallback to default session: {e}")
            try:
                self.session = new_session("u2netp")
            except:
                self.session = None

    def clean_backdrop_spill(self, cropped_img, rgba_result):
        """
        Cleans up residual backdrop curtain patches (e.g. blue wrinkled cloth)
        that AI segmentation might mistakenly include near the hair edges.
        """
        rgb_arr = np.array(cropped_img.convert("RGB"))
        rgba_arr = np.array(rgba_result)
        alpha = rgba_arr[:, :, 3].copy()
        h, w = alpha.shape

        # Sample corners to detect background color profile
        corner_tl = rgb_arr[:int(h*0.12), :int(w*0.15)]
        corner_tr = rgb_arr[:int(h*0.12), int(w*0.85):]
        corners = np.concatenate([corner_tl.reshape(-1, 3), corner_tr.reshape(-1, 3)], axis=0)

        # Average backdrop color
        bg_mean = np.mean(corners, axis=0)
        hsv_img = cv2.cvtColor(rgb_arr, cv2.COLOR_RGB2HSV)
        bg_hsv = cv2.cvtColor(np.uint8([[bg_mean]]), cv2.COLOR_RGB2HSV)[0][0]

        # 1. Detect if background is Blue Curtain (very common in Vietnamese schools/studios)
        # Blue Hue in OpenCV HSV is ~95 to 135
        is_blue_backdrop = (bg_hsv[0] >= 90 and bg_hsv[0] <= 140) or (bg_mean[2] > bg_mean[0] + 15 and bg_mean[2] > bg_mean[1] + 5)
        
        if is_blue_backdrop:
            # Mask out blue cloth pixels that are outside the center face region
            is_curtain_pixel = (hsv_img[:, :, 0] >= 90) & (hsv_img[:, :, 0] <= 140) & (hsv_img[:, :, 1] >= 20) & (hsv_img[:, :, 2] >= 35)
            # Suppress blue curtain pixels in alpha
            alpha[is_curtain_pixel] = 0

        # 2. General color distance suppression in upper outer areas (corners)
        color_dist = np.linalg.norm(rgb_arr.astype(np.float32) - bg_mean, axis=2)
        # In the upper 40% and left/right 25%, if color is close to background, zero it out
        outer_mask = np.zeros((h, w), dtype=bool)
        outer_mask[:int(h * 0.45), :int(w * 0.28)] = True
        outer_mask[:int(h * 0.45), int(w * 0.72):] = True
        close_to_bg = (color_dist < 45.0) & outer_mask
        alpha[close_to_bg] = 0

        # Smooth alpha edge
        alpha_pil = Image.fromarray(alpha).filter(ImageFilter.GaussianBlur(1.2))
        rgba_arr[:, :, 3] = np.array(alpha_pil)

        return Image.fromarray(rgba_arr)

    def remove_background(self, pil_img, feather_radius=1.2):
        if self.session is not None:
            rgba = remove(pil_img, session=self.session)
        else:
            rgba = remove(pil_img)

        # Clean any blue cloth / backdrop curtain spill
        cleaned_rgba = self.clean_backdrop_spill(pil_img, rgba)

        # Subtle feathering for hair
        if feather_radius > 0:
            r, g, b, a = cleaned_rgba.split()
            a_blurred = a.filter(ImageFilter.GaussianBlur(feather_radius))
            cleaned_rgba = Image.merge("RGBA", (r, g, b, a_blurred))

        return cleaned_rgba

    def create_gradient_background(self, width, height, center_rgb, edge_rgb):
        y, x = np.ogrid[:height, :width]
        cx, cy = width / 2.0, height * 0.42
        max_dist = np.sqrt(cx**2 + cy**2)
        dist = np.sqrt((x - cx)**2 + (y - cy)**2)
        norm_dist = np.clip(dist / max_dist, 0.0, 1.0)
        t = (1.0 - np.cos(norm_dist * np.pi)) / 2.0

        bg_arr = np.zeros((height, width, 3), dtype=np.uint8)
        for i in range(3):
            bg_arr[:, :, i] = np.clip(
                center_rgb[i] * (1.0 - t) + edge_rgb[i] * t, 0, 255
            ).astype(np.uint8)

        return Image.fromarray(bg_arr, "RGB")

    def apply_background(self, rgba_img, preset_key="blue_studio_radial", custom_hex=None):
        w, h = rgba_img.size

        if preset_key == "transparent" and not custom_hex:
            return rgba_img

        if custom_hex:
            hex_clean = custom_hex.lstrip("#")
            if len(hex_clean) == 6:
                r = int(hex_clean[0:2], 16)
                g = int(hex_clean[2:4], 16)
                b = int(hex_clean[4:6], 16)
                bg_img = Image.new("RGB", (w, h), (r, g, b))
            else:
                bg_img = Image.new("RGB", (w, h), (11, 132, 212))
        else:
            preset = BACKGROUND_PRESETS.get(preset_key, BACKGROUND_PRESETS["blue_studio_radial"])
            if preset.get("is_gradient"):
                bg_img = self.create_gradient_background(
                    w, h, preset["center_rgb"], preset["edge_rgb"]
                )
            else:
                rgb = preset.get("rgb", (11, 132, 212))
                bg_img = Image.new("RGB", (w, h), rgb)

        bg_img = bg_img.convert("RGBA")
        combined = Image.alpha_composite(bg_img, rgba_img)
        return combined.convert("RGB")
