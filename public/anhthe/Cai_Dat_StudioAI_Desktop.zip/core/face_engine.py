import os
import cv2
import numpy as np
from PIL import Image, ImageOps

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODELS_DIR = os.path.join(BASE_DIR, "models")
YUNET_PATH = os.path.join(MODELS_DIR, "face_detection_yunet_2023mar.onnx")
HAAR_PATH = os.path.join(MODELS_DIR, "haarcascade_frontalface_default.xml")

class FaceEngine:
    def __init__(self):
        self.yunet_detector = None
        self.haar_detector = None
        self._init_detectors()

    def _init_detectors(self):
        if os.path.exists(YUNET_PATH):
            try:
                self.yunet_detector = cv2.FaceDetectorYN.create(YUNET_PATH, "", (320, 320))
            except Exception as e:
                print(f"[FaceEngine] YuNet load error: {e}")
                self.yunet_detector = None

        if os.path.exists(HAAR_PATH):
            try:
                self.haar_detector = cv2.CascadeClassifier(HAAR_PATH)
            except Exception as e:
                print(f"[FaceEngine] Haar load error: {e}")
                self.haar_detector = None

    def detect_face(self, cv2_img):
        """
        Detects primary face in cv2 image (BGR format).
        Scales large images down to max dimension 1024 for 100% reliable, ultra-fast YuNet inference.
        """
        orig_h, orig_w = cv2_img.shape[:2]

        max_dim = 1024.0
        if max(orig_h, orig_w) > max_dim:
            scale = max_dim / float(max(orig_h, orig_w))
            dw, dh = int(orig_w * scale), int(orig_h * scale)
            detect_img = cv2.resize(cv2_img, (dw, dh), interpolation=cv2.INTER_AREA)
        else:
            scale = 1.0
            dw, dh = orig_w, orig_h
            detect_img = cv2_img

        # 1. Try YuNet first on scaled image
        if self.yunet_detector is not None:
            try:
                self.yunet_detector.setInputSize((dw, dh))
                _, faces = self.yunet_detector.detect(detect_img)
                if faces is not None and len(faces) > 0:
                    best_face = max(faces, key=lambda f: f[2] * f[3])
                    x, y, bw, bh = best_face[:4] / scale
                    landmarks = best_face[4:14].reshape((5, 2)) / scale
                    # [0]=right_eye, [1]=left_eye, [2]=nose, [3]=right_mouth, [4]=left_mouth
                    re = landmarks[0]
                    le = landmarks[1]
                    dx = le[0] - re[0]
                    dy = le[1] - re[1]
                    angle = np.degrees(np.arctan2(dy, dx))

                    cx = int(x + bw / 2)
                    cy = int(y + bh / 2)

                    return {
                        "bbox": (int(x), int(y), int(bw), int(bh)),
                        "landmarks": landmarks,
                        "angle": float(angle),
                        "center": (cx, cy),
                        "method": "yunet"
                    }
            except Exception as e:
                print(f"[FaceEngine] YuNet detection error: {e}")

        # 2. Fallback to Haar Cascade on grayscale scaled image
        if self.haar_detector is not None:
            try:
                gray = cv2.cvtColor(detect_img, cv2.COLOR_BGR2GRAY)
                faces = self.haar_detector.detectMultiScale(
                    gray, scaleFactor=1.1, minNeighbors=4, minSize=(50, 50)
                )
                if len(faces) > 0:
                    best_face = max(faces, key=lambda f: f[2] * f[3])
                    x, y, bw, bh = [val / scale for val in best_face]
                    cx = int(x + bw / 2)
                    cy = int(y + bh / 2)
                    return {
                        "bbox": (int(x), int(y), int(bw), int(bh)),
                        "landmarks": None,
                        "angle": 0.0,
                        "center": (cx, cy),
                        "method": "haar"
                    }
            except Exception as e:
                print(f"[FaceEngine] Haar detection error: {e}")

        # Default fallback: center box
        return {
            "bbox": (int(orig_w * 0.25), int(orig_h * 0.2), int(orig_w * 0.5), int(orig_h * 0.5)),
            "landmarks": None,
            "angle": 0.0,
            "center": (int(orig_w / 2), int(orig_h * 0.45)),
            "method": "fallback_center"
        }

    def align_and_crop(self, pil_img, target_w=1062, target_h=1416, face_ratio=0.68, top_margin_ratio=0.10):
        """
        Aligns eyes horizontally (leveling head upright) and crops to natural, balanced posture.
        - face_ratio: 0.68 for natural headroom and balanced shoulder width.
        - top_margin_ratio: 0.10 (10% headroom).
        """
        pil_img = ImageOps.exif_transpose(pil_img)
        orig_w, orig_h = pil_img.size

        cv_img = cv2.cvtColor(np.array(pil_img.convert("RGB")), cv2.COLOR_RGB2BGR)
        face_info = self.detect_face(cv_img)

        # 1. Level head upright: Rotate with +angle around eye midpoint
        angle = face_info.get("angle", 0.0)
        if abs(angle) > 0.5 and abs(angle) < 25.0 and face_info.get("landmarks") is not None:
            re = face_info["landmarks"][0]
            le = face_info["landmarks"][1]
            eye_center = (float((re[0] + le[0]) / 2.0), float((re[1] + le[1]) / 2.0))

            # In image coords where Y is down, rotating counter-clockwise with +angle levels the eyes
            pil_img = pil_img.rotate(angle, resample=Image.Resampling.BICUBIC, center=eye_center, expand=False)
            cv_img = cv2.cvtColor(np.array(pil_img.convert("RGB")), cv2.COLOR_RGB2BGR)
            face_info = self.detect_face(cv_img)

        bx, by, bw, bh = face_info["bbox"]
        cx, cy = face_info["center"]

        if face_info.get("landmarks") is not None:
            landmarks = face_info["landmarks"]
            re = landmarks[0]
            le = landmarks[1]
            nose = landmarks[2]
            eye_y = (re[1] + le[1]) / 2.0
            nose_y = nose[1]
            # Chin landmark estimate
            chin_y = nose_y + (nose_y - eye_y) * 1.5
            # Top of head estimate
            top_head_y = max(0, by - bh * 0.28)
            estimated_face_h = max(chin_y - top_head_y, bh * 0.85)
        else:
            top_head_y = max(0, by - bh * 0.28)
            chin_y = by + bh
            estimated_face_h = chin_y - top_head_y

        # Target face height
        target_face_h = target_h * face_ratio
        scale = target_face_h / max(estimated_face_h, 50.0)

        crop_box_h = target_h / scale
        crop_box_w = target_w / scale

        crop_top = top_head_y - (target_h * top_margin_ratio) / scale
        crop_bottom = crop_top + crop_box_h

        crop_left = cx - crop_box_w / 2.0
        crop_right = crop_left + crop_box_w

        # Padding if box exceeds image
        pad_left = max(0, int(-crop_left))
        pad_top = max(0, int(-crop_top))
        pad_right = max(0, int(crop_right - orig_w))
        pad_bottom = max(0, int(crop_bottom - orig_h))

        if pad_left > 0 or pad_top > 0 or pad_right > 0 or pad_bottom > 0:
            padded_img = Image.new(pil_img.mode, (orig_w + pad_left + pad_right, orig_h + pad_top + pad_bottom), (240, 240, 240))
            padded_img.paste(pil_img, (pad_left, pad_top))
            pil_img = padded_img
            crop_left += pad_left
            crop_right += pad_left
            crop_top += pad_top
            crop_bottom += pad_top

        cropped = pil_img.crop((int(crop_left), int(crop_top), int(crop_right), int(crop_bottom)))
        final_img = cropped.resize((target_w, target_h), Image.Resampling.LANCZOS)

        return final_img, face_info
