import cv2
import numpy as np
from PIL import Image

class InpaintEngine:
    def __init__(self):
        pass

    def remove_object(self, pil_img, pil_mask, radius=5):
        """
        Removes object / blemish from image using Telea & Navier-Stokes Inpainting.
        pil_img: RGB PIL Image
        pil_mask: Grayscale or RGBA PIL Image where white (255) is the area to erase.
        radius: inpaint radius in pixels
        """
        cv_img = cv2.cvtColor(np.array(pil_img.convert("RGB")), cv2.COLOR_RGB2BGR)

        # Convert mask to single channel 8-bit
        mask_arr = np.array(pil_mask.convert("L"))
        # Threshold to binary mask
        _, binary_mask = cv2.threshold(mask_arr, 127, 255, cv2.THRESH_BINARY)

        # Inpaint
        inpainted = cv2.inpaint(cv_img, binary_mask, inpaintRadius=radius, flags=cv2.INPAINT_TELEA)

        # Convert back to PIL
        return Image.fromarray(cv2.cvtColor(inpainted, cv2.COLOR_BGR2RGB))
