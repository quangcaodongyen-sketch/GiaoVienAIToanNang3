import os
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont

DPI = 300
CM_TO_PX = DPI / 2.54

PHOTO_SIZES = {
    "2x3": {"cm_w": 2.0, "cm_h": 3.0, "px_w": int(2.0 * CM_TO_PX), "px_h": int(3.0 * CM_TO_PX), "name": "2 x 3 cm"},
    "3x4": {"cm_w": 3.0, "cm_h": 4.0, "px_w": int(3.0 * CM_TO_PX), "px_h": int(4.0 * CM_TO_PX), "name": "3 x 4 cm (Phổ biến)"},
    "4x6": {"cm_w": 4.0, "cm_h": 6.0, "px_w": int(4.0 * CM_TO_PX), "px_h": int(6.0 * CM_TO_PX), "name": "4 x 6 cm (Hộ chiếu / Bằng lái)"},
    "3.5x4.5": {"cm_w": 3.5, "cm_h": 4.5, "px_w": int(3.5 * CM_TO_PX), "px_h": int(4.5 * CM_TO_PX), "name": "3.5 x 4.5 cm (Visa / Passport quốc tế)"},
    "5x5": {"cm_w": 5.0, "cm_h": 5.0, "px_w": int(5.0 * CM_TO_PX), "px_h": int(5.0 * CM_TO_PX), "name": "5 x 5 cm (Visa Mỹ)"},
}

class PrintSheetEngine:
    def __init__(self):
        self.font = None
        self._init_font()

    def _init_font(self):
        font_paths = [
            "C:/Windows/Fonts/arial.ttf",
            "C:/Windows/Fonts/times.ttf",
            "C:/Windows/Fonts/segoeui.ttf",
        ]
        for p in font_paths:
            if os.path.exists(p):
                try:
                    self.font_path = p
                    return
                except:
                    pass
        self.font_path = None

    def get_font(self, size=24):
        if self.font_path:
            try:
                return ImageFont.truetype(self.font_path, size)
            except:
                pass
        return ImageFont.load_default()

    def create_10x15_combo(self, img_3x4, img_4x6=None, draw_guides=True):
        sheet_w = int(15.0 * CM_TO_PX)
        sheet_h = int(10.0 * CM_TO_PX)

        sheet = Image.new("RGB", (sheet_w, sheet_h), (255, 255, 255))
        draw = ImageDraw.Draw(sheet)

        p34_w = PHOTO_SIZES["3x4"]["px_w"]
        p34_h = PHOTO_SIZES["3x4"]["px_h"]
        p46_w = PHOTO_SIZES["4x6"]["px_w"]
        p46_h = PHOTO_SIZES["4x6"]["px_h"]

        p34 = img_3x4.resize((p34_w, p34_h), Image.Resampling.LANCZOS).convert("RGB")
        p46 = img_4x6.resize((p46_w, p46_h), Image.Resampling.LANCZOS).convert("RGB") if img_4x6 else img_3x4.resize((p46_w, p46_h), Image.Resampling.LANCZOS).convert("RGB")

        margin_x = int(0.5 * CM_TO_PX)
        margin_y = int(0.4 * CM_TO_PX)
        gap = int(0.2 * CM_TO_PX)

        # 4 photos of 3x4
        for row in range(2):
            for col in range(2):
                x = margin_x + col * (p34_w + gap)
                y = margin_y + row * (p34_h + gap)
                sheet.paste(p34, (x, y))
                if draw_guides:
                    draw.rectangle([x-1, y-1, x + p34_w, y + p34_h], outline=(220, 220, 220), width=1)

        # 2 photos of 4x6
        right_start_x = margin_x + 2 * (p34_w + gap) + int(0.3 * CM_TO_PX)
        for col in range(2):
            x = right_start_x + col * (p46_w + gap)
            y = margin_y + int((sheet_h - margin_y*2 - p46_h) / 2)
            if x + p46_w <= sheet_w:
                sheet.paste(p46, (x, y))
                if draw_guides:
                    draw.rectangle([x-1, y-1, x + p46_w, y + p46_h], outline=(220, 220, 220), width=1)

        return sheet

    def create_10x15_single_size(self, img, size_key="3x4", draw_guides=True):
        sheet_w = int(15.0 * CM_TO_PX)
        sheet_h = int(10.0 * CM_TO_PX)
        sheet = Image.new("RGB", (sheet_w, sheet_h), (255, 255, 255))
        draw = ImageDraw.Draw(sheet)

        spec = PHOTO_SIZES.get(size_key, PHOTO_SIZES["3x4"])
        pw, ph = spec["px_w"], spec["px_h"]
        resized_img = img.resize((pw, ph), Image.Resampling.LANCZOS).convert("RGB")

        gap = int(0.25 * CM_TO_PX)
        cols = int((sheet_w - gap) / (pw + gap))
        rows = int((sheet_h - gap) / (ph + gap))

        grid_w = cols * pw + (cols - 1) * gap
        grid_h = rows * ph + (rows - 1) * gap
        start_x = max(0, int((sheet_w - grid_w) / 2))
        start_y = max(0, int((sheet_h - grid_h) / 2))

        for r in range(rows):
            for c in range(cols):
                x = start_x + c * (pw + gap)
                y = start_y + r * (ph + gap)
                sheet.paste(resized_img, (x, y))
                if draw_guides:
                    draw.rectangle([x-1, y-1, x + pw, y + ph], outline=(220, 220, 220), width=1)

        return sheet

    def create_a4_class_sheet(self, student_items, size_key="3x4", draw_guides=True):
        a4_w = int(21.0 * CM_TO_PX)
        a4_h = int(29.7 * CM_TO_PX)

        sheet = Image.new("RGB", (a4_w, a4_h), (255, 255, 255))
        draw = ImageDraw.Draw(sheet)

        spec = PHOTO_SIZES.get(size_key, PHOTO_SIZES["3x4"])
        pw, ph = spec["px_w"], spec["px_h"]
        label_h = int(0.5 * CM_TO_PX)

        cell_w = pw
        cell_h = ph + label_h

        gap_x = int(0.4 * CM_TO_PX)
        gap_y = int(0.4 * CM_TO_PX)

        cols = int((a4_w - gap_x) / (cell_w + gap_x))
        rows = int((a4_h - gap_y) / (cell_h + gap_y))

        start_x = int((a4_w - (cols * cell_w + (cols - 1) * gap_x)) / 2)
        start_y = int((a4_h - (rows * cell_h + (rows - 1) * gap_y)) / 2)

        font = self.get_font(28)

        idx = 0
        for r in range(rows):
            for c in range(cols):
                if idx >= len(student_items):
                    break
                item = student_items[idx]
                p_img = item["img"].resize((pw, ph), Image.Resampling.LANCZOS).convert("RGB")
                name = item.get("name", "")

                x = start_x + c * (cell_w + gap_x)
                y = start_y + r * (cell_h + gap_y)

                sheet.paste(p_img, (x, y))
                if draw_guides:
                    draw.rectangle([x-1, y-1, x + pw, y + ph], outline=(220, 220, 220), width=1)

                if name and label_h > 0:
                    text_y = y + ph + 8
                    draw.text((x + pw/2, text_y), name, fill=(20, 20, 20), font=font, anchor="mt")

                idx += 1
            if idx >= len(student_items):
                break

        return sheet
