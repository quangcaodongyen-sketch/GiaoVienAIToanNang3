/**
 * StudioAI Pro - Master Frontend Controller
 * Nền tảng chỉnh sửa & xử lý ảnh AI toàn năng - Thầy giáo Đinh Văn Thành
 */

document.addEventListener('DOMContentLoaded', () => {
  // ==========================================
  // Application State
  // ==========================================
  const state = {
    items: [],
    activeId: null,
    activeView: 'view_image_edit',
    activeTool: 'id_photo',
    viewMode: 'split', // 'split' or 'single'
    isBatchProcessing: false,
    settings: {
      size_key: '3x4',
      bg_preset: 'blue_studio_radial',
      custom_bg_hex: null,
      clothing_id: 'none',
      clothes_scale: 1.0,
      clothes_y_offset: 0,
      skin_smooth: 25,
      brightness: 6,
      contrast: 6,
      sharpness: 20,
      preset_id: 'hoc_sinh_2'
    }
  };

  // Canvas drawing state for Generative Fill (Magic Eraser)
  const eraserState = {
    isDrawing: false,
    history: [],
    brushSize: 30
  };

  // Presets mapping with prompts and clothing overlay
  const PRESET_DEFINITIONS = {
    'quan_phuc': {
      prompt: 'Trang phục: Quân phục nghiêm trang. Màu nền: Xanh studio 0084ff. Căn chỉnh vai ngay ngắn, nhìn thẳng ống kính.',
      clothing_id: 'vest_nu_den',
      bg_preset: 'blue_standard'
    },
    'hoc_sinh_2': {
      prompt: 'Màu nền: Màu xanh 0084ff. Chi tiết: giữ kiểu tóc nguyên bản, Làn da mịn màng, tươi sáng và sắc nét.',
      clothing_id: 'none',
      bg_preset: 'blue_studio_radial'
    },
    'anh_the_can_cuoc': {
      prompt: 'Trang phục: Áo sơ mi có cổ lịch sự. Màu nền: Trắng tinh chuẩn CCCD / Hộ chiếu. Giữ nguyên tóc, khuôn mặt nhìn thẳng.',
      clothing_id: 'so_mi_nam_trang',
      bg_preset: 'white_cccd'
    },
    'so_mi_xanh_nhat': {
      prompt: 'Trang phục: Áo sơ mi màu xanh nhạt thanh lịch. Màu nền: Xanh studio. Da mịn màng tự nhiên.',
      clothing_id: 'so_mi_nam_trang',
      bg_preset: 'blue_light'
    },
    'ao_so_mi_polo': {
      prompt: 'Trang phục: Áo sơ mi polo có cổ trẻ trung. Màu nền: Xanh nhạt. Căn thẳng mặt, mắt nhìn thẳng camera.',
      clothing_id: 'none',
      bg_preset: 'blue_light'
    },
    'ao_vest_cong_so': {
      prompt: 'Trang phục: Áo vest đen công sở kèm sơ mi trắng. Màu nền: Xanh 0084ff studio. Phong thái chuyên nghiệp.',
      clothing_id: 'vest_nam_den',
      bg_preset: 'blue_standard'
    },
    'ao_so_mi_nu': {
      prompt: 'Trang phục: Áo sơ mi trắng nữ công sở. Màu nền: Trắng hoặc xanh studio. Nét mặt tươi tắn, thanh lịch.',
      clothing_id: 'so_mi_nam_trang',
      bg_preset: 'white_cccd'
    },
    'ao_co_no': {
      prompt: 'Trang phục: Áo cổ nơ duyên dáng. Màu nền: Xanh studio tỏa sáng. Nét mặt rạng rỡ, sắc nét.',
      clothing_id: 'vest_nu_den',
      bg_preset: 'blue_studio_radial'
    }
  };

  // ==========================================
  // DOM Elements
  // ==========================================
  const emptyBox = document.getElementById('emptyBox');
  const activeStageView = document.getElementById('activeStageView');
  const dropArea = document.getElementById('dropArea');
  const fileInput = document.getElementById('fileInput');
  const btnBrowseFolder = document.getElementById('btnBrowseFolder');
  const btnEmptyBrowse = document.getElementById('btnEmptyBrowse');
  const btnClearAll = document.getElementById('btnClearAll');
  const btnExportZip = document.getElementById('btnExportZip');
  const btnProcessBatch = document.getElementById('btnProcessBatch');
  const btnApplyAll = document.getElementById('btnApplyAll');
  const btnDownloadCurrent = document.getElementById('btnDownloadCurrent');
  const btnSwitchViewMode = document.getElementById('btnSwitchViewMode');
  const btnThemeToggle = document.getElementById('btnThemeToggle');
  const btnOpenPrintLab = document.getElementById('btnOpenPrintLab');
  const bottomCarousel = document.getElementById('bottomCarousel');
  const carouselTrack = document.getElementById('carouselTrack');
  const progressTrack = document.getElementById('progressTrack');
  const progressLabel = document.getElementById('progressLabel');
  const progressVal = document.getElementById('progressVal');
  const progressFill = document.getElementById('progressFill');

  // Split Viewport Elements
  const splitViewport = document.getElementById('splitViewport');
  const stageBeforeLayer = document.getElementById('stageBeforeLayer');
  const stageDivider = document.getElementById('stageDivider');
  const stageImgBefore = document.getElementById('stageImgBefore');
  const stageImgAfter = document.getElementById('stageImgAfter');

  // Inpaint Canvas
  const inpaintCanvas = document.getElementById('inpaintCanvas');
  const eraserToolbar = document.getElementById('eraserToolbar');
  const brushSizeInput = document.getElementById('brushSize');
  const valBrushSize = document.getElementById('valBrushSize');
  const btnUndoEraser = document.getElementById('btnUndoEraser');
  const btnApplyEraser = document.getElementById('btnApplyEraser');
  let inpaintCtx = inpaintCanvas ? inpaintCanvas.getContext('2d') : null;

  // Prompt Box
  const txtPrompt = document.getElementById('txtPrompt');
  const btnVoicePrompt = document.getElementById('btnVoicePrompt');
  const btnCopyPrompt = document.getElementById('btnCopyPrompt');
  const btnExpandPrompt = document.getElementById('btnExpandPrompt');

  // Sliders
  const rngSkinSmooth = document.getElementById('rngSkinSmooth');
  const lblSkinSmooth = document.getElementById('lblSkinSmooth');
  const rngBrightness = document.getElementById('rngBrightness');
  const lblBrightness = document.getElementById('lblBrightness');
  const rngContrast = document.getElementById('rngContrast');
  const lblContrast = document.getElementById('lblContrast');
  const rngSharpness = document.getElementById('rngSharpness');
  const lblSharpness = document.getElementById('lblSharpness');

  // Print Modal
  const printModal = document.getElementById('printModal');
  const btnClosePrint = document.getElementById('btnClosePrint');
  const selSheetType = document.getElementById('selSheetType');
  const chkGuides = document.getElementById('chkGuides');
  const btnGeneratePrintSheet = document.getElementById('btnGeneratePrintSheet');
  const imgSheetPreview = document.getElementById('imgSheetPreview');
  const btnDownloadPrintFile = document.getElementById('btnDownloadPrintFile');

  // ==========================================
  // Helper: Toast Notifications
  // ==========================================
  function showToast(message, type = 'info') {
    const existing = document.getElementById('studioToast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.id = 'studioToast';
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      left: 50%;
      transform: translateX(-50%);
      background: ${type === 'error' ? '#EF4444' : type === 'success' ? '#10B981' : '#FA541C'};
      color: #FFFFFF;
      padding: 10px 22px;
      border-radius: 9999px;
      font-size: 13.5px;
      font-weight: 700;
      box-shadow: 0 10px 30px rgba(0,0,0,0.35);
      z-index: 9999;
      pointer-events: none;
      animation: fadeIn 0.2s ease;
      display: flex;
      align-items: center;
      gap: 8px;
    `;
    toast.innerHTML = `<span>${type === 'error' ? '⚠️' : type === 'success' ? '✅' : '✨'}</span> ${message}`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3200);
  }

  // ==========================================
  // View Switching (Tab Controller)
  // ==========================================
  function switchView(viewId) {
    state.activeView = viewId;

    // Update top nav tabs
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.view === viewId);
    });

    // Toggle view containers
    document.querySelectorAll('.main-view-container').forEach(container => {
      container.classList.toggle('active', container.id === viewId);
    });

    if (viewId === 'view_image_edit') {
      requestAnimationFrame(syncSplitViewport);
    }
  }

  document.querySelectorAll('.nav-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.dataset.view) {
        switchView(btn.dataset.view);
      }
    });
  });

  document.querySelectorAll('[data-view-target]').forEach(el => {
    el.addEventListener('click', () => {
      const target = el.dataset.viewTarget;
      if (target) switchView(target);
    });
  });

  document.getElementById('btnLogoHome')?.addEventListener('click', () => {
    switchView('view_image_edit');
  });

  document.getElementById('btnAdminBadge')?.addEventListener('click', () => {
    switchView('view_admin_billing');
  });

  document.getElementById('userProfileBtn')?.addEventListener('click', () => {
    switchView('view_admin_billing');
  });

  // ==========================================
  // Active Item & Viewports
  // ==========================================
  function getActiveItem() {
    return state.items.find(it => it.id === state.activeId) || null;
  }

  function updateViewports() {
    const item = getActiveItem();
    if (!item) {
      emptyBox.style.display = 'block';
      activeStageView.style.display = 'none';
      bottomCarousel.style.display = 'none';
      return;
    }

    emptyBox.style.display = 'none';
    activeStageView.style.display = 'flex';
    bottomCarousel.style.display = 'block';

    const beforeSrc = item.original_cropped_url || item.preview_url;
    const afterSrc = item.processed_url || item.preview_url;

    stageImgBefore.src = beforeSrc;
    stageImgAfter.src = afterSrc;

    if (item.download_url) {
      btnDownloadCurrent.href = item.download_url;
      btnDownloadCurrent.setAttribute('download', `anh_the_${item.filename}`);
      btnDownloadCurrent.style.opacity = '1';
      btnDownloadCurrent.style.pointerEvents = 'auto';
    } else {
      btnDownloadCurrent.href = '#';
      btnDownloadCurrent.style.opacity = '0.5';
      btnDownloadCurrent.style.pointerEvents = 'none';
    }

    requestAnimationFrame(syncSplitViewport);
  }

  function syncSplitViewport() {
    if (!splitViewport) return;
    const vpWidth = splitViewport.clientWidth;
    splitViewport.style.setProperty('--viewport-w', `${vpWidth}px`);
    if (inpaintCanvas) {
      inpaintCanvas.width = vpWidth;
      inpaintCanvas.height = splitViewport.clientHeight;
    }
  }

  window.addEventListener('resize', syncSplitViewport);

  // ==========================================
  // Split Comparison Slider Logic
  // ==========================================
  let isDraggingSplit = false;

  function setSplitPercent(pct) {
    pct = Math.max(5, Math.min(95, pct));
    stageBeforeLayer.style.width = `${pct}%`;
    stageDivider.style.left = `${pct}%`;
  }

  function onSplitMove(e) {
    if (!isDraggingSplit || !splitViewport) return;
    const rect = splitViewport.getBoundingClientRect();
    const clientX = e.clientX || (e.touches && e.touches[0].clientX);
    if (!clientX) return;
    const offset = clientX - rect.left;
    const pct = (offset / rect.width) * 100;
    setSplitPercent(pct);
  }

  stageDivider.addEventListener('mousedown', (e) => {
    isDraggingSplit = true;
    document.body.style.cursor = 'ew-resize';
    e.preventDefault();
  });

  window.addEventListener('mousemove', onSplitMove);
  window.addEventListener('mouseup', () => {
    if (isDraggingSplit) {
      isDraggingSplit = false;
      document.body.style.cursor = 'default';
    }
  });

  stageDivider.addEventListener('touchstart', (e) => {
    isDraggingSplit = true;
    e.preventDefault();
  });
  window.addEventListener('touchmove', onSplitMove);
  window.addEventListener('touchend', () => {
    isDraggingSplit = false;
  });

  btnSwitchViewMode.addEventListener('click', () => {
    if (state.viewMode === 'split') {
      state.viewMode = 'single';
      stageBeforeLayer.style.display = 'none';
      stageDivider.style.display = 'none';
      btnSwitchViewMode.textContent = '⇹ Xem So Sánh';
    } else {
      state.viewMode = 'split';
      stageBeforeLayer.style.display = 'block';
      stageDivider.style.display = 'block';
      setSplitPercent(50);
      btnSwitchViewMode.textContent = '⇹ Chỉ Xem Ảnh Đã Xử Lý';
    }
  });

  // ==========================================
  // Carousel Render
  // ==========================================
  function renderCarousel() {
    carouselTrack.innerHTML = '';
    state.items.forEach((it, idx) => {
      const card = document.createElement('div');
      card.className = `carousel-card ${it.id === state.activeId ? 'active' : ''} ${it.status}`;
      card.dataset.id = it.id;

      const img = document.createElement('img');
      img.src = it.thumb_url || it.preview_url;
      img.alt = it.filename;

      const badge = document.createElement('div');
      badge.className = 'card-badge';
      badge.textContent = it.status === 'done' ? '✓ Xong' : it.status === 'processing' ? '⚡ Đang chạy' : (idx + 1);

      card.appendChild(img);
      card.appendChild(badge);

      card.addEventListener('click', () => {
        state.activeId = it.id;
        renderCarousel();
        updateViewports();
      });

      carouselTrack.appendChild(card);
    });
  }

  // ==========================================
  // Preset Selection (Exact 8 items from Screenshot 5)
  // ==========================================
  document.querySelectorAll('.preset-card').forEach(card => {
    card.addEventListener('click', () => {
      document.querySelectorAll('.preset-card').forEach(c => c.classList.remove('active'));
      card.classList.add('active');

      const presetId = card.dataset.preset;
      state.settings.preset_id = presetId;

      if (PRESET_DEFINITIONS[presetId]) {
        const def = PRESET_DEFINITIONS[presetId];
        txtPrompt.value = def.prompt;
        state.settings.clothing_id = def.clothing_id;
        state.settings.bg_preset = def.bg_preset;

        // Highlight matching bg dot
        document.querySelectorAll('.bg-dot-btn').forEach(btn => {
          btn.classList.toggle('active', btn.dataset.bg === def.bg_preset);
        });

        showToast(`Đã áp dụng mẫu: ${card.querySelector('.preset-label').textContent}`, 'info');
        triggerCurrentUpdate();
      }
    });
  });

  // Size pills
  document.querySelectorAll('.size-pill-mini').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.size-pill-mini').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.settings.size_key = btn.dataset.size;
      triggerCurrentUpdate();
    });
  });

  // Background dots
  document.querySelectorAll('.bg-dot-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.bg-dot-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      state.settings.bg_preset = btn.dataset.bg;
      triggerCurrentUpdate();
    });
  });

  // Tuning sliders
  rngSkinSmooth.addEventListener('input', (e) => {
    state.settings.skin_smooth = parseInt(e.target.value);
    lblSkinSmooth.textContent = `${e.target.value}%`;
    triggerCurrentUpdate();
  });

  rngBrightness.addEventListener('input', (e) => {
    const val = parseInt(e.target.value);
    state.settings.brightness = val;
    lblBrightness.textContent = val >= 0 ? `+${val}` : `${val}`;
    triggerCurrentUpdate();
  });

  rngContrast.addEventListener('input', (e) => {
    const val = parseInt(e.target.value);
    state.settings.contrast = val;
    lblContrast.textContent = val >= 0 ? `+${val}` : `${val}`;
    triggerCurrentUpdate();
  });

  rngSharpness.addEventListener('input', (e) => {
    state.settings.sharpness = parseInt(e.target.value);
    lblSharpness.textContent = `${e.target.value}%`;
    triggerCurrentUpdate();
  });

  // Copy Prompt
  btnCopyPrompt.addEventListener('click', () => {
    navigator.clipboard.writeText(txtPrompt.value).then(() => {
      showToast('Đã sao chép prompt yêu cầu chỉnh sửa!', 'success');
    });
  });

  // Voice Prompt Simulation
  btnVoicePrompt.addEventListener('click', () => {
    showToast('Đang lắng nghe giọng nói Thầy Thành... "Làm ảnh thẻ nền xanh áo sơ mi trắng"', 'info');
    setTimeout(() => {
      txtPrompt.value = "Yêu cầu: Màu nền xanh studio 0084ff, áo sơ mi trắng học sinh, da mịn màng, mắt nhìn thẳng.";
      showToast('Đã nhận diện giọng nói thành công!', 'success');
    }, 1500);
  });

  // ==========================================
  // Processing Logic
  // ==========================================
  async function processItem(itemId) {
    const item = state.items.find(i => i.id === itemId);
    if (!item) return;

    item.status = 'processing';
    renderCarousel();

    try {
      const payload = {
        item_id: item.id,
        size_key: state.settings.size_key,
        bg_preset: state.settings.bg_preset,
        custom_bg_hex: state.settings.custom_bg_hex,
        clothing_id: state.settings.clothing_id,
        clothes_scale: state.settings.clothes_scale,
        clothes_y_offset: state.settings.clothes_y_offset,
        skin_smooth: state.settings.skin_smooth,
        brightness: state.settings.brightness,
        contrast: state.settings.contrast,
        sharpness: state.settings.sharpness
      };

      const res = await fetch('/api/process-item', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || 'Lỗi xử lý ảnh');
      }

      const updated = await res.json();
      Object.assign(item, updated);
      item.status = 'done';
    } catch (err) {
      console.error(err);
      item.status = 'error';
      showToast(`Lỗi ảnh ${item.filename}: ${err.message}`, 'error');
    } finally {
      renderCarousel();
      if (item.id === state.activeId) {
        updateViewports();
      }
    }
  }

  // Batch Process Button (✨ Tạo ảnh / Enter)
  btnProcessBatch.addEventListener('click', async () => {
    if (state.items.length === 0) {
      showToast('Vui lòng chọn ảnh thẻ trước khi tạo ảnh!', 'error');
      return;
    }

    state.isBatchProcessing = true;
    progressTrack.style.display = 'flex';
    btnProcessBatch.disabled = true;

    const total = state.items.length;
    for (let i = 0; i < total; i++) {
      const it = state.items[i];
      const pct = Math.round(((i) / total) * 100);
      progressLabel.textContent = `Đang xử lý: ${it.filename} (${i + 1}/${total})...`;
      progressVal.textContent = `${pct}%`;
      progressFill.style.width = `${pct}%`;

      await processItem(it.id);
    }

    progressLabel.textContent = `Hoàn thành xử lý toàn bộ ${total} ảnh!`;
    progressVal.textContent = '100%';
    progressFill.style.width = '100%';
    showToast(`Đã tạo thành công ${total} ảnh thẻ chất lượng cao!`, 'success');

    state.isBatchProcessing = false;
    btnProcessBatch.disabled = false;
    setTimeout(() => {
      progressTrack.style.display = 'none';
    }, 4000);
  });

  // Keyboard Enter Trigger
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !['TEXTAREA', 'INPUT'].includes(e.target.tagName)) {
      e.preventDefault();
      btnProcessBatch.click();
    }
  });

  btnApplyAll.addEventListener('click', () => {
    if (!state.activeId) return;
    btnProcessBatch.click();
  });

  let debounceTimer = null;
  function triggerCurrentUpdate() {
    if (!state.activeId || state.isBatchProcessing) return;
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      processItem(state.activeId);
    }, 400);
  }

  // ==========================================
  // Left Sidebar Tools Switching
  // ==========================================
  document.querySelectorAll('.menu-item').forEach(item => {
    item.addEventListener('click', () => {
      document.querySelectorAll('.menu-item').forEach(m => m.classList.remove('active'));
      item.classList.add('active');

      const tool = item.dataset.tool;
      state.activeTool = tool;

      if (tool === 'generative_fill') {
        inpaintCanvas.style.display = 'block';
        eraserToolbar.style.display = 'flex';
        syncSplitViewport();
        showToast('Chế độ Generative Fill: Dùng cọ vẽ đỏ lên vùng cần xóa/điền!', 'info');
      } else {
        inpaintCanvas.style.display = 'none';
        eraserToolbar.style.display = 'none';
      }

      if (tool === 'trang_phuc') {
        showToast('Chế độ Thay trang phục: Chọn mẫu vest, áo sơ mi hoặc quân phục ở cột bên phải!', 'info');
      }
    });
  });

  // ==========================================
  // Generative Fill (Inpaint Canvas)
  // ==========================================
  function setupInpaintCanvas() {
    if (!inpaintCanvas) return;

    function getCoords(e) {
      const rect = inpaintCanvas.getBoundingClientRect();
      const clientX = e.clientX || (e.touches && e.touches[0].clientX);
      const clientY = e.clientY || (e.touches && e.touches[0].clientY);
      return {
        x: clientX - rect.left,
        y: clientY - rect.top
      };
    }

    function startDraw(e) {
      if (state.activeTool !== 'generative_fill') return;
      eraserState.isDrawing = true;
      const { x, y } = getCoords(e);

      eraserState.history.push(inpaintCtx.getImageData(0, 0, inpaintCanvas.width, inpaintCanvas.height));

      inpaintCtx.beginPath();
      inpaintCtx.moveTo(x, y);
      inpaintCtx.lineCap = 'round';
      inpaintCtx.lineJoin = 'round';
      inpaintCtx.lineWidth = eraserState.brushSize;
      inpaintCtx.strokeStyle = 'rgba(250, 84, 28, 0.7)';
    }

    function draw(e) {
      if (!eraserState.isDrawing || state.activeTool !== 'generative_fill') return;
      const { x, y } = getCoords(e);
      inpaintCtx.lineTo(x, y);
      inpaintCtx.stroke();
    }

    function stopDraw() {
      if (eraserState.isDrawing) {
        eraserState.isDrawing = false;
        inpaintCtx.closePath();
      }
    }

    inpaintCanvas.addEventListener('mousedown', startDraw);
    inpaintCanvas.addEventListener('mousemove', draw);
    window.addEventListener('mouseup', stopDraw);

    inpaintCanvas.addEventListener('touchstart', startDraw);
    inpaintCanvas.addEventListener('touchmove', draw);
    window.addEventListener('touchend', stopDraw);
  }

  setupInpaintCanvas();

  brushSizeInput.addEventListener('input', (e) => {
    eraserState.brushSize = parseInt(e.target.value);
    valBrushSize.textContent = `${e.target.value}px`;
  });

  btnUndoEraser.addEventListener('click', () => {
    if (eraserState.history.length > 0) {
      const prev = eraserState.history.pop();
      inpaintCtx.putImageData(prev, 0, 0);
    } else {
      inpaintCtx.clearRect(0, 0, inpaintCanvas.width, inpaintCanvas.height);
    }
  });

  btnApplyEraser.addEventListener('click', async () => {
    const item = getActiveItem();
    if (!item) return;

    const offscreen = document.createElement('canvas');
    offscreen.width = inpaintCanvas.width;
    offscreen.height = inpaintCanvas.height;
    const offCtx = offscreen.getContext('2d');

    offCtx.fillStyle = '#000000';
    offCtx.fillRect(0, 0, offscreen.width, offscreen.height);

    const maskData = inpaintCtx.getImageData(0, 0, inpaintCanvas.width, inpaintCanvas.height);
    const destData = offCtx.getImageData(0, 0, offscreen.width, offscreen.height);

    let painted = 0;
    for (let i = 0; i < maskData.data.length; i += 4) {
      if (maskData.data[i + 3] > 20) {
        destData.data[i] = 255;
        destData.data[i + 1] = 255;
        destData.data[i + 2] = 255;
        destData.data[i + 3] = 255;
        painted++;
      }
    }

    if (painted === 0) {
      showToast('Vui lòng dùng cọ vẽ lên vùng cần xóa!', 'error');
      return;
    }

    offCtx.putImageData(destData, 0, 0);
    const maskB64 = offscreen.toDataURL('image/png');

    btnApplyEraser.disabled = true;
    btnApplyEraser.textContent = '⏳ Đang Xóa...';

    try {
      const res = await fetch('/api/inpaint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ item_id: item.id, mask_b64: maskB64 })
      });

      if (!res.ok) throw new Error('Lỗi từ dịch vụ xóa vật thể');
      const data = await res.json();
      item.processed_url = data.processed_url;
      updateViewports();
      inpaintCtx.clearRect(0, 0, inpaintCanvas.width, inpaintCanvas.height);
      eraserState.history = [];
      showToast('Đã xóa vật thể thành công!', 'success');
    } catch (err) {
      showToast(`Không thể xóa: ${err.message}`, 'error');
    } finally {
      btnApplyEraser.disabled = false;
      btnApplyEraser.textContent = '✨ Xóa Vật Thể Ngay';
    }
  });

  // ==========================================
  // Print Modal
  // ==========================================
  function openPrintModal() {
    printModal.style.display = 'flex';
    generatePrintSheet();
  }

  btnOpenPrintLab.addEventListener('click', openPrintModal);
  btnClosePrint.addEventListener('click', () => {
    printModal.style.display = 'none';
  });

  async function generatePrintSheet() {
    btnGeneratePrintSheet.disabled = true;
    btnGeneratePrintSheet.textContent = '⏳ Đang Tạo...';

    try {
      const res = await fetch('/api/create-print-sheet', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sheet_type: selSheetType.value,
          item_id: state.activeId,
          size_key: state.settings.size_key,
          draw_guides: chkGuides.checked
        })
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || 'Lỗi tạo khổ in');
      }

      const data = await res.json();
      imgSheetPreview.src = data.sheet_url;
      btnDownloadPrintFile.href = data.download_url;
      showToast('Đã tạo bản in 300 DPI chuẩn Lab!', 'success');
    } catch (err) {
      showToast(`Không thể tạo bản in: ${err.message}`, 'error');
    } finally {
      btnGeneratePrintSheet.disabled = false;
      btnGeneratePrintSheet.textContent = '⚡ Tạo Bản In Ngay';
    }
  }

  btnGeneratePrintSheet.addEventListener('click', generatePrintSheet);
  selSheetType.addEventListener('change', generatePrintSheet);
  chkGuides.addEventListener('change', generatePrintSheet);

  // ==========================================
  // Folder Ingestion & File Upload
  // ==========================================
  async function triggerBrowseFolder() {
    try {
      showToast('Đang mở hộp thoại Windows Explorer...', 'info');
      const res = await fetch('/api/browse-folder', { method: 'POST' });
      const data = await res.json();

      if (data.cancelled) return;

      if (data.items && data.items.length > 0) {
        data.items.forEach(it => {
          if (!state.items.some(existing => existing.id === it.id)) {
            state.items.push(it);
          }
        });
        if (!state.activeId) state.activeId = data.items[0].id;
        renderCarousel();
        updateViewports();
        showToast(`Đã nạp ${data.items.length} ảnh từ thư mục!`, 'success');
        processItem(state.activeId);
      } else {
        showToast('Không tìm thấy tệp ảnh nào trong thư mục đã chọn', 'error');
      }
    } catch (err) {
      showToast(`Lỗi chọn thư mục: ${err.message}`, 'error');
    }
  }

  btnBrowseFolder.addEventListener('click', triggerBrowseFolder);
  btnEmptyBrowse.addEventListener('click', triggerBrowseFolder);

  async function uploadFiles(fileList) {
    if (!fileList || fileList.length === 0) return;

    const formData = new FormData();
    for (let i = 0; i < fileList.length; i++) {
      formData.append('files', fileList[i]);
    }

    showToast(`Đang tải lên ${fileList.length} ảnh...`, 'info');
    try {
      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData
      });

      if (!res.ok) throw new Error('Lỗi khi tải ảnh lên');
      const newItems = await res.json();

      newItems.forEach(it => state.items.push(it));
      if (!state.activeId && newItems.length > 0) {
        state.activeId = newItems[0].id;
      }

      renderCarousel();
      updateViewports();
      showToast(`Đã nạp thành công ${newItems.length} ảnh!`, 'success');
      if (newItems.length > 0) {
        processItem(newItems[0].id);
      }
    } catch (err) {
      showToast(`Không thể tải ảnh: ${err.message}`, 'error');
    }
  }

  fileInput.addEventListener('change', (e) => uploadFiles(e.target.files));

  dropArea.addEventListener('dragover', (e) => {
    e.preventDefault();
    emptyBox.classList.add('drag-over');
  });

  dropArea.addEventListener('dragleave', () => {
    emptyBox.classList.remove('drag-over');
  });

  dropArea.addEventListener('drop', (e) => {
    e.preventDefault();
    emptyBox.classList.remove('drag-over');
    if (e.dataTransfer && e.dataTransfer.files) {
      uploadFiles(e.dataTransfer.files);
    }
  });

  // Sample Chips
  document.querySelectorAll('.sample-chip').forEach(btn => {
    btn.addEventListener('click', async () => {
      const sample = btn.dataset.sample;
      try {
        const res = await fetch(`/api/load-sample?sample_id=${sample}`);
        if (!res.ok) throw new Error('Không tìm thấy ảnh mẫu');
        const item = await res.json();
        state.items.push(item);
        state.activeId = item.id;
        renderCarousel();
        updateViewports();
        processItem(item.id);
      } catch (err) {
        showToast(`Lỗi nạp mẫu: ${err.message}`, 'error');
      }
    });
  });

  // Clear All
  btnClearAll.addEventListener('click', async () => {
    if (!confirm('Thầy có chắc muốn xóa danh sách toàn bộ ảnh đang làm việc?')) return;
    try {
      await fetch('/api/clear-all', { method: 'DELETE' });
      state.items = [];
      state.activeId = null;
      renderCarousel();
      updateViewports();
      showToast('Đã dọn sạch danh sách làm việc', 'info');
    } catch (err) {
      console.error(err);
    }
  });

  // Export Zip
  btnExportZip.addEventListener('click', () => {
    const hasDone = state.items.some(it => it.status === 'done');
    if (!hasDone) {
      showToast('Chưa có ảnh nào được xử lý xong để xuất ZIP!', 'error');
      return;
    }
    showToast('Đang nén toàn bộ ảnh vào file ZIP...', 'info');
    window.location.href = '/api/export-zip';
  });

  // Theme Toggle
  btnThemeToggle.addEventListener('click', () => {
    const isDark = document.body.classList.contains('theme-dark');
    if (isDark) {
      document.body.classList.remove('theme-dark');
      btnThemeToggle.textContent = '🌙';
    } else {
      document.body.classList.add('theme-dark');
      btnThemeToggle.textContent = '☀️';
    }
  });

  // Billing Period Buttons
  document.querySelectorAll('.period-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.period-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      showToast(`Đã chọn chu kỳ: ${btn.textContent} (Đã kích hoạt cho Admin)`, 'success');
    });
  });

  // Chat Assistant Interactive Simulation
  const chatMessages = document.getElementById('chatMessages');
  const chatInputTxt = document.getElementById('chatInputTxt');
  const btnSendChat = document.getElementById('btnSendChat');

  function sendChatMessage() {
    const val = chatInputTxt.value.trim();
    if (!val) return;

    // Append User Message
    const userMsg = document.createElement('div');
    userMsg.className = 'chat-msg user-msg';
    userMsg.innerHTML = `<div class="chat-bubble">${val}</div>`;
    chatMessages.appendChild(userMsg);
    chatInputTxt.value = '';
    chatMessages.scrollTop = chatMessages.scrollHeight;

    // AI Response Simulation
    setTimeout(() => {
      const aiMsg = document.createElement('div');
      aiMsg.className = 'chat-msg ai-msg';
      aiMsg.innerHTML = `
        <div class="chat-avatar">🪄</div>
        <div class="chat-bubble">
          Dạ Thầy Thành, tôi đã phân tích yêu cầu: <em>"${val}"</em>.<br>
          Tôi khuyến nghị Thầy áp dụng phông nền <strong>Xanh Studio Radial (#0084ff)</strong> kết hợp tỷ lệ đầu 68% để đạt chuẩn hồ sơ cấp trường &amp; Sở GD&ĐT tối ưu nhất!
        </div>
      `;
      chatMessages.appendChild(aiMsg);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }, 600);
  }

  btnSendChat?.addEventListener('click', sendChatMessage);
  chatInputTxt?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendChatMessage();
  });

  // Text to Image Generator Simulation
  document.getElementById('btnGenImage')?.addEventListener('click', () => {
    const box = document.getElementById('genPreviewBox');
    if (!box) return;
    box.innerHTML = `<p style="color:var(--orange-primary); font-weight:700;">⏳ AI đang kết xuất hình ảnh 8K... (Miễn phí Admin)</p>`;
    setTimeout(() => {
      box.innerHTML = `<img src="/assets/sample_images/sample_nu.jpg" style="max-width:100%; max-height:100%; border-radius:12px; object-fit:contain;" alt="Ảnh AI">`;
      showToast('Đã tạo ảnh AI thành công!', 'success');
    }, 1200);
  });

  // Initial setup
  updateViewports();
});
