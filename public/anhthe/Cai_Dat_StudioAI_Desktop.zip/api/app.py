import os
import sys
import shutil
import io
import time
import zipfile
import base64
from typing import List, Optional

# Ensure UTF-8 output encoding on Windows console
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

from fastapi import FastAPI, File, UploadFile, Form, HTTPException, Query
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from PIL import Image, ImageOps

# Add parent dir to sys.path so core is importable
APP_DIR = os.path.dirname(os.path.abspath(__file__))
WEB_APP_DIR = os.path.dirname(APP_DIR)
sys.path.insert(0, WEB_APP_DIR)

from core.processor import PhotoCardProcessor, MASTER_RESOLUTIONS
from core.background_engine import BACKGROUND_PRESETS
from core.clothing_engine import CLOTHING_PRESETS
from core.print_sheet_engine import PrintSheetEngine, PHOTO_SIZES

STATIC_DIR = os.path.join(WEB_APP_DIR, "static")
UPLOADS_DIR = os.path.join(WEB_APP_DIR, "temp_uploads")
OUTPUTS_DIR = os.path.join(WEB_APP_DIR, "outputs")
ASSETS_DIR = os.path.join(WEB_APP_DIR, "assets")

os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(OUTPUTS_DIR, exist_ok=True)

app = FastAPI(title="StudioAI Pro - Hệ Thống Chỉnh Sửa & Xử Lý Ảnh AI Toàn Năng", description="Nền tảng AI xử lý ảnh đa năng không giới hạn")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

processor = PhotoCardProcessor()
print_engine = PrintSheetEngine()

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
app.mount("/assets", StaticFiles(directory=ASSETS_DIR), name="assets")
app.mount("/outputs", StaticFiles(directory=OUTPUTS_DIR), name="outputs")
app.mount("/temp_uploads", StaticFiles(directory=UPLOADS_DIR), name="temp_uploads")

items_db = {}

def make_web_images(source_path, item_id):
    img = ImageOps.exif_transpose(Image.open(source_path))
    if img.mode != "RGB":
        img = img.convert("RGB")

    w, h = img.size

    # 1. Card Thumbnail (240x320 max)
    thumb = img.copy()
    thumb.thumbnail((240, 320), Image.Resampling.BILINEAR)
    thumb_path = os.path.join(UPLOADS_DIR, f"{item_id}_thumb.jpg")
    thumb.save(thumb_path, "JPEG", quality=80)

    # 2. HD Working Preview (max 1400px)
    preview = img.copy()
    if max(w, h) > 1400:
        preview.thumbnail((1400, 1400), Image.Resampling.BILINEAR)
    preview_path = os.path.join(UPLOADS_DIR, f"{item_id}_preview.jpg")
    preview.save(preview_path, "JPEG", quality=88)

    return {
        "thumb_url": f"/temp_uploads/{item_id}_thumb.jpg",
        "preview_url": f"/temp_uploads/{item_id}_preview.jpg"
    }

@app.get("/", response_class=HTMLResponse)
async def serve_index():
    index_file = os.path.join(STATIC_DIR, "index.html")
    if os.path.exists(index_file):
        with open(index_file, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse("<h1>StudioAI Pro đang khởi động...</h1>")

@app.get("/api/presets")
async def get_presets():
    return {
        "sizes": MASTER_RESOLUTIONS,
        "backgrounds": BACKGROUND_PRESETS,
        "clothes": processor.clothing_engine.get_presets()
    }

@app.get("/api/load-sample")
async def load_sample(sample_id: str = "sample_nam.jpg"):
    sample_path = os.path.join(ASSETS_DIR, "sample_images", sample_id)
    if not os.path.exists(sample_path):
        raise HTTPException(status_code=404, detail="Sample image not found")

    item_id = f"sample_{int(time.time()*1000)}_{sample_id}"
    dest_path = os.path.join(UPLOADS_DIR, f"{item_id}_orig.jpg")
    shutil.copy2(sample_path, dest_path)

    urls = make_web_images(dest_path, item_id)

    item = {
        "id": item_id,
        "filename": sample_id,
        "original_path": dest_path,
        "thumb_url": urls["thumb_url"],
        "preview_url": urls["preview_url"],
        "status": "pending",
        "processed_url": None,
        "original_cropped_url": None,
        "settings": {},
        "elapsed": 0
    }
    items_db[item_id] = item
    return item

@app.post("/api/upload")
async def upload_files(files: List[UploadFile] = File(...)):
    results = []
    timestamp = int(time.time() * 1000)
    for idx, file in enumerate(files):
        if not file.filename.lower().endswith(('.jpg', '.jpeg', '.png', '.webp', '.bmp', '.mpo')):
            continue
        clean_name = os.path.basename(file.filename).replace(' ', '_')
        item_id = f"up_{timestamp}_{idx}_{clean_name}"
        upload_path = os.path.join(UPLOADS_DIR, f"{item_id}_orig.jpg")

        with open(upload_path, "wb") as f:
            content = await file.read()
            f.write(content)

        try:
            urls = make_web_images(upload_path, item_id)
            item = {
                "id": item_id,
                "filename": file.filename,
                "original_path": upload_path,
                "thumb_url": urls["thumb_url"],
                "preview_url": urls["preview_url"],
                "status": "pending",
                "processed_url": None,
                "original_cropped_url": None,
                "settings": {},
                "elapsed": 0
            }
            items_db[item_id] = item
            results.append(item)
        except Exception as e:
            print(f"Error reading image {file.filename}: {e}")

    return results

@app.post("/api/browse-folder")
async def browse_folder():
    selected_dir = None
    try:
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        selected_dir = filedialog.askdirectory(title="Chọn thư mục ảnh thẻ (ví dụ thư mục Anh 1)")
        root.destroy()
    except Exception as e:
        print(f"Error opening folder picker: {e}")

    if not selected_dir:
        return {"cancelled": True, "count": 0, "items": []}

    return scan_folder_path(selected_dir)

class FolderScanRequest(BaseModel):
    folder_path: str

@app.post("/api/scan-folder")
async def scan_folder(req: FolderScanRequest):
    folder = req.folder_path.strip().strip('"').strip("'")
    if not os.path.exists(folder) or not os.path.isdir(folder):
        raise HTTPException(status_code=400, detail="Thư mục không tồn tại trên máy tính")
    return scan_folder_path(folder)

def scan_folder_path(folder):
    results = []
    valid_exts = ('.jpg', '.jpeg', '.png', '.webp', '.bmp', '.mpo')
    timestamp = int(time.time() * 1000)

    try:
        filenames = sorted(os.listdir(folder))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

    for idx, fname in enumerate(filenames):
        if fname.lower().endswith(valid_exts):
            full_path = os.path.join(folder, fname)
            item_id = f"dir_{timestamp}_{idx}_{fname.replace(' ', '_')}"
            try:
                dest_orig = os.path.join(UPLOADS_DIR, f"{item_id}_orig.jpg")
                shutil.copy2(full_path, dest_orig)
                urls = make_web_images(dest_orig, item_id)

                item = {
                    "id": item_id,
                    "filename": fname,
                    "original_path": dest_orig,
                    "thumb_url": urls["thumb_url"],
                    "preview_url": urls["preview_url"],
                    "status": "pending",
                    "processed_url": None,
                    "original_cropped_url": None,
                    "settings": {},
                    "elapsed": 0
                }
                items_db[item_id] = item
                results.append(item)
            except Exception as e:
                print(f"Error reading {full_path}: {e}")

    return {"cancelled": False, "count": len(results), "folder_path": folder, "items": results}

class ProcessItemRequest(BaseModel):
    item_id: str
    size_key: str = "3x4"
    bg_preset: str = "blue_studio_radial"
    custom_bg_hex: Optional[str] = None
    clothing_id: str = "none"
    clothes_scale: float = 1.0
    clothes_y_offset: int = 0
    skin_smooth: int = 25
    brightness: int = 6
    contrast: int = 6
    sharpness: int = 20

@app.post("/api/process-item")
async def process_item(req: ProcessItemRequest):
    if req.item_id not in items_db:
        raise HTTPException(status_code=404, detail="Không tìm thấy ảnh")

    item = items_db[req.item_id]
    orig_path = item["original_path"]

    try:
        pil_img = ImageOps.exif_transpose(Image.open(orig_path))
        res = processor.process_single(
            pil_img,
            size_key=req.size_key,
            bg_preset=req.bg_preset,
            custom_bg_hex=req.custom_bg_hex,
            clothing_id=req.clothing_id,
            clothes_scale=req.clothes_scale,
            clothes_y_offset=req.clothes_y_offset,
            skin_smooth=req.skin_smooth,
            brightness=req.brightness,
            contrast=req.contrast,
            sharpness=req.sharpness
        )

        out_name = f"anh_the_{req.size_key}_{item['filename']}"
        out_path = os.path.join(OUTPUTS_DIR, out_name)
        res["final_img"].save(out_path, quality=95, dpi=(300, 300))

        crop_path = os.path.join(UPLOADS_DIR, f"{item['id']}_cropped.jpg")
        proc_path = os.path.join(UPLOADS_DIR, f"{item['id']}_processed.jpg")
        res["original_cropped"].save(crop_path, "JPEG", quality=92)
        res["final_img"].save(proc_path, "JPEG", quality=92)

        cache_buster = f"?t={int(time.time()*1000)}"
        item["status"] = "done"
        item["processed_path"] = out_path
        item["download_url"] = f"/outputs/{out_name}"
        item["processed_url"] = f"/temp_uploads/{item['id']}_processed.jpg{cache_buster}"
        item["original_cropped_url"] = f"/temp_uploads/{item['id']}_cropped.jpg{cache_buster}"
        item["elapsed"] = res["elapsed_seconds"]
        item["dimensions"] = res["dimensions"]
        item["settings"] = req.dict()

        return item
    except Exception as e:
        print(f"Error processing item {req.item_id}: {e}")
        item["status"] = "error"
        item["error_msg"] = str(e)
        raise HTTPException(status_code=500, detail=str(e))

class InpaintRequest(BaseModel):
    item_id: str
    mask_b64: str

@app.post("/api/inpaint")
async def inpaint_object(req: InpaintRequest):
    if req.item_id not in items_db:
        raise HTTPException(status_code=404, detail="Không tìm thấy ảnh")
    item = items_db[req.item_id]
    src_path = item.get("processed_path") or item["original_path"]

    try:
        # Decode mask
        mask_data = req.mask_b64.split(",")[-1]
        mask_bytes = base64.b64decode(mask_data)
        mask_img = Image.open(io.BytesIO(mask_bytes))

        base_img = Image.open(src_path)
        mask_resized = mask_img.resize(base_img.size, Image.Resampling.NEAREST)

        result_img = processor.inpaint_engine.remove_object(base_img, mask_resized)

        # Save back
        result_img.save(src_path, quality=95)
        proc_path = os.path.join(UPLOADS_DIR, f"{item['id']}_processed.jpg")
        result_img.save(proc_path, "JPEG", quality=92)

        cache_buster = f"?t={int(time.time()*1000)}"
        item["processed_url"] = f"/temp_uploads/{item['id']}_processed.jpg{cache_buster}"
        return {"status": "done", "processed_url": item["processed_url"]}
    except Exception as e:
        print(f"Inpaint error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/export-zip")
async def export_zip():
    zip_buffer = io.BytesIO()
    count = 0
    with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
        for item_id, item in items_db.items():
            if item["status"] == "done" and item.get("processed_path") and os.path.exists(item["processed_path"]):
                arcname = os.path.basename(item["processed_path"])
                zf.write(item["processed_path"], arcname=arcname)
                count += 1

    if count == 0:
        raise HTTPException(status_code=400, detail="Chưa có ảnh nào được xử lý để xuất")

    zip_buffer.seek(0)
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={"Content-Disposition": "attachment; filename=Bo_Anh_Studio_300DPI.zip"}
    )

class PrintSheetRequest(BaseModel):
    sheet_type: str = "10x15_combo"
    item_id: Optional[str] = None
    size_key: str = "3x4"
    draw_guides: bool = True

@app.post("/api/create-print-sheet")
async def create_print_sheet(req: PrintSheetRequest):
    ready = [it for it in items_db.values() if it["status"] == "done" and it.get("processed_path")]
    if not ready:
        raise HTTPException(status_code=400, detail="Vui lòng xử lý ảnh trước khi tạo bản in")

    if req.sheet_type == "10x15_combo":
        target = items_db.get(req.item_id, ready[0]) if req.item_id else ready[0]
        img = Image.open(target["processed_path"])
        sheet = print_engine.create_10x15_combo(img, draw_guides=req.draw_guides)

    elif req.sheet_type == "10x15_single":
        target = items_db.get(req.item_id, ready[0]) if req.item_id else ready[0]
        img = Image.open(target["processed_path"])
        sheet = print_engine.create_10x15_single_size(img, size_key=req.size_key, draw_guides=req.draw_guides)

    elif req.sheet_type == "a4_class":
        student_items = []
        for it in ready:
            raw_name = os.path.splitext(it["filename"])[0].replace("_", " ")
            student_items.append({
                "name": raw_name,
                "img": Image.open(it["processed_path"])
            })
        sheet = print_engine.create_a4_class_sheet(student_items, size_key=req.size_key, draw_guides=req.draw_guides)
    else:
        raise HTTPException(status_code=400, detail="Loại khổ in không hợp lệ")

    out_sheet_name = f"kho_in_{req.sheet_type}_{int(time.time())}.jpg"
    out_sheet_path = os.path.join(OUTPUTS_DIR, out_sheet_name)
    sheet.save(out_sheet_path, quality=95, dpi=(300, 300))

    return {
        "sheet_type": req.sheet_type,
        "width": sheet.width,
        "height": sheet.height,
        "download_url": f"/outputs/{out_sheet_name}",
        "sheet_url": f"/outputs/{out_sheet_name}?t={int(time.time()*1000)}"
    }

@app.delete("/api/clear-all")
async def clear_all():
    items_db.clear()
    return {"status": "ok"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=7860, reload=False)
