import os
import sys
import time
import socket
import webbrowser
import threading
import uvicorn

# Set console encoding to UTF-8 on Windows
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

PORT = 7860
HOST = "127.0.0.1"
URL = f"http://{HOST}:{PORT}"

def is_port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex((HOST, port)) == 0

def open_browser():
    time.sleep(1.2)
    print(f"\n=======================================================")
    print(f" StudioAI Pro - He Thong Chinh Sua & Xu Ly Anh AI Toan Nang")
    print(f" Tac quyen: Thay giao Dinh Van Thanh (Zalo: 0915.213717)")
    print(f" Dang mo trinh duyet tai: {URL}")
    print(f"=======================================================\n")
    try:
        webbrowser.open(URL)
    except Exception as e:
        print(f"Khong the tu dong mo trinh duyet: {e}")

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(current_dir)
    sys.path.insert(0, current_dir)

    print(">>> Dang khoi tao StudioAI Pro Backend...")
    threading.Thread(target=open_browser, daemon=True).start()

    # Import FastAPI app
    from api.app import app
    uvicorn.run(app, host=HOST, port=PORT, log_level="info")
