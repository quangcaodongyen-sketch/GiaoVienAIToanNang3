# -*- coding: utf-8 -*-
"""
StudioAI Pro - Local Standalone Server
He Thong Chinh Sua & Xu Ly Anh AI Toan Nang
Tac quyen: Thay giao Dinh Van Thanh (Zalo: 0915.213717)
"""
import os
import sys
import webbrowser
import threading
import time
from http.server import HTTPServer, SimpleHTTPRequestHandler

PORT = 7860
HOST = "127.0.0.1"
URL = f"http://{HOST}:{PORT}"

class StudioHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        # Enable CORS and disable aggressive caching for local development
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        super().end_headers()

    def do_GET(self):
        # Serve index.html for root path
        if self.path == "/" or self.path == "/index.html":
            self.path = "/index.html"
        return super().do_GET()

def open_browser():
    time.sleep(1.0)
    print(f"\n==================================================================")
    print(f" StudioAI Pro - He Thong Chinh Sua & Xu Ly Anh AI Toan Nang")
    print(f" Tac quyen: Thay giao Dinh Van Thanh (Hotline/Zalo: 0915.213717)")
    print(f" Web dang chay tai: {URL}")
    print(f"==================================================================\n")
    try:
        webbrowser.open(URL)
    except Exception as e:
        print(f"Khong the tu dong mo trinh duyet: {e}")

if __name__ == "__main__":
    current_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(current_dir)

    print(">>> Dang khoi dong may chu StudioAI Pro...")
    threading.Thread(target=open_browser, daemon=True).start()

    try:
        server = HTTPServer((HOST, PORT), StudioHandler)
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nDa dung may chu.")
