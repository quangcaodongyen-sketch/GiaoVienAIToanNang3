@echo off
chcp 65001 >nul
title StudioAI Pro - Hệ Thống Chỉnh Sửa Ảnh AI Toàn Năng - Thầy Đinh Văn Thành
cd /d "%~dp0"

echo ==============================================================================
echo    StudioAI Pro - Nền Tảng Chỉnh Sửa & Xử Lý Ảnh AI Toàn Năng
echo    Tác quyền: Thầy giáo Đinh Văn Thành (Hotline / Zalo: 0915.213717)
echo ==============================================================================
echo.
echo [1/2] Đang khởi động máy chủ Web nội bộ StudioAI Pro...
echo [2/2] Trình duyệt sẽ tự động mở tại http://127.0.0.1:7860
echo.

python server.py
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [LƯU Ý] Không tìm thấy Python trong biến môi trường PATH!
    echo Đang mở trực tiếp trang giao diện web bằng trình duyệt mặc định...
    start "" "%~dp0index.html"
)

pause
