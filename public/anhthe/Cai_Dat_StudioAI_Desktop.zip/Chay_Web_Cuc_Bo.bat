@echo off
title StudioAI Pro - Thay giao Dinh Van Thanh
chcp 65001 >nul
cd /d "%~dp0"

echo ======================================================================
echo    STUDIOAI PRO - HE THONG XU LY & CHINH SUA ANH AI TOAN NANG
echo    Tac quyen: Thay giao Dinh Van Thanh - Hotline/Zalo: 0915.213717
echo ======================================================================
echo.

:: Kiem tra Python
where python >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [LOI] Khong tim thay Python tren he thong!
    echo Vui long cai dat Python 3.10 hoac 3.11 tai python.org va tich vao "Add Python to PATH".
    pause
    exit /b 1
)

echo [*] Dang kiem tra cac thu vien can thiet...
python -c "import fastapi, uvicorn, PIL, cv2, rembg" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [*] Dang tu dong cai dat thu vien (lan dau chay)...
    pip install -r requirements.txt
)

echo.
echo [*] Dang khoi dong Web Server cuc bo tai http://127.0.0.1:7860 ...
echo [*] Trinh duyet se tu dong mo len sau vai giay.
echo [*] De dong chuong trinh, hay dong cua so console nay.
echo.

python server.py

pause
