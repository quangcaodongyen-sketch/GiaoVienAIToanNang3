@echo off
setlocal enabledelayedexpansion
title Khoi Chay Dinh Thanh Cleaner Pro
color 0b

:: Tu dong yeu cau quyen Administrator
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo Dang yeu cau quyen Administrator...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
    pushd "%CD%"
    CD /D "%~dp0"

if exist "DinhThanh_Cleaner_Pro.exe" (
    start "" "DinhThanh_Cleaner_Pro.exe"
) else (
    echo Khong tim thay file DinhThanh_Cleaner_Pro.exe!
    pause
)
exit
